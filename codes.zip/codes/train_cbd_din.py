import os
import json
import time
import random
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from tqdm import tqdm

from sklearn.metrics import roc_auc_score
from sklearn.preprocessing import StandardScaler
import joblib

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# =========================================================
# 0. 配置
# =========================================================

class Config:
    # =====================================================
    # 本地路径：按你的实际路径修改
    # =====================================================
    EMBEDDINGS_DIR = "your_path/data/embeddings"
    PROCESSED_DIR = "your_path/data/processed"

    TRAIN_PATH = "your_path/data/processed/train_samples.csv"
    VALID_PATH = "your_path/data/processed/valid_samples.csv"
    TEST_PATH = "your_path/data/processed/test_samples.csv"

    NEWS_EMB_PATH = "your_path/data/embeddings/news_embeddings.npy"
    NEWS_MAP_PATH = "your_path/data/embeddings/news_id_to_index.json"

    # 可选，如果没有 news.tsv，代码会自动跳过 category 特征
    NEWS_TSV_PATH = "your_path/data/raw/news.tsv"

    OUTPUT_DIR = "./outputs/cf_din_macos_m2"

    # =====================================================
    # 随机种子
    # =====================================================
    SEED = 42

    # =====================================================
    # 负采样：与 DIN 保持一致
    # =====================================================
    USE_NEGATIVE_DOWNSAMPLE = True
    NEG_POS_RATIO = 4

    # =====================================================
    # 快速测试模式
    # =====================================================
    USE_FAST_TEST_MODE = False
    FAST_TEST_SAMPLE_SIZE = 50000

    # =====================================================
    # DIN 主干参数：与普通 DIN 保持一致
    # =====================================================
    MAX_HISTORY_LEN = 50
    BATCH_SIZE = 256
    NUM_WORKERS = 0

    ATTENTION_HIDDEN_DIM = 64
    MLP_HIDDEN_DIMS = [256, 128, 64]
    DROPOUT = 0.2

    EPOCHS = 8
    LR = 1e-3
    WEIGHT_DECAY = 1e-5
    PATIENCE = 2

    # =====================================================
    # CF-DIN 去偏参数
    # =====================================================
    # 训练时 total_logit = interest_logit + TRAIN_BIAS_ALPHA * bias_logit
    TRAIN_BIAS_ALPHA = 1.0

    # bias tower 辅助损失权重
    # 太大会让模型过度学习 bias；建议 0.05 ~ 0.2
    BIAS_AUX_LOSS_WEIGHT = 0.10

    # interest_logit 和 bias_logit 的去相关正则
    # 太大会损害性能；建议 0.0 ~ 0.02
    DECOUPLE_LOSS_WEIGHT = 0.005

    # 推理阶段 eta 搜索空间
    # eta=1.0：保留完整 bias
    # eta=0.0：完全去除 bias
    # eta<1.0：温和去偏
    # eta>1.0：如果 bias 对 valid 有帮助，也允许增强
    ETA_GRID = [-0.2, 0.0, 0.1, 0.2, 0.3, 0.5, 0.7, 1.0, 1.2]

    # valid 选择 eta / best model 的指标
    # 可选：
    # "auc", "group_auc", "mrr", "ndcg@5", "ndcg@10", "composite"
    SELECT_METRIC = "composite"

    # =====================================================
    # MPS
    # =====================================================
    USE_MPS = True

cfg = Config()
os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)

# =========================================================
# 1. 随机种子和设备
# =========================================================

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

set_seed(cfg.SEED)

def get_device():
    if cfg.USE_MPS and torch.backends.mps.is_available():
        return torch.device("mps")
    elif torch.cuda.is_available():
        return torch.device("cuda")
    else:
        return torch.device("cpu")

device = get_device()

print("=" * 90)
print("CF-DIN / Counterfactual Bias-Decomposed DIN")
print("=" * 90)
print(f"Device: {device}")
print(f"Output dir: {cfg.OUTPUT_DIR}")

if device.type == "mps":
    print("使用 Apple Silicon MPS 后端")
elif device.type == "cuda":
    print(f"使用 CUDA: {torch.cuda.get_device_name(0)}")
else:
    print("使用 CPU")

# =========================================================
# 2. 读取数据
# =========================================================

print("\n" + "=" * 90)
print("Step 1: 加载数据")
print("=" * 90)

train_full_df = pd.read_csv(cfg.TRAIN_PATH)
valid_df = pd.read_csv(cfg.VALID_PATH)
test_df = pd.read_csv(cfg.TEST_PATH)

print(f"原始 train: {len(train_full_df):,}, CTR={train_full_df['label'].mean():.5f}")
print(f"原始 valid: {len(valid_df):,}, CTR={valid_df['label'].mean():.5f}")

if "label" in test_df.columns:
    print(f"原始 test : {len(test_df):,}, CTR={test_df['label'].mean():.5f}")
else:
    print(f"原始 test : {len(test_df):,}, 无 label")

required_cols = ["user_id", "candidate_news_id", "history"]
for col in required_cols:
    assert col in train_full_df.columns, f"train_df 缺少必要列: {col}"

assert "label" in train_full_df.columns
assert "label" in valid_df.columns

# =========================================================
# 3. fit bias statistics：注意在负采样前的完整 train 上统计
# =========================================================

print("\n" + "=" * 90)
print("Step 2: 构造 bias/confounder 统计特征")
print("=" * 90)

def safe_history_len(x):
    if pd.isna(x) or str(x) == "" or str(x) == "nan":
        return 0
    return len(str(x).split())

def load_news_meta(path):
    if not os.path.exists(path):
        print(f"未找到 news.tsv: {path}，跳过 category/subcategory 特征")
        return None

    news_df = pd.read_csv(
        path,
        sep="\t",
        header=None,
        names=[
            "news_id", "category", "subcategory", "title", "abstract",
            "url", "title_entities", "abstract_entities"
        ]
    )

    print(f"已加载 news.tsv: {len(news_df):,}")
    return news_df

news_meta_df = load_news_meta(cfg.NEWS_TSV_PATH)

def fit_bias_statistics(train_df, news_meta_df=None):
    """
    只使用完整 train 统计，避免 valid/test 泄露。
    注意：这里使用负采样前 train，避免采样改变曝光/CTR 统计。
    """
    stats = {}

    stats["global_ctr"] = float(train_df["label"].mean())

    # news-level
    stats["news_exposure_count"] = train_df["candidate_news_id"].value_counts().to_dict()
    stats["news_click_count"] = train_df.loc[
        train_df["label"] == 1, "candidate_news_id"
    ].value_counts().to_dict()

    # user-level
    stats["user_exposure_count"] = train_df["user_id"].value_counts().to_dict()
    stats["user_click_count"] = train_df.loc[
        train_df["label"] == 1, "user_id"
    ].value_counts().to_dict()

    if news_meta_df is not None:
        news_meta = news_meta_df[[
            "news_id", "category", "subcategory", "title", "abstract"
        ]].copy()

        stats["news_meta"] = news_meta

        tmp = train_df[["candidate_news_id", "label"]].merge(
            news_meta[["news_id", "category", "subcategory"]],
            left_on="candidate_news_id",
            right_on="news_id",
            how="left"
        )

        cat_grp = tmp.groupby("category")["label"].agg(["sum", "count"]).reset_index()
        cat_grp["category_ctr"] = cat_grp["sum"] / (cat_grp["count"] + 1e-6)

        stats["category_ctr"] = dict(zip(cat_grp["category"], cat_grp["category_ctr"]))
        stats["category_exposure"] = dict(zip(cat_grp["category"], cat_grp["count"]))

        sub_grp = tmp.groupby("subcategory")["label"].agg(["sum", "count"]).reset_index()
        sub_grp["subcategory_ctr"] = sub_grp["sum"] / (sub_grp["count"] + 1e-6)

        stats["subcategory_ctr"] = dict(zip(sub_grp["subcategory"], sub_grp["subcategory_ctr"]))
        stats["subcategory_exposure"] = dict(zip(sub_grp["subcategory"], sub_grp["count"]))

    else:
        stats["news_meta"] = None

    return stats

def transform_bias_features(df, stats):
    out = df.copy()

    # news exposure/click
    out["news_exposure_count"] = out["candidate_news_id"].map(
        stats["news_exposure_count"]
    ).fillna(0).astype(np.float32)

    out["news_click_count"] = out["candidate_news_id"].map(
        stats["news_click_count"]
    ).fillna(0).astype(np.float32)

    out["news_ctr"] = out["news_click_count"] / (out["news_exposure_count"] + 1e-6)

    # user exposure/click
    out["user_exposure_count"] = out["user_id"].map(
        stats["user_exposure_count"]
    ).fillna(0).astype(np.float32)

    out["user_click_count"] = out["user_id"].map(
        stats["user_click_count"]
    ).fillna(0).astype(np.float32)

    out["user_ctr"] = out["user_click_count"] / (out["user_exposure_count"] + 1e-6)

    # history len
    out["user_history_len"] = out["history"].apply(safe_history_len).astype(np.float32)

    # log transforms
    out["log_news_exposure_count"] = np.log1p(out["news_exposure_count"]).astype(np.float32)
    out["log_news_click_count"] = np.log1p(out["news_click_count"]).astype(np.float32)
    out["log_user_exposure_count"] = np.log1p(out["user_exposure_count"]).astype(np.float32)
    out["log_user_click_count"] = np.log1p(out["user_click_count"]).astype(np.float32)
    out["log_user_history_len_bias"] = np.log1p(out["user_history_len"]).astype(np.float32)

    if stats.get("news_meta") is not None:
        news_meta = stats["news_meta"]

        out = out.merge(
            news_meta[["news_id", "category", "subcategory", "title", "abstract"]],
            left_on="candidate_news_id",
            right_on="news_id",
            how="left"
        )

        out["category_ctr"] = out["category"].map(
            stats["category_ctr"]
        ).fillna(stats["global_ctr"]).astype(np.float32)

        out["subcategory_ctr"] = out["subcategory"].map(
            stats["subcategory_ctr"]
        ).fillna(stats["global_ctr"]).astype(np.float32)

        out["category_exposure"] = out["category"].map(
            stats["category_exposure"]
        ).fillna(0).astype(np.float32)

        out["subcategory_exposure"] = out["subcategory"].map(
            stats["subcategory_exposure"]
        ).fillna(0).astype(np.float32)

        out["log_category_exposure"] = np.log1p(out["category_exposure"]).astype(np.float32)
        out["log_subcategory_exposure"] = np.log1p(out["subcategory_exposure"]).astype(np.float32)

        out["title_length"] = out["title"].fillna("").apply(
            lambda x: len(str(x).split())
        ).astype(np.float32)

        out["abstract_length"] = out["abstract"].fillna("").apply(
            lambda x: len(str(x).split())
        ).astype(np.float32)

        out["has_abstract"] = out["abstract"].notna().astype(np.float32)

    else:
        out["category_ctr"] = stats["global_ctr"]
        out["subcategory_ctr"] = stats["global_ctr"]
        out["log_category_exposure"] = 0.0
        out["log_subcategory_exposure"] = 0.0
        out["title_length"] = 0.0
        out["abstract_length"] = 0.0
        out["has_abstract"] = 0.0

    return out

bias_stats = fit_bias_statistics(train_full_df, news_meta_df)

# 先对完整 train 变换，后续负采样在带特征的 train 上做
train_full_bias_df = transform_bias_features(train_full_df, bias_stats)
valid_bias_df = transform_bias_features(valid_df, bias_stats)
test_bias_df = transform_bias_features(test_df, bias_stats)

BIAS_FEATURES = [
    "log_news_exposure_count",
    "log_news_click_count",
    "news_ctr",
    "log_user_exposure_count",
    "log_user_click_count",
    "user_ctr",
    "log_user_history_len_bias",
    "category_ctr",
    "subcategory_ctr",
    "log_category_exposure",
    "log_subcategory_exposure",
    "title_length",
    "abstract_length",
    "has_abstract",
]

BIAS_FEATURES = [c for c in BIAS_FEATURES if c in train_full_bias_df.columns]

print(f"Bias/confounder features: {len(BIAS_FEATURES)}")
print(BIAS_FEATURES)

# =========================================================
# 4. 负采样：与普通 DIN 保持一致
# =========================================================

def negative_downsample(df, neg_pos_ratio=4, seed=42):
    pos_df = df[df["label"] == 1]
    neg_df = df[df["label"] == 0]

    n_pos = len(pos_df)
    n_neg_keep = min(len(neg_df), n_pos * neg_pos_ratio)

    neg_sampled = neg_df.sample(n=n_neg_keep, random_state=seed)
    sampled_df = pd.concat([pos_df, neg_sampled], axis=0)
    sampled_df = sampled_df.sample(frac=1.0, random_state=seed).reset_index(drop=True)

    return sampled_df

train_bias_df = train_full_bias_df.copy()

if cfg.USE_NEGATIVE_DOWNSAMPLE:
    print("\n执行负采样")
    print(f"负采样比例: 1:{cfg.NEG_POS_RATIO}")
    train_bias_df = negative_downsample(
        train_bias_df,
        neg_pos_ratio=cfg.NEG_POS_RATIO,
        seed=cfg.SEED
    )
    print(f"采样后 train: {len(train_bias_df):,}, CTR={train_bias_df['label'].mean():.5f}")

if cfg.USE_FAST_TEST_MODE:
    print("\n⚠️ 当前为快速测试模式")
    if len(train_bias_df) > cfg.FAST_TEST_SAMPLE_SIZE:
        train_bias_df = train_bias_df.sample(
            n=cfg.FAST_TEST_SAMPLE_SIZE,
            random_state=cfg.SEED
        ).reset_index(drop=True)
    print(f"快速测试 train: {len(train_bias_df):,}, CTR={train_bias_df['label'].mean():.5f}")

# =========================================================
# 5. 标准化 bias features
# =========================================================

print("\n" + "=" * 90)
print("Step 3: 标准化 bias features")
print("=" * 90)

scaler = StandardScaler()

X_bias_train = train_bias_df[BIAS_FEATURES].replace(
    [np.inf, -np.inf], 0
).fillna(0).values.astype(np.float32)

X_bias_valid = valid_bias_df[BIAS_FEATURES].replace(
    [np.inf, -np.inf], 0
).fillna(0).values.astype(np.float32)

X_bias_test = test_bias_df[BIAS_FEATURES].replace(
    [np.inf, -np.inf], 0
).fillna(0).values.astype(np.float32)

X_bias_train_scaled = scaler.fit_transform(X_bias_train).astype(np.float32)
X_bias_valid_scaled = scaler.transform(X_bias_valid).astype(np.float32)
X_bias_test_scaled = scaler.transform(X_bias_test).astype(np.float32)

# 写回 dataframe，方便 Dataset 按行读取
for i, col in enumerate(BIAS_FEATURES):
    train_bias_df[f"bias_scaled_{i}"] = X_bias_train_scaled[:, i]
    valid_bias_df[f"bias_scaled_{i}"] = X_bias_valid_scaled[:, i]
    test_bias_df[f"bias_scaled_{i}"] = X_bias_test_scaled[:, i]

BIAS_SCALED_COLS = [f"bias_scaled_{i}" for i in range(len(BIAS_FEATURES))]

joblib.dump(
    {
        "scaler": scaler,
        "bias_features": BIAS_FEATURES,
        "bias_stats": bias_stats,
    },
    os.path.join(cfg.OUTPUT_DIR, "bias_feature_processor.pkl")
)

print("bias feature scaler saved")

# =========================================================
# 6. 加载新闻 embedding
# =========================================================

print("\n" + "=" * 90)
print("Step 4: 加载新闻 embedding")
print("=" * 90)

news_embeddings = np.load(cfg.NEWS_EMB_PATH).astype(np.float32)

with open(cfg.NEWS_MAP_PATH, "r", encoding="utf-8") as f:
    news_id_to_index = json.load(f)

embedding_dim = news_embeddings.shape[1]

print(f"news_embeddings shape: {news_embeddings.shape}")
print(f"embedding_dim: {embedding_dim}")
print(f"news_id_to_index size: {len(news_id_to_index):,}")

# =========================================================
# 7. Dataset / DataLoader
# =========================================================

print("\n" + "=" * 90)
print("Step 5: 构造 Dataset / DataLoader")
print("=" * 90)

class CFDINDataset(Dataset):
    def __init__(
        self,
        df,
        news_embeddings,
        news_id_to_index,
        bias_scaled_cols,
        max_history_len=50,
        has_label=True
    ):
        self.df = df.reset_index(drop=True)
        self.news_embeddings = news_embeddings
        self.news_id_to_index = news_id_to_index
        self.bias_scaled_cols = bias_scaled_cols
        self.max_history_len = max_history_len
        self.has_label = has_label
        self.embedding_dim = news_embeddings.shape[1]
        self.bias_dim = len(bias_scaled_cols)

    def __len__(self):
        return len(self.df)

    def _get_vec(self, news_id):
        if news_id in self.news_id_to_index:
            return self.news_embeddings[self.news_id_to_index[news_id]]
        return np.zeros(self.embedding_dim, dtype=np.float32)

    def _get_history_vecs_and_mask(self, history):
        history_vecs = np.zeros(
            (self.max_history_len, self.embedding_dim),
            dtype=np.float32
        )
        history_mask = np.zeros(self.max_history_len, dtype=np.float32)

        if pd.isna(history) or str(history) == "" or str(history) == "nan":
            return history_vecs, history_mask, 0

        news_ids = str(history).split()
        news_ids = news_ids[-self.max_history_len:]

        real_len = 0
        for i, nid in enumerate(news_ids):
            if nid in self.news_id_to_index:
                history_vecs[i] = self.news_embeddings[self.news_id_to_index[nid]]
                history_mask[i] = 1.0
                real_len += 1

        return history_vecs, history_mask, real_len

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        candidate_vec = self._get_vec(row["candidate_news_id"]).astype(np.float32)

        history_vecs, history_mask, real_history_len = self._get_history_vecs_and_mask(
            row["history"]
        )

        log_history_len = np.float32(np.log1p(real_history_len))

        bias_features = row[self.bias_scaled_cols].values.astype(np.float32)

        item = {
            "candidate_vec": torch.tensor(candidate_vec, dtype=torch.float32),
            "history_vecs": torch.tensor(history_vecs, dtype=torch.float32),
            "history_mask": torch.tensor(history_mask, dtype=torch.float32),
            "log_history_len": torch.tensor([log_history_len], dtype=torch.float32),
            "bias_features": torch.tensor(bias_features, dtype=torch.float32),
        }

        if self.has_label and "label" in row:
            item["label"] = torch.tensor(row["label"], dtype=torch.float32)
        else:
            item["label"] = torch.tensor(0.0, dtype=torch.float32)

        return item

train_dataset = CFDINDataset(
    train_bias_df,
    news_embeddings,
    news_id_to_index,
    BIAS_SCALED_COLS,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=True
)

valid_dataset = CFDINDataset(
    valid_bias_df,
    news_embeddings,
    news_id_to_index,
    BIAS_SCALED_COLS,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=True
)

test_dataset = CFDINDataset(
    test_bias_df,
    news_embeddings,
    news_id_to_index,
    BIAS_SCALED_COLS,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=("label" in test_bias_df.columns)
)

train_loader = DataLoader(
    train_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=True,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

valid_loader = DataLoader(
    valid_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

test_loader = DataLoader(
    test_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

print(f"train batches: {len(train_loader)}")
print(f"valid batches: {len(valid_loader)}")
print(f"test batches : {len(test_loader)}")

# =========================================================
# 8. 模型定义
# =========================================================

print("\n" + "=" * 90)
print("Step 6: 定义 CF-DIN 模型")
print("=" * 90)

class AttentionLayer(nn.Module):
    def __init__(self, embedding_dim, attention_hidden_dim=64):
        super().__init__()

        input_dim = embedding_dim * 4

        self.attention_mlp = nn.Sequential(
            nn.Linear(input_dim, attention_hidden_dim),
            nn.ReLU(),
            nn.Linear(attention_hidden_dim, attention_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(attention_hidden_dim // 2, 1)
        )

    def forward(self, history_vecs, candidate_vec, history_mask):
        B, H, D = history_vecs.shape

        candidate_expand = candidate_vec.unsqueeze(1).expand(-1, H, -1)

        attention_input = torch.cat(
            [
                history_vecs,
                candidate_expand,
                history_vecs * candidate_expand,
                torch.abs(history_vecs - candidate_expand)
            ],
            dim=-1
        )

        scores = self.attention_mlp(attention_input).squeeze(-1)
        scores = scores.masked_fill(history_mask <= 0, -1e9)

        weights = torch.softmax(scores, dim=1)

        weights = weights * history_mask
        weights_sum = weights.sum(dim=1, keepdim=True) + 1e-8
        weights = weights / weights_sum

        user_vec = torch.sum(
            history_vecs * weights.unsqueeze(-1),
            dim=1
        )

        return user_vec, weights

class CFDIN(nn.Module):
    """
    CF-DIN:
    - DIN 主干输出 interest_logit
    - bias tower 输出 bias_logit
    - 训练时 total_logit = interest_logit + alpha * bias_logit
    - 推理时 cf_logit = interest_logit + eta * bias_logit
    """

    def __init__(
        self,
        embedding_dim,
        bias_dim,
        attention_hidden_dim=64,
        mlp_hidden_dims=[256, 128, 64],
        dropout=0.2
    ):
        super().__init__()

        self.embedding_dim = embedding_dim
        self.bias_dim = bias_dim

        self.attention = AttentionLayer(
            embedding_dim=embedding_dim,
            attention_hidden_dim=attention_hidden_dim
        )

        # -------------------------
        # Interest tower：与普通 DIN MLP 尽量一致
        # -------------------------
        interest_input_dim = embedding_dim * 3 + 2

        interest_layers = []
        prev_dim = interest_input_dim

        for hidden_dim in mlp_hidden_dims:
            interest_layers.append(nn.Linear(prev_dim, hidden_dim))
            interest_layers.append(nn.BatchNorm1d(hidden_dim))
            interest_layers.append(nn.ReLU())
            interest_layers.append(nn.Dropout(dropout))
            prev_dim = hidden_dim

        interest_layers.append(nn.Linear(prev_dim, 1))

        self.interest_mlp = nn.Sequential(*interest_layers)

        # -------------------------
        # Bias tower：只使用统计 confounder features
        # -------------------------
        self.bias_mlp = nn.Sequential(
            nn.Linear(bias_dim, 64),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(64, 32),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(32, 1)
        )

    def forward(
        self,
        candidate_vec,
        history_vecs,
        history_mask,
        log_history_len,
        bias_features
    ):
        user_vec, att_weights = self.attention(
            history_vecs=history_vecs,
            candidate_vec=candidate_vec,
            history_mask=history_mask
        )

        interaction_vec = user_vec * candidate_vec

        user_norm = torch.norm(user_vec, dim=1, keepdim=True)
        cand_norm = torch.norm(candidate_vec, dim=1, keepdim=True)

        cosine_sim = torch.sum(user_vec * candidate_vec, dim=1, keepdim=True) / (
            user_norm * cand_norm + 1e-8
        )

        interest_input = torch.cat(
            [
                user_vec,
                candidate_vec,
                interaction_vec,
                cosine_sim,
                log_history_len
            ],
            dim=1
        )

        interest_logit = self.interest_mlp(interest_input).squeeze(-1)
        bias_logit = self.bias_mlp(bias_features).squeeze(-1)

        total_logit = interest_logit + cfg.TRAIN_BIAS_ALPHA * bias_logit

        return {
            "interest_logit": interest_logit,
            "bias_logit": bias_logit,
            "total_logit": total_logit,
        }

model = CFDIN(
    embedding_dim=embedding_dim,
    bias_dim=len(BIAS_FEATURES),
    attention_hidden_dim=cfg.ATTENTION_HIDDEN_DIM,
    mlp_hidden_dims=cfg.MLP_HIDDEN_DIMS,
    dropout=cfg.DROPOUT
).to(device)

print(model)
print(f"可训练参数量: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

# =========================================================
# 9. loss / train / predict
# =========================================================

def move_batch_to_device(batch, device):
    return {
        k: v.to(device)
        for k, v in batch.items()
    }

def batch_corr_penalty(x, y):
    """
    去相关正则：
    降低 interest_logit 与 bias_logit 的线性相关性。
    只作为温和约束，权重不能太大。
    """
    x = x - x.mean()
    y = y - y.mean()

    x_std = torch.sqrt(torch.mean(x ** 2) + 1e-8)
    y_std = torch.sqrt(torch.mean(y ** 2) + 1e-8)

    corr = torch.mean(x * y) / (x_std * y_std + 1e-8)

    return corr ** 2

def compute_cf_din_loss(outputs, labels):
    interest_logit = outputs["interest_logit"]
    bias_logit = outputs["bias_logit"]
    total_logit = outputs["total_logit"]

    # 主任务：total path
    main_loss = F.binary_cross_entropy_with_logits(
        total_logit,
        labels,
        reduction="mean"
    )

    # bias tower 辅助预测，让 bias 分支显式吸收统计偏置信息
    bias_aux_loss = F.binary_cross_entropy_with_logits(
        bias_logit,
        labels,
        reduction="mean"
    )

    # 去相关约束：减少 interest 与 bias 的混合
    decouple_loss = batch_corr_penalty(interest_logit, bias_logit)

    loss = (
        main_loss
        + cfg.BIAS_AUX_LOSS_WEIGHT * bias_aux_loss
        + cfg.DECOUPLE_LOSS_WEIGHT * decouple_loss
    )

    loss_dict = {
        "loss": loss,
        "main_loss": main_loss.detach(),
        "bias_aux_loss": bias_aux_loss.detach(),
        "decouple_loss": decouple_loss.detach(),
    }

    return loss, loss_dict

def train_one_epoch(model, loader, optimizer, device):
    model.train()

    total_loss = 0.0
    total_main_loss = 0.0
    total_bias_loss = 0.0
    total_decouple_loss = 0.0

    total_samples = 0

    all_probs = []
    all_labels = []

    for batch in tqdm(loader, desc="Train", leave=False):
        batch = move_batch_to_device(batch, device)

        labels = batch["label"]

        optimizer.zero_grad(set_to_none=True)

        outputs = model(
            candidate_vec=batch["candidate_vec"],
            history_vecs=batch["history_vecs"],
            history_mask=batch["history_mask"],
            log_history_len=batch["log_history_len"],
            bias_features=batch["bias_features"],
        )

        loss, loss_dict = compute_cf_din_loss(outputs, labels)

        loss.backward()
        optimizer.step()

        batch_size = labels.size(0)

        total_loss += loss.item() * batch_size
        total_main_loss += loss_dict["main_loss"].item() * batch_size
        total_bias_loss += loss_dict["bias_aux_loss"].item() * batch_size
        total_decouple_loss += loss_dict["decouple_loss"].item() * batch_size

        total_samples += batch_size

        probs = torch.sigmoid(outputs["total_logit"]).detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()

        all_probs.append(probs)
        all_labels.append(labels_np)

    all_probs = np.concatenate(all_probs)
    all_labels = np.concatenate(all_labels)

    avg_loss = total_loss / max(total_samples, 1)
    avg_main_loss = total_main_loss / max(total_samples, 1)
    avg_bias_loss = total_bias_loss / max(total_samples, 1)
    avg_decouple_loss = total_decouple_loss / max(total_samples, 1)

    try:
        auc = roc_auc_score(all_labels, all_probs)
    except Exception:
        auc = 0.0

    return {
        "loss": avg_loss,
        "main_loss": avg_main_loss,
        "bias_aux_loss": avg_bias_loss,
        "decouple_loss": avg_decouple_loss,
        "auc": auc,
    }

@torch.no_grad()
def predict_components(model, loader, device, desc="Predict", has_label=True):
    model.eval()

    all_interest_logits = []
    all_bias_logits = []
    all_total_logits = []
    all_labels = []

    total_loss = 0.0
    total_samples = 0

    for batch in tqdm(loader, desc=desc, leave=False):
        batch = move_batch_to_device(batch, device)

        outputs = model(
            candidate_vec=batch["candidate_vec"],
            history_vecs=batch["history_vecs"],
            history_mask=batch["history_mask"],
            log_history_len=batch["log_history_len"],
            bias_features=batch["bias_features"],
        )

        interest_logit = outputs["interest_logit"]
        bias_logit = outputs["bias_logit"]
        total_logit = outputs["total_logit"]

        all_interest_logits.append(interest_logit.detach().cpu().numpy())
        all_bias_logits.append(bias_logit.detach().cpu().numpy())
        all_total_logits.append(total_logit.detach().cpu().numpy())

        if has_label:
            labels = batch["label"]

            loss = F.binary_cross_entropy_with_logits(
                total_logit,
                labels,
                reduction="mean"
            )

            labels_np = labels.detach().cpu().numpy()
            all_labels.append(labels_np)

            batch_size = labels.size(0)
            total_loss += loss.item() * batch_size
            total_samples += batch_size

    interest_logits = np.concatenate(all_interest_logits)
    bias_logits = np.concatenate(all_bias_logits)
    total_logits = np.concatenate(all_total_logits)

    if has_label:
        labels = np.concatenate(all_labels)
        avg_loss = total_loss / max(total_samples, 1)
    else:
        labels = None
        avg_loss = None

    return {
        "interest_logits": interest_logits,
        "bias_logits": bias_logits,
        "total_logits": total_logits,
        "labels": labels,
        "loss": avg_loss,
    }

def sigmoid_np(x):
    return 1.0 / (1.0 + np.exp(-x))

# =========================================================
# 10. 指标函数
# =========================================================

def dcg_score(labels):
    labels = np.asarray(labels)
    gains = (2 ** labels - 1)
    discounts = np.log2(np.arange(len(labels)) + 2)
    return np.sum(gains / discounts)

def ndcg_score(labels, k=None):
    labels = np.asarray(labels)

    if k is not None:
        labels = labels[:k]

    dcg = dcg_score(labels)

    ideal = np.sort(labels)[::-1]
    if k is not None:
        ideal = ideal[:k]

    idcg = dcg_score(ideal)

    if idcg == 0:
        return 0.0

    return dcg / idcg

def mrr_score(labels):
    labels = np.asarray(labels)
    pos_indices = np.where(labels == 1)[0]

    if len(pos_indices) == 0:
        return 0.0

    return 1.0 / (pos_indices[0] + 1)

def evaluate_ranking_metrics(df, probs):
    eval_df = df.copy()
    eval_df["pred"] = probs

    if "label" not in eval_df.columns:
        return {
            "auc": None,
            "group_auc": None,
            "mrr": None,
            "ndcg@5": None,
            "ndcg@10": None,
        }

    labels_all = eval_df["label"].values

    try:
        auc = roc_auc_score(labels_all, probs)
    except Exception:
        auc = 0.0

    if "impression_id" not in eval_df.columns:
        return {
            "auc": float(auc),
            "group_auc": 0.0,
            "mrr": 0.0,
            "ndcg@5": 0.0,
            "ndcg@10": 0.0,
        }

    auc_list = []
    mrr_list = []
    ndcg5_list = []
    ndcg10_list = []

    for imp_id, group in tqdm(eval_df.groupby("impression_id"), desc="Ranking metrics", leave=False):
        labels = group["label"].values
        preds = group["pred"].values

        if len(np.unique(labels)) > 1:
            auc_list.append(roc_auc_score(labels, preds))

        order = np.argsort(-preds)
        sorted_labels = labels[order]

        mrr_list.append(mrr_score(sorted_labels))
        ndcg5_list.append(ndcg_score(sorted_labels, k=5))
        ndcg10_list.append(ndcg_score(sorted_labels, k=10))

    metrics = {
        "auc": float(auc),
        "group_auc": float(np.mean(auc_list)) if len(auc_list) > 0 else 0.0,
        "mrr": float(np.mean(mrr_list)) if len(mrr_list) > 0 else 0.0,
        "ndcg@5": float(np.mean(ndcg5_list)) if len(ndcg5_list) > 0 else 0.0,
        "ndcg@10": float(np.mean(ndcg10_list)) if len(ndcg10_list) > 0 else 0.0,
    }

    return metrics

def metric_selection_score(metrics, select_metric="composite"):
    if metrics["auc"] is None:
        return -1e9

    if select_metric == "auc":
        return metrics["auc"]
    elif select_metric == "group_auc":
        return metrics["group_auc"]
    elif select_metric == "mrr":
        return metrics["mrr"]
    elif select_metric == "ndcg@5":
        return metrics["ndcg@5"]
    elif select_metric == "ndcg@10":
        return metrics["ndcg@10"]
    elif select_metric == "composite":
        # 为了求稳，同时考虑分类和排序指标
        # AUC/group_auc 数值偏大，MRR/nDCG 也纳入。
        return (
            0.25 * metrics["auc"]
            + 0.25 * metrics["group_auc"]
            + 0.20 * metrics["mrr"]
            + 0.15 * metrics["ndcg@5"]
            + 0.15 * metrics["ndcg@10"]
        )
    else:
        return metrics["group_auc"]

def evaluate_eta_grid(df, components, eta_grid, select_metric="composite"):
    """
    对不同 eta 进行 valid 选择：
      cf_logit = interest_logit + eta * bias_logit
    """
    interest_logits = components["interest_logits"]
    bias_logits = components["bias_logits"]

    results = []

    best_eta = None
    best_score = -1e18
    best_metrics = None
    best_probs = None

    for eta in eta_grid:
        logits = interest_logits + eta * bias_logits
        probs = sigmoid_np(logits)

        metrics = evaluate_ranking_metrics(df, probs)
        score = metric_selection_score(metrics, select_metric)

        row = {
            "eta": float(eta),
            "score": float(score),
            **metrics
        }

        results.append(row)

        if score > best_score:
            best_score = score
            best_eta = eta
            best_metrics = metrics
            best_probs = probs

    results_df = pd.DataFrame(results)

    return {
        "best_eta": float(best_eta),
        "best_score": float(best_score),
        "best_metrics": best_metrics,
        "best_probs": best_probs,
        "results_df": results_df,
    }

# =========================================================
# 11. 训练
# =========================================================

print("\n" + "=" * 90)
print("Step 7: 开始训练 CF-DIN")
print("=" * 90)

optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=cfg.LR,
    weight_decay=cfg.WEIGHT_DECAY
)

scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer,
    mode="max",
    factor=0.5,
    patience=1
)

best_valid_score = -1e18
best_valid_metrics = None
best_eta = None
best_epoch = -1
patience_counter = 0

history_logs = []

best_model_path = os.path.join(cfg.OUTPUT_DIR, "best_cf_din.pt")

start_total = time.time()

for epoch in range(1, cfg.EPOCHS + 1):
    print("\n" + "-" * 90)
    print(f"Epoch {epoch}/{cfg.EPOCHS}")
    print("-" * 90)

    start_epoch = time.time()

    train_log = train_one_epoch(
        model,
        train_loader,
        optimizer,
        device
    )

    valid_components = predict_components(
        model,
        valid_loader,
        device,
        desc="Valid components",
        has_label=True
    )

    eta_eval = evaluate_eta_grid(
        valid_bias_df,
        valid_components,
        cfg.ETA_GRID,
        select_metric=cfg.SELECT_METRIC
    )

    valid_score = eta_eval["best_score"]
    valid_metrics = eta_eval["best_metrics"]
    epoch_best_eta = eta_eval["best_eta"]

    scheduler.step(valid_score)

    epoch_time = time.time() - start_epoch

    log = {
        "epoch": int(epoch),
        "train_loss": float(train_log["loss"]),
        "train_main_loss": float(train_log["main_loss"]),
        "train_bias_aux_loss": float(train_log["bias_aux_loss"]),
        "train_decouple_loss": float(train_log["decouple_loss"]),
        "train_auc_total": float(train_log["auc"]),
        "valid_score": float(valid_score),
        "valid_best_eta": float(epoch_best_eta),
        "valid_auc": float(valid_metrics["auc"]),
        "valid_group_auc": float(valid_metrics["group_auc"]),
        "valid_mrr": float(valid_metrics["mrr"]),
        "valid_ndcg@5": float(valid_metrics["ndcg@5"]),
        "valid_ndcg@10": float(valid_metrics["ndcg@10"]),
        "lr": float(optimizer.param_groups[0]["lr"]),
        "epoch_time": float(epoch_time),
    }

    history_logs.append(log)

    eta_result_path = os.path.join(
        cfg.OUTPUT_DIR,
        f"eta_grid_epoch_{epoch}.csv"
    )
    eta_eval["results_df"].to_csv(eta_result_path, index=False)

    print(
        f"Epoch {epoch}: "
        f"train_loss={train_log['loss']:.5f}, "
        f"train_auc_total={train_log['auc']:.5f}, "
        f"valid_score={valid_score:.6f}, "
        f"eta={epoch_best_eta}, "
        f"valid_auc={valid_metrics['auc']:.6f}, "
        f"group_auc={valid_metrics['group_auc']:.6f}, "
        f"mrr={valid_metrics['mrr']:.6f}, "
        f"ndcg@5={valid_metrics['ndcg@5']:.6f}, "
        f"ndcg@10={valid_metrics['ndcg@10']:.6f}, "
        f"lr={optimizer.param_groups[0]['lr']:.2e}, "
        f"time={epoch_time:.1f}s"
    )

    if valid_score > best_valid_score:
        best_valid_score = valid_score
        best_valid_metrics = valid_metrics
        best_eta = epoch_best_eta
        best_epoch = epoch
        patience_counter = 0

        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "config": {
                    "embedding_dim": embedding_dim,
                    "bias_dim": len(BIAS_FEATURES),
                    "max_history_len": cfg.MAX_HISTORY_LEN,
                    "attention_hidden_dim": cfg.ATTENTION_HIDDEN_DIM,
                    "mlp_hidden_dims": cfg.MLP_HIDDEN_DIMS,
                    "dropout": cfg.DROPOUT,
                    "train_bias_alpha": cfg.TRAIN_BIAS_ALPHA,
                    "bias_aux_loss_weight": cfg.BIAS_AUX_LOSS_WEIGHT,
                    "decouple_loss_weight": cfg.DECOUPLE_LOSS_WEIGHT,
                    "eta_grid": cfg.ETA_GRID,
                    "select_metric": cfg.SELECT_METRIC,
                },
                "best_valid_score": float(best_valid_score),
                "best_valid_metrics": best_valid_metrics,
                "best_eta": float(best_eta),
                "epoch": int(epoch),
            },
            best_model_path
        )

        print(f"保存最优模型: {best_model_path}")
    else:
        patience_counter += 1
        print(f"未提升，patience={patience_counter}/{cfg.PATIENCE}")

        if patience_counter >= cfg.PATIENCE:
            print("Early stopping")
            break

total_train_time = time.time() - start_total

print("\n训练完成")
print(f"Best epoch: {best_epoch}")
print(f"Best eta: {best_eta}")
print(f"Best valid score: {best_valid_score:.6f}")
print(f"Best valid metrics: {best_valid_metrics}")
print(f"Total train time: {total_train_time:.1f}s")

pd.DataFrame(history_logs).to_csv(
    os.path.join(cfg.OUTPUT_DIR, "training_history.csv"),
    index=False
)

# =========================================================
# 12. 加载最优模型并最终评估
# =========================================================

print("\n" + "=" * 90)
print("Step 8: 加载最优模型并最终评估")
print("=" * 90)

checkpoint = torch.load(best_model_path, map_location=device)
model.load_state_dict(checkpoint["model_state_dict"])
model.to(device)

best_eta = float(checkpoint["best_eta"])

print(f"Loaded best epoch: {checkpoint['epoch']}")
print(f"Loaded best eta: {best_eta}")

# -------------------------
# Valid final
# -------------------------
valid_components = predict_components(
    model,
    valid_loader,
    device,
    desc="Final Valid components",
    has_label=True
)

valid_eta_eval = evaluate_eta_grid(
    valid_bias_df,
    valid_components,
    cfg.ETA_GRID,
    select_metric=cfg.SELECT_METRIC
)

# 使用 checkpoint 中保存的 best_eta
valid_logits = (
    valid_components["interest_logits"]
    + best_eta * valid_components["bias_logits"]
)
valid_probs = sigmoid_np(valid_logits)
valid_metrics = evaluate_ranking_metrics(valid_bias_df, valid_probs)

print("\nFinal Valid Metrics:")
print(f"  eta:       {best_eta}")
print(f"  auc:       {valid_metrics['auc']:.6f}")
print(f"  group_auc: {valid_metrics['group_auc']:.6f}")
print(f"  mrr:       {valid_metrics['mrr']:.6f}")
print(f"  ndcg@5:    {valid_metrics['ndcg@5']:.6f}")
print(f"  ndcg@10:   {valid_metrics['ndcg@10']:.6f}")

valid_eta_eval["results_df"].to_csv(
    os.path.join(cfg.OUTPUT_DIR, "final_valid_eta_grid.csv"),
    index=False
)

# -------------------------
# Test final
# -------------------------
test_has_label = "label" in test_bias_df.columns

test_components = predict_components(
    model,
    test_loader,
    device,
    desc="Final Test components",
    has_label=test_has_label
)

test_logits = (
    test_components["interest_logits"]
    + best_eta * test_components["bias_logits"]
)

test_probs = sigmoid_np(test_logits)

if test_has_label:
    test_metrics = evaluate_ranking_metrics(test_bias_df, test_probs)

    print("\nFinal Test Metrics:")
    print(f"  eta:       {best_eta}")
    print(f"  auc:       {test_metrics['auc']:.6f}")
    print(f"  group_auc: {test_metrics['group_auc']:.6f}")
    print(f"  mrr:       {test_metrics['mrr']:.6f}")
    print(f"  ndcg@5:    {test_metrics['ndcg@5']:.6f}")
    print(f"  ndcg@10:   {test_metrics['ndcg@10']:.6f}")

else:
    test_metrics = {
        "auc": None,
        "group_auc": None,
        "mrr": None,
        "ndcg@5": None,
        "ndcg@10": None,
    }

    print("\nFinal Test 无 label，仅保存预测和 submission")

# =========================================================
# 13. 保存预测结果
# =========================================================

print("\n" + "=" * 90)
print("Step 9: 保存预测结果")
print("=" * 90)

valid_pred_cols = [
    c for c in ["impression_id", "user_id", "candidate_news_id", "label"]
    if c in valid_bias_df.columns
]

valid_pred_df = valid_bias_df[valid_pred_cols].copy()
valid_pred_df["pred"] = valid_probs
valid_pred_df["interest_logit"] = valid_components["interest_logits"]
valid_pred_df["bias_logit"] = valid_components["bias_logits"]
valid_pred_df["eta"] = best_eta

test_pred_cols = [
    c for c in ["impression_id", "user_id", "candidate_news_id", "label"]
    if c in test_bias_df.columns
]

test_pred_df = test_bias_df[test_pred_cols].copy()
test_pred_df["pred"] = test_probs
test_pred_df["interest_logit"] = test_components["interest_logits"]
test_pred_df["bias_logit"] = test_components["bias_logits"]
test_pred_df["eta"] = best_eta

valid_pred_path = os.path.join(cfg.OUTPUT_DIR, "valid_predictions_cf_din.csv")
test_pred_path = os.path.join(cfg.OUTPUT_DIR, "test_predictions_cf_din.csv")

valid_pred_df.to_csv(valid_pred_path, index=False)
test_pred_df.to_csv(test_pred_path, index=False)

print(f"Valid predictions saved: {valid_pred_path}")
print(f"Test predictions saved : {test_pred_path}")

# =========================================================
# 14. MIND submission
# =========================================================

def make_mind_submission(pred_df, output_path):
    assert "impression_id" in pred_df.columns
    assert "pred" in pred_df.columns

    lines = []

    for imp_id, group in tqdm(pred_df.groupby("impression_id"), desc="Make submission"):
        preds = group["pred"].values

        order = np.argsort(-preds)
        ranks = np.empty_like(order)
        ranks[order] = np.arange(1, len(preds) + 1)

        rank_str = "[" + ",".join(map(str, ranks.tolist())) + "]"
        lines.append(f"{imp_id} {rank_str}")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"Submission saved: {output_path}")

if "impression_id" in test_pred_df.columns:
    submission_path = os.path.join(cfg.OUTPUT_DIR, "prediction_cf_din.txt")
    make_mind_submission(test_pred_df, submission_path)

# =========================================================
# 15. 保存最终指标
# =========================================================

print("\n" + "=" * 90)
print("Step 10: 保存最终指标")
print("=" * 90)

final_metrics = {
    "method": "CF-DIN / Counterfactual Bias-Decomposed DIN",

    "best_epoch": int(best_epoch),
    "best_eta": float(best_eta),
    "best_valid_score": float(best_valid_score),

    "final_valid_metrics": {
        "auc": float(valid_metrics["auc"]),
        "group_auc": float(valid_metrics["group_auc"]),
        "mrr": float(valid_metrics["mrr"]),
        "ndcg@5": float(valid_metrics["ndcg@5"]),
        "ndcg@10": float(valid_metrics["ndcg@10"]),
    },

    "final_test_metrics": {
        "auc": None if test_metrics["auc"] is None else float(test_metrics["auc"]),
        "group_auc": None if test_metrics["group_auc"] is None else float(test_metrics["group_auc"]),
        "mrr": None if test_metrics["mrr"] is None else float(test_metrics["mrr"]),
        "ndcg@5": None if test_metrics["ndcg@5"] is None else float(test_metrics["ndcg@5"]),
        "ndcg@10": None if test_metrics["ndcg@10"] is None else float(test_metrics["ndcg@10"]),
    },

    "bias_decomposition": {
        "train_bias_alpha": cfg.TRAIN_BIAS_ALPHA,
        "bias_aux_loss_weight": cfg.BIAS_AUX_LOSS_WEIGHT,
        "decouple_loss_weight": cfg.DECOUPLE_LOSS_WEIGHT,
        "eta_grid": cfg.ETA_GRID,
        "select_metric": cfg.SELECT_METRIC,
        "bias_features": BIAS_FEATURES,
        "fit_bias_stats_on_full_train_before_downsampling": True,
    },

    "config": {
        "seed": cfg.SEED,
        "use_negative_downsample": cfg.USE_NEGATIVE_DOWNSAMPLE,
        "neg_pos_ratio": cfg.NEG_POS_RATIO,
        "max_history_len": cfg.MAX_HISTORY_LEN,
        "batch_size": cfg.BATCH_SIZE,
        "epochs": cfg.EPOCHS,
        "lr": cfg.LR,
        "weight_decay": cfg.WEIGHT_DECAY,
        "attention_hidden_dim": cfg.ATTENTION_HIDDEN_DIM,
        "mlp_hidden_dims": cfg.MLP_HIDDEN_DIMS,
        "dropout": cfg.DROPOUT,
        "embedding_dim": embedding_dim,
        "bias_dim": len(BIAS_FEATURES),
        "device": str(device),
        "num_workers": cfg.NUM_WORKERS,
        "fast_test_mode": cfg.USE_FAST_TEST_MODE,
        "train_samples": int(len(train_bias_df)),
        "valid_samples": int(len(valid_bias_df)),
        "test_samples": int(len(test_bias_df)),
    },

    "time": {
        "train_total_time": float(total_train_time)
    }
}

metrics_path = os.path.join(cfg.OUTPUT_DIR, "final_metrics_cf_din.json")

with open(metrics_path, "w", encoding="utf-8") as f:
    json.dump(final_metrics, f, indent=2, ensure_ascii=False)

print(f"Final metrics saved: {metrics_path}")

# =========================================================
# 16. 总结
# =========================================================

print("\n" + "=" * 90)
print("CF-DIN 完成")
print("=" * 90)

print(f"Best epoch: {best_epoch}")
print(f"Best eta: {best_eta}")

print("\nFinal Valid:")
print(f"  auc:       {valid_metrics['auc']:.6f}")
print(f"  group_auc: {valid_metrics['group_auc']:.6f}")
print(f"  mrr:       {valid_metrics['mrr']:.6f}")
print(f"  ndcg@5:    {valid_metrics['ndcg@5']:.6f}")
print(f"  ndcg@10:   {valid_metrics['ndcg@10']:.6f}")

if test_has_label:
    print("\nFinal Test:")
    print(f"  auc:       {test_metrics['auc']:.6f}")
    print(f"  group_auc: {test_metrics['group_auc']:.6f}")
    print(f"  mrr:       {test_metrics['mrr']:.6f}")
    print(f"  ndcg@5:    {test_metrics['ndcg@5']:.6f}")
    print(f"  ndcg@10:   {test_metrics['ndcg@10']:.6f}")
else:
    print("\nFinal Test:")
    print("  无 label，仅保存预测和 submission 文件")

print(f"\nOutput dir: {cfg.OUTPUT_DIR}")
print("=" * 90)