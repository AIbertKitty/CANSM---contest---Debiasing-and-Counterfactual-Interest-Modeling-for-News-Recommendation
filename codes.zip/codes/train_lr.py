
"""
使用 LR 测试跨数据集泛化能力
"""

import os
import json
import random
import numpy as np
import pandas as pd
from tqdm import tqdm
import time

from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
import joblib

# =========================================================
# 0. 配置
# =========================================================

class Config:
    # 数据路径
    EMBEDDINGS_DIR = "your_path/data/embeddings"
    PROCESSED_DIR = "your_path/data/processed"
    OUTPUT_DIR = "./outputs/text_avg_lr"

    TRAIN_PATH = "your_path/data/processed/train_samples.csv"
    VALID_PATH = "your_path/data/processed/valid_samples.csv"
    TEST_PATH = "your_path/data/processed/test_samples.csv"

    NEWS_EMB_PATH = "your_path/data/embeddings/news_embeddings.npy"
    NEWS_MAP_PATH = "your_path/data/embeddings/news_id_to_index.json"

    SEED = 42

    # 负采样参数
    USE_NEGATIVE_DOWNSAMPLE = True
    NEG_POS_RATIO = 4

    # macOS 优化参数
    USE_FAST_TEST_MODE = False      # 快速测试模式（首次运行建议开启）
    FAST_TEST_SAMPLE_SIZE = 10000  # 测试样本数
    
    # LR 参数（自动选择，也可手动指定）
    LR_SOLVER = 'auto'  # 'auto', 'lbfgs', 'saga', 'liblinear'
    LR_C = 1.0
    LR_MAX_ITER = 1000
    LR_PENALTY = 'l2'
    
    # macOS 稳定性优先
    N_JOBS = 1  # 单进程（避免卡死）

cfg = Config()
os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)

# =========================================================
# 1. 随机种子
# =========================================================

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)

set_seed(cfg.SEED)

# =========================================================
# 2. 读取数据
# =========================================================

print("=" * 80)
print("Text-Avg-LR 训练脚本（macOS 优化版）")
print("=" * 80)
print(f"\n配置信息:")
print(f"  快速测试模式: {cfg.USE_FAST_TEST_MODE}")
if cfg.USE_FAST_TEST_MODE:
    print(f"  测试样本数: {cfg.FAST_TEST_SAMPLE_SIZE}")
print(f"  负采样比例: 1:{cfg.NEG_POS_RATIO}")
print(f"  求解器: {cfg.LR_SOLVER}")
print(f"  并行数: {cfg.N_JOBS} (单进程)")

print("\n" + "=" * 80)
print("Step 1: 加载数据")
print("=" * 80)

train_df = pd.read_csv(cfg.TRAIN_PATH)
valid_df = pd.read_csv(cfg.VALID_PATH)
test_df = pd.read_csv(cfg.TEST_PATH)

print(f"\n原始数据规模:")
print(f"  训练集: {len(train_df):,} 样本，点击率: {train_df['label'].mean():.4f}")
print(f"  验证集: {len(valid_df):,} 样本，点击率: {valid_df['label'].mean():.4f}")
print(f"  测试集: {len(test_df):,} 样本，点击率: {test_df['label'].mean():.4f}")

# =========================================================
# 3. 负样本下采样
# =========================================================

def negative_downsample(df, neg_pos_ratio=4, seed=42):
    pos_df = df[df["label"] == 1]
    neg_df = df[df["label"] == 0]
    
    n_pos = len(pos_df)
    n_neg_keep = min(len(neg_df), n_pos * neg_pos_ratio)
    
    neg_sampled = neg_df.sample(n=n_neg_keep, random_state=seed)
    sampled_df = pd.concat([pos_df, neg_sampled], axis=0)
    sampled_df = sampled_df.sample(frac=1.0, random_state=seed).reset_index(drop=True)
    
    return sampled_df

if cfg.USE_NEGATIVE_DOWNSAMPLE:
    print(f"\n负采样 (1:{cfg.NEG_POS_RATIO})...")
    train_df = negative_downsample(train_df, neg_pos_ratio=cfg.NEG_POS_RATIO, seed=cfg.SEED)
    print(f"  训练集: {len(train_df):,} 样本，点击率: {train_df['label'].mean():.4f}")

# =========================================================
# 3.5. 快速测试模式
# =========================================================

if cfg.USE_FAST_TEST_MODE and len(train_df) > cfg.FAST_TEST_SAMPLE_SIZE:
    print("\n" + "=" * 80)
    print("⚠️  快速测试模式")
    print("=" * 80)
    print(f"原始训练集: {len(train_df):,} 样本")
    print(f"采样至: {cfg.FAST_TEST_SAMPLE_SIZE:,} 样本")
    print("提示: 验证代码正常后，设置 USE_FAST_TEST_MODE = False 进行完整训练")
    
    train_df = train_df.sample(n=cfg.FAST_TEST_SAMPLE_SIZE, random_state=cfg.SEED)
    print(f"✓ 已采样 {len(train_df):,} 样本用于快速测试")

# =========================================================
# 4. 加载新闻向量
# =========================================================

print("\n" + "=" * 80)
print("Step 2: 加载新闻 embedding")
print("=" * 80)

news_embeddings = np.load(cfg.NEWS_EMB_PATH).astype(np.float32)

with open(cfg.NEWS_MAP_PATH, "r", encoding="utf-8") as f:
    news_id_to_index = json.load(f)

embedding_dim = news_embeddings.shape[1]

print(f"\n新闻向量信息:")
print(f"  shape: {news_embeddings.shape}")
print(f"  embedding_dim: {embedding_dim}")
print(f"  新闻数量: {len(news_id_to_index):,}")

# =========================================================
# 5. 特征提取函数
# =========================================================

def get_news_vec(news_id, news_embeddings, news_id_to_index, embedding_dim):
    if news_id in news_id_to_index:
        idx = news_id_to_index[news_id]
        return news_embeddings[idx]
    else:
        return np.zeros(embedding_dim, dtype=np.float32)

def get_user_avg_vec(history, news_embeddings, news_id_to_index, embedding_dim, history_cache):
    if pd.isna(history) or history == "" or str(history) == "nan":
        return np.zeros(embedding_dim, dtype=np.float32), 0
    
    history = str(history)
    
    if history in history_cache:
        return history_cache[history]
    
    news_ids = history.split()
    vecs = []
    
    for nid in news_ids:
        if nid in news_id_to_index:
            idx = news_id_to_index[nid]
            vecs.append(news_embeddings[idx])
    
    history_len = len(vecs)
    
    if history_len == 0:
        user_vec = np.zeros(embedding_dim, dtype=np.float32)
    else:
        user_vec = np.mean(vecs, axis=0).astype(np.float32)
    
    result = (user_vec, history_len)
    history_cache[history] = result
    
    return result

def extract_features(df, news_embeddings, news_id_to_index, desc="提取特征"):
    embedding_dim = news_embeddings.shape[1]
    history_cache = {}
    
    X_list = []
    y_list = []
    
    for _, row in tqdm(df.iterrows(), total=len(df), desc=desc):
        history = row["history"]
        candidate_news_id = row["candidate_news_id"]
        label = row["label"]
        
        user_vec, history_len = get_user_avg_vec(
            history, news_embeddings, news_id_to_index, embedding_dim, history_cache
        )
        cand_vec = get_news_vec(candidate_news_id, news_embeddings, news_id_to_index, embedding_dim)
        
        # 余弦相似度
        user_norm = np.linalg.norm(user_vec)
        cand_norm = np.linalg.norm(cand_vec)
        
        if user_norm == 0 or cand_norm == 0:
            sim = 0.0
        else:
            sim = float(np.dot(user_vec, cand_vec) / (user_norm * cand_norm))
        
        # 交互项
        interact_vec = user_vec * cand_vec
        
        # 历史长度 log 变换
        log_history_len = np.log1p(history_len).astype(np.float32)
        
        # 拼接特征
        feature = np.concatenate([
            user_vec,
            cand_vec,
            interact_vec,
            np.array([sim, log_history_len], dtype=np.float32)
        ]).astype(np.float32)
        
        X_list.append(feature)
        y_list.append(label)
    
    X = np.array(X_list, dtype=np.float32)
    y = np.array(y_list, dtype=np.float32)
    
    return X, y

# =========================================================
# 6. 提取特征
# =========================================================

print("\n" + "=" * 80)
print("Step 3: 提取特征")
print("=" * 80)

input_dim = embedding_dim * 3 + 2

print(f"\n特征维度:")
print(f"  user_vec: {embedding_dim}")
print(f"  candidate_vec: {embedding_dim}")
print(f"  interaction_vec: {embedding_dim}")
print(f"  sim + log_history_len: 2")
print(f"  总维度: {input_dim}")

start_time = time.time()

X_train, y_train = extract_features(
    train_df, news_embeddings, news_id_to_index, desc="训练集"
)

X_valid, y_valid = extract_features(
    valid_df, news_embeddings, news_id_to_index, desc="验证集"
)

X_test, y_test = extract_features(
    test_df, news_embeddings, news_id_to_index, desc="测试集"
)

extract_time = time.time() - start_time

print(f"\n✓ 特征提取完成，耗时: {extract_time:.2f} 秒")
print(f"  训练特征: {X_train.shape}, 内存: {X_train.nbytes / 1024 / 1024:.2f} MB")
print(f"  验证特征: {X_valid.shape}, 内存: {X_valid.nbytes / 1024 / 1024:.2f} MB")
print(f"  测试特征: {X_test.shape}, 内存: {X_test.nbytes / 1024 / 1024:.2f} MB")

# =========================================================
# 7. 训练 LR（macOS 优化版）
# =========================================================

print("\n" + "=" * 80)
print("Step 4: 训练 LR")
print("=" * 80)

# 自动选择求解器
if cfg.LR_SOLVER == 'auto':
    if len(X_train) > 100000:
        solver = 'saga'
        max_iter = 100
        print(f"\n自动选择: SAGA 求解器（训练集 > 10万）")
    elif len(X_train) > 50000:
        solver = 'lbfgs'
        max_iter = 1000
        print(f"\n自动选择: L-BFGS 求解器（训练集 > 5万）")
    else:
        solver = 'lbfgs'
        max_iter = 1000
        print(f"\n自动选择: L-BFGS 求解器（训练集较小）")
else:
    solver = cfg.LR_SOLVER
    max_iter = cfg.LR_MAX_ITER
    print(f"\n使用指定求解器: {solver}")

model = LogisticRegression(
    penalty=cfg.LR_PENALTY,
    C=cfg.LR_C,
    max_iter=max_iter,
    solver=solver,
    random_state=cfg.SEED,
    verbose=1,
    n_jobs=cfg.N_JOBS
)

print(f"\nLR 参数:")
print(f"  penalty: {cfg.LR_PENALTY}")
print(f"  C: {cfg.LR_C}")
print(f"  max_iter: {max_iter}")
print(f"  solver: {solver}")
print(f"  n_jobs: {cfg.N_JOBS}")

print(f"\n开始训练...")
print(f"  训练样本: {len(X_train):,}")
print(f"  特征维度: {X_train.shape[1]}")

start_time = time.time()
model.fit(X_train, y_train)
train_time = time.time() - start_time

print(f"\n✓ LR 训练完成，耗时: {train_time:.2f} 秒")

# =========================================================
# 8. 评估
# =========================================================

print("\n" + "=" * 80)
print("Step 5: 评估")
print("=" * 80)

print("\n计算 AUC...")

# 训练集
y_train_probs = model.predict_proba(X_train)[:, 1]
train_auc = roc_auc_score(y_train, y_train_probs)

# 验证集
y_valid_probs = model.predict_proba(X_valid)[:, 1]
valid_auc = roc_auc_score(y_valid, y_valid_probs)

# 测试集
y_test_probs = model.predict_proba(X_test)[:, 1]
test_auc = roc_auc_score(y_test, y_test_probs)

print(f"\nAUC 结果:")
print(f"  Train AUC: {train_auc:.5f}")
print(f"  Valid AUC: {valid_auc:.5f}")
print(f"  Test AUC: {test_auc:.5f}")

# =========================================================
# 9. 排序指标
# =========================================================

def dcg_score(labels):
    labels = np.asarray(labels)
    gains = (2 ** labels - 1)
    discounts = np.log2(np.arange(len(labels)) + 2)
    return np.sum(gains / discounts)

def ndcg_score(labels, k=None):
    labels = np.asarray(labels)
    if k is not None:
        labels = labels[:k]
    
    dcg = dcg_score(labels)
    ideal = np.sort(labels)[::-1]
    if k is not None:
        ideal = ideal[:k]
    
    idcg = dcg_score(ideal)
    if idcg == 0:
        return 0.0
    
    return dcg / idcg

def mrr_score(labels):
    labels = np.asarray(labels)
    pos_indices = np.where(labels == 1)[0]
    if len(pos_indices) == 0:
        return 0.0
    return 1.0 / (pos_indices[0] + 1)

def evaluate_ranking_metrics(df, probs):
    eval_df = df.copy()
    eval_df["pred"] = probs
    
    auc_list = []
    mrr_list = []
    ndcg5_list = []
    ndcg10_list = []
    
    for imp_id, group in tqdm(eval_df.groupby("impression_id"), desc="排序指标"):
        labels = group["label"].values
        preds = group["pred"].values
        
        if len(np.unique(labels)) > 1:
            auc_list.append(roc_auc_score(labels, preds))
        
        order = np.argsort(-preds)
        sorted_labels = labels[order]
        
        mrr_list.append(mrr_score(sorted_labels))
        ndcg5_list.append(ndcg_score(sorted_labels, k=5))
        ndcg10_list.append(ndcg_score(sorted_labels, k=10))
    
    metrics = {
        "group_auc": float(np.mean(auc_list)) if len(auc_list) > 0 else 0.0,
        "mrr": float(np.mean(mrr_list)),
        "ndcg@5": float(np.mean(ndcg5_list)),
        "ndcg@10": float(np.mean(ndcg10_list)),
    }
    
    return metrics

print("\n计算验证集排序指标...")
valid_ranking_metrics = evaluate_ranking_metrics(valid_df, y_valid_probs)

print("\n计算测试集排序指标...")
test_ranking_metrics = evaluate_ranking_metrics(test_df, y_test_probs)

print("\n验证集排序指标:")
for k, v in valid_ranking_metrics.items():
    print(f"  {k}: {v:.5f}")

print("\n测试集排序指标:")
for k, v in test_ranking_metrics.items():
    print(f"  {k}: {v:.5f}")

# =========================================================
# 10. 保存结果
# =========================================================

print("\n" + "=" * 80)
print("Step 6: 保存模型和结果")
print("=" * 80)

# 保存模型
best_model_path = os.path.join(cfg.OUTPUT_DIR, "best_text_avg_lr.pkl")
joblib.dump(model, best_model_path)
print(f"✓ 模型已保存: {best_model_path}")

# 保存预测结果
valid_pred_df = valid_df[["impression_id", "user_id", "candidate_news_id", "label"]].copy()
valid_pred_df["pred"] = y_valid_probs

test_pred_df = test_df[["impression_id", "user_id", "candidate_news_id", "label"]].copy()
test_pred_df["pred"] = y_test_probs

valid_pred_path = os.path.join(cfg.OUTPUT_DIR, "valid_predictions.csv")
test_pred_path = os.path.join(cfg.OUTPUT_DIR, "test_predictions.csv")

valid_pred_df.to_csv(valid_pred_path, index=False)
test_pred_df.to_csv(test_pred_path, index=False)

print(f"✓ 验证集预测: {valid_pred_path}")
print(f"✓ 测试集预测: {test_pred_path}")

# 保存最终指标
final_metrics = {
    "train_auc": float(train_auc),
    "valid_auc": float(valid_auc),
    "test_auc": float(test_auc),
    "valid_ranking_metrics": valid_ranking_metrics,
    "test_ranking_metrics": test_ranking_metrics,
    "config": {
        "lr_c": cfg.LR_C,
        "lr_penalty": cfg.LR_PENALTY,
        "lr_max_iter": max_iter,
        "lr_solver": solver,
        "use_negative_downsample": cfg.USE_NEGATIVE_DOWNSAMPLE,
        "neg_pos_ratio": cfg.NEG_POS_RATIO,
        "input_dim": input_dim,
        "embedding_dim": embedding_dim,
        "n_jobs": cfg.N_JOBS,
        "fast_test_mode": cfg.USE_FAST_TEST_MODE,
        "train_samples": len(X_train),
    },
    "time": {
        "feature_extraction": float(extract_time),
        "training": float(train_time),
        "total": float(extract_time + train_time),
    }
}

metrics_path = os.path.join(cfg.OUTPUT_DIR, "final_metrics.json")
with open(metrics_path, "w", encoding="utf-8") as f:
    json.dump(final_metrics, f, indent=2, ensure_ascii=False)

print(f"✓ 最终指标: {metrics_path}")

# =========================================================
# 11. 总结
# =========================================================

print("\n" + "=" * 80)
print("✓ Text-Avg-LR 训练完成")
print("=" * 80)

print(f"\n最终结果:")
print(f"  Train AUC: {train_auc:.5f}")
print(f"  Valid AUC: {valid_auc:.5f}")
print(f"  Test AUC: {test_auc:.5f}")

print(f"\n时间统计:")
print(f"  特征提取: {extract_time:.2f} 秒")
print(f"  模型训练: {train_time:.2f} 秒")
print(f"  总耗时: {extract_time + train_time:.2f} 秒")

if cfg.USE_FAST_TEST_MODE:
    print(f"\n⚠️  当前为快速测试模式")
    print(f"如需完整训练，请修改配置:")
    print(f"  Config.USE_FAST_TEST_MODE = False")

print("\n" + "=" * 80)