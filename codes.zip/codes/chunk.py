import pandas as pd
import json

# ============================================
# 1. 读取数据
# ============================================

behaviors_cols = ['impression_id', 'user_id', 'time', 'history', 'impressions']
behaviors = pd.read_csv(
    'your_path/data/MINDsmall_train/behaviors.tsv', sep='\t', names=behaviors_cols)

# 解析时间
behaviors['time'] = pd.to_datetime(behaviors['time'])

print(f"Total impressions: {len(behaviors)}")
print(f"Time range: {behaviors['time'].min()} to {behaviors['time'].max()}")
print(
    f"Time span: {(behaviors['time'].max() - behaviors['time'].min()).days} days")

# ============================================
# 2. 时间切分
# ============================================

# 按时间排序
behaviors = behaviors.sort_values('time').reset_index(drop=True)

# 计算分位点
time_80 = behaviors['time'].quantile(0.80)
time_90 = behaviors['time'].quantile(0.90)

# 划分
train_behaviors = behaviors[behaviors['time'] < time_80].copy()
valid_behaviors = behaviors[(behaviors['time'] >= time_80) & (
    behaviors['time'] < time_90)].copy()
test_behaviors = behaviors[behaviors['time'] >= time_90].copy()

print("\n=== Time-based Split ===")
print(f"Train: {len(train_behaviors)} impressions ({len(train_behaviors)/len(behaviors)*100:.1f}%)")
print(
    f"  Time: {train_behaviors['time'].min()} to {train_behaviors['time'].max()}")
print(f"Valid: {len(valid_behaviors)} impressions ({len(valid_behaviors)/len(behaviors)*100:.1f}%)")
print(
    f"  Time: {valid_behaviors['time'].min()} to {valid_behaviors['time'].max()}")
print(f"Test: {len(test_behaviors)} impressions ({len(test_behaviors)/len(behaviors)*100:.1f}%)")
print(
    f"  Time: {test_behaviors['time'].min()} to {test_behaviors['time'].max()}")

# ============================================
# 3. 展开样本
# ============================================


def expand_impressions(behaviors_df):
    """展开impressions为user-news-label样本"""
    samples = []

    for idx, row in behaviors_df.iterrows():
        impression_id = row['impression_id']
        user_id = row['user_id']
        time = row['time']
        history = row['history'] if pd.notna(row['history']) else ''
        impressions = str(row['impressions']).split()

        for imp in impressions:
            if '-' not in imp:
                continue
            news_id, label = imp.split('-')
            samples.append({
                'impression_id': impression_id,
                'user_id': user_id,
                'time': time,
                'history': history,
                'candidate_news_id': news_id,
                'label': int(label)
            })

    return pd.DataFrame(samples)


print("\n=== Expanding samples ===")
train_samples = expand_impressions(train_behaviors)
valid_samples = expand_impressions(valid_behaviors)
test_samples = expand_impressions(test_behaviors)

print(f"Train samples: {len(train_samples)}")
print(
    f"  Positive: {train_samples['label'].sum()} ({train_samples['label'].mean()*100:.2f}%)")
print(f"Valid samples: {len(valid_samples)}")
print(
    f"  Positive: {valid_samples['label'].sum()} ({valid_samples['label'].mean()*100:.2f}%)")
print(f"Test samples: {len(test_samples)}")
print(
    f"  Positive: {test_samples['label'].sum()} ({test_samples['label'].mean()*100:.2f}%)")

# ============================================
# 4. 新新闻分析
# ============================================

train_news_set = set(train_samples['candidate_news_id'])
valid_news_set = set(valid_samples['candidate_news_id'])
test_news_set = set(test_samples['candidate_news_id'])

new_news_in_valid = valid_news_set - train_news_set
new_news_in_test = test_news_set - train_news_set

print("\n=== New News Analysis ===")
print(f"Train unique news: {len(train_news_set)}")
print(f"Valid unique news: {len(valid_news_set)}")
print(
    f"  New in valid: {len(new_news_in_valid)} ({len(new_news_in_valid)/len(valid_news_set)*100:.1f}%)")
print(f"Test unique news: {len(test_news_set)}")
print(
    f"  New in test: {len(new_news_in_test)} ({len(new_news_in_test)/len(test_news_set)*100:.1f}%)")

# 构造新新闻验证集
new_doc_valid = valid_samples[valid_samples['candidate_news_id'].isin(
    new_news_in_valid)].copy()
seen_doc_valid = valid_samples[~valid_samples['candidate_news_id'].isin(
    new_news_in_valid)].copy()

print(
    f"\nNewDoc validation samples: {len(new_doc_valid)} ({len(new_doc_valid)/len(valid_samples)*100:.1f}%)")
print(f"  Positive rate: {new_doc_valid['label'].mean()*100:.2f}%")
print(
    f"SeenDoc validation samples: {len(seen_doc_valid)} ({len(seen_doc_valid)/len(valid_samples)*100:.1f}%)")
print(f"  Positive rate: {seen_doc_valid['label'].mean()*100:.2f}%")

# ============================================
# 5. 长尾新闻分析
# ============================================

train_news_counts = train_samples['candidate_news_id'].value_counts()

# 定义长尾：曝光次数后30%
tail_threshold = train_news_counts.quantile(0.30)
tail_news_ids = set(
    train_news_counts[train_news_counts <= tail_threshold].index)

print("\n=== Tail News Analysis ===")
print(f"Tail threshold: exposure <= {tail_threshold}")
print(
    f"Tail news count: {len(tail_news_ids)} ({len(tail_news_ids)/len(train_news_set)*100:.1f}%)")

# 构造长尾验证集
tail_valid = valid_samples[valid_samples['candidate_news_id'].isin(
    tail_news_ids)].copy()
head_valid = valid_samples[~valid_samples['candidate_news_id'].isin(
    tail_news_ids)].copy()

print(
    f"Tail validation samples: {len(tail_valid)} ({len(tail_valid)/len(valid_samples)*100:.1f}%)")
print(f"  Positive rate: {tail_valid['label'].mean()*100:.2f}%")
print(
    f"Head validation samples: {len(head_valid)} ({len(head_valid)/len(valid_samples)*100:.1f}%)")
print(f"  Positive rate: {head_valid['label'].mean()*100:.2f}%")

# ============================================
# 6. 低活跃用户分析
# ============================================


def get_history_length(history_str):
    if pd.isna(history_str) or history_str == '':
        return 0
    return len(str(history_str).split())


train_samples['history_len'] = train_samples['history'].apply(
    get_history_length)
valid_samples['history_len'] = valid_samples['history'].apply(
    get_history_length)

# 定义低活跃：历史长度 <= 5
low_active_valid = valid_samples[valid_samples['history_len'] <= 5].copy()
high_active_valid = valid_samples[valid_samples['history_len'] > 5].copy()

print("\n=== User Activity Analysis ===")
print(
    f"Low-active validation (history<=5): {len(low_active_valid)} ({len(low_active_valid)/len(valid_samples)*100:.1f}%)")
print(f"  Positive rate: {low_active_valid['label'].mean()*100:.2f}%")
print(
    f"High-active validation (history>5): {len(high_active_valid)} ({len(high_active_valid)/len(valid_samples)*100:.1f}%)")
print(f"  Positive rate: {high_active_valid['label'].mean()*100:.2f}%")

# ============================================
# 7. 保存切分结果
# ============================================

train_samples.to_csv(
    '/your_path/data/processed/train_samples.csv', index=False)
valid_samples.to_csv(
    '/your_path/data/processed/valid_samples.csv', index=False)
test_samples.to_csv(
    '/your_path/data/processed/test_samples.csv', index=False)

new_doc_valid.to_csv(
    '/your_path/data/processed/new_doc_valid.csv', index=False)
tail_valid.to_csv(
    '/your_path/data/processed/tail_valid.csv', index=False)
low_active_valid.to_csv(
    '/your_path/data/processed/low_active_valid.csv', index=False)

# 保存切分信息
split_info = {
    'train': {
        'impressions': len(train_behaviors),
        'samples': len(train_samples),
        'positive_rate': float(train_samples['label'].mean()),
        'time_start': str(train_behaviors['time'].min()),
        'time_end': str(train_behaviors['time'].max())
    },
    'valid': {
        'impressions': len(valid_behaviors),
        'samples': len(valid_samples),
        'positive_rate': float(valid_samples['label'].mean()),
        'time_start': str(valid_behaviors['time'].min()),
        'time_end': str(valid_behaviors['time'].max())
    },
    'test': {
        'impressions': len(test_behaviors),
        'samples': len(test_samples),
        'positive_rate': float(test_samples['label'].mean()),
        'time_start': str(test_behaviors['time'].min()),
        'time_end': str(test_behaviors['time'].max())
    },
    'new_doc_valid': {
        'samples': len(new_doc_valid),
        'ratio': float(len(new_doc_valid)/len(valid_samples))
    },
    'tail_valid': {
        'samples': len(tail_valid),
        'ratio': float(len(tail_valid)/len(valid_samples))
    },
    'low_active_valid': {
        'samples': len(low_active_valid),
        'ratio': float(len(low_active_valid)/len(valid_samples))
    }
}

with open('your_path/data/processed/split_info.json', 'w') as f:
    json.dump(split_info, f, indent=2)

print("\n=== Split completed and saved ===")
print("Files saved:")
print("  - train_samples.csv")
print("  - valid_samples.csv")
print("  - test_samples.csv")
print("  - new_doc_valid.csv")
print("  - tail_valid.csv")
print("  - low_active_valid.csv")
print("  - split_info.json")