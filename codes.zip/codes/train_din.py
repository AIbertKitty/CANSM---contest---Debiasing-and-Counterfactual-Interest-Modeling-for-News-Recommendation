"""
DIN-lite baseline for macOS 13 + Apple M2 Pro

功能：
1. 使用普通 DIN-lite 训练点击预测模型；
2. 不使用 IPS 权重；
3. 与 IPS-DIN 输出相同评测指标：
   - auc
   - group_auc
   - mrr
   - ndcg@5
   - ndcg@10
4. 适配 macOS M2 Pro 的 MPS 后端。
"""

import os
import json
import time
import random
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from tqdm import tqdm

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

from sklearn.metrics import roc_auc_score

# =========================================================
# 0. 配置
# =========================================================

class Config:
    # =====================================================
    # 数据路径：按你的本地路径设置
    # =====================================================
    EMBEDDINGS_DIR = "your_path/data/embeddings"
    PROCESSED_DIR = "your_path/data/processed"

    TRAIN_PATH = "your_path/data/processed/train_samples.csv"
    VALID_PATH = "your_path/data/processed/valid_samples.csv"
    TEST_PATH = "your_path/data/processed/test_samples.csv"

    NEWS_EMB_PATH = "your_path/data/embeddings/news_embeddings.npy"
    NEWS_MAP_PATH = "your_path/data/embeddings/news_id_to_index.json"

    OUTPUT_DIR = "./outputs/din_lite_macos_m2"

    # =====================================================
    # 随机种子
    # =====================================================
    SEED = 42

    # =====================================================
    # 负采样参数：需要与 IPS-DIN 保持一致
    # =====================================================
    USE_NEGATIVE_DOWNSAMPLE = True
    NEG_POS_RATIO = 4

    # =====================================================
    # 快速测试模式
    # =====================================================
    USE_FAST_TEST_MODE = False
    FAST_TEST_SAMPLE_SIZE = 50000

    # =====================================================
    # DIN-lite 参数：需要与 IPS-DIN 保持一致
    # =====================================================
    MAX_HISTORY_LEN = 50
    BATCH_SIZE = 256          # M2 Pro 建议 128/256/512，根据内存调整
    NUM_WORKERS = 0           # macOS 建议 0，避免多进程卡死

    ATTENTION_HIDDEN_DIM = 64
    MLP_HIDDEN_DIMS = [256, 128, 64]
    DROPOUT = 0.2

    EPOCHS = 8
    LR = 1e-3
    WEIGHT_DECAY = 1e-5
    PATIENCE = 2

    # =====================================================
    # 设备配置
    # =====================================================
    USE_MPS = True

cfg = Config()
os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)

# =========================================================
# 1. 随机种子和设备
# =========================================================

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

set_seed(cfg.SEED)

def get_device():
    if cfg.USE_MPS and torch.backends.mps.is_available():
        return torch.device("mps")
    elif torch.cuda.is_available():
        return torch.device("cuda")
    else:
        return torch.device("cpu")

device = get_device()

print("=" * 90)
print("DIN-lite baseline - macOS M2 Pro version")
print("=" * 90)
print(f"Device: {device}")
print(f"Output dir: {cfg.OUTPUT_DIR}")

if device.type == "mps":
    print("使用 Apple Silicon MPS 后端")
elif device.type == "cuda":
    print(f"使用 CUDA: {torch.cuda.get_device_name(0)}")
else:
    print("使用 CPU")

# =========================================================
# 2. 读取数据
# =========================================================

print("\n" + "=" * 90)
print("Step 1: 加载数据")
print("=" * 90)

train_df = pd.read_csv(cfg.TRAIN_PATH)
valid_df = pd.read_csv(cfg.VALID_PATH)
test_df = pd.read_csv(cfg.TEST_PATH)

print(f"原始 train: {len(train_df):,}, CTR={train_df['label'].mean():.5f}")
print(f"原始 valid: {len(valid_df):,}, CTR={valid_df['label'].mean():.5f}")

if "label" in test_df.columns:
    print(f"原始 test : {len(test_df):,}, CTR={test_df['label'].mean():.5f}")
else:
    print(f"原始 test : {len(test_df):,}, 无 label")

required_cols = ["user_id", "candidate_news_id", "history"]
for col in required_cols:
    assert col in train_df.columns, f"train_df 缺少必要列: {col}"

assert "label" in train_df.columns, "train_df 必须包含 label"
assert "label" in valid_df.columns, "valid_df 必须包含 label"

# =========================================================
# 3. 负采样
# =========================================================

def negative_downsample(df, neg_pos_ratio=4, seed=42):
    pos_df = df[df["label"] == 1]
    neg_df = df[df["label"] == 0]

    n_pos = len(pos_df)
    n_neg_keep = min(len(neg_df), n_pos * neg_pos_ratio)

    neg_sampled = neg_df.sample(n=n_neg_keep, random_state=seed)
    sampled_df = pd.concat([pos_df, neg_sampled], axis=0)
    sampled_df = sampled_df.sample(frac=1.0, random_state=seed).reset_index(drop=True)

    return sampled_df

if cfg.USE_NEGATIVE_DOWNSAMPLE:
    print("\n执行负采样")
    print(f"负采样比例: 1:{cfg.NEG_POS_RATIO}")
    train_df = negative_downsample(
        train_df,
        neg_pos_ratio=cfg.NEG_POS_RATIO,
        seed=cfg.SEED
    )
    print(f"采样后 train: {len(train_df):,}, CTR={train_df['label'].mean():.5f}")

if cfg.USE_FAST_TEST_MODE:
    print("\n⚠️ 当前为快速测试模式")
    if len(train_df) > cfg.FAST_TEST_SAMPLE_SIZE:
        train_df = train_df.sample(
            n=cfg.FAST_TEST_SAMPLE_SIZE,
            random_state=cfg.SEED
        ).reset_index(drop=True)
    print(f"快速测试 train: {len(train_df):,}, CTR={train_df['label'].mean():.5f}")

# =========================================================
# 4. 加载新闻 embedding
# =========================================================

print("\n" + "=" * 90)
print("Step 2: 加载新闻 embedding")
print("=" * 90)

news_embeddings = np.load(cfg.NEWS_EMB_PATH).astype(np.float32)

with open(cfg.NEWS_MAP_PATH, "r", encoding="utf-8") as f:
    news_id_to_index = json.load(f)

embedding_dim = news_embeddings.shape[1]

print(f"news_embeddings shape: {news_embeddings.shape}")
print(f"embedding_dim: {embedding_dim}")
print(f"news_id_to_index size: {len(news_id_to_index):,}")

# =========================================================
# 5. Dataset
# =========================================================

print("\n" + "=" * 90)
print("Step 3: 构造 Dataset / DataLoader")
print("=" * 90)

class DINLiteDataset(Dataset):
    def __init__(
        self,
        df,
        news_embeddings,
        news_id_to_index,
        max_history_len=50,
        has_label=True
    ):
        self.df = df.reset_index(drop=True)
        self.news_embeddings = news_embeddings
        self.news_id_to_index = news_id_to_index
        self.max_history_len = max_history_len
        self.has_label = has_label
        self.embedding_dim = news_embeddings.shape[1]

    def __len__(self):
        return len(self.df)

    def _get_vec(self, news_id):
        if news_id in self.news_id_to_index:
            idx = self.news_id_to_index[news_id]
            return self.news_embeddings[idx]
        return np.zeros(self.embedding_dim, dtype=np.float32)

    def _get_history_vecs_and_mask(self, history):
        history_vecs = np.zeros(
            (self.max_history_len, self.embedding_dim),
            dtype=np.float32
        )
        history_mask = np.zeros(self.max_history_len, dtype=np.float32)

        if pd.isna(history) or str(history) == "" or str(history) == "nan":
            return history_vecs, history_mask, 0

        news_ids = str(history).split()

        # 保留最近 max_history_len 条历史
        news_ids = news_ids[-self.max_history_len:]

        real_len = 0
        for i, nid in enumerate(news_ids):
            if nid in self.news_id_to_index:
                idx = self.news_id_to_index[nid]
                history_vecs[i] = self.news_embeddings[idx]
                history_mask[i] = 1.0
                real_len += 1

        return history_vecs, history_mask, real_len

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        candidate_news_id = row["candidate_news_id"]
        history = row["history"]

        candidate_vec = self._get_vec(candidate_news_id).astype(np.float32)
        history_vecs, history_mask, real_history_len = self._get_history_vecs_and_mask(history)

        log_history_len = np.log1p(real_history_len).astype(np.float32)

        item = {
            "candidate_vec": torch.tensor(candidate_vec, dtype=torch.float32),
            "history_vecs": torch.tensor(history_vecs, dtype=torch.float32),
            "history_mask": torch.tensor(history_mask, dtype=torch.float32),
            "log_history_len": torch.tensor([log_history_len], dtype=torch.float32),
        }

        if self.has_label and "label" in row:
            item["label"] = torch.tensor(row["label"], dtype=torch.float32)
        else:
            item["label"] = torch.tensor(0.0, dtype=torch.float32)

        return item

train_dataset = DINLiteDataset(
    train_df,
    news_embeddings,
    news_id_to_index,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=True
)

valid_dataset = DINLiteDataset(
    valid_df,
    news_embeddings,
    news_id_to_index,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=True
)

test_dataset = DINLiteDataset(
    test_df,
    news_embeddings,
    news_id_to_index,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=("label" in test_df.columns)
)

train_loader = DataLoader(
    train_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=True,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

valid_loader = DataLoader(
    valid_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

test_loader = DataLoader(
    test_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

print(f"train batches: {len(train_loader)}")
print(f"valid batches: {len(valid_loader)}")
print(f"test batches : {len(test_loader)}")

# =========================================================
# 6. 定义 DIN-lite 模型
# =========================================================

print("\n" + "=" * 90)
print("Step 4: 定义 DIN-lite 模型")
print("=" * 90)

class AttentionLayer(nn.Module):
    """
    DIN Attention:
    根据候选新闻 candidate_vec 动态计算历史新闻的注意力权重。
    """
    def __init__(self, embedding_dim, attention_hidden_dim=64):
        super().__init__()

        input_dim = embedding_dim * 4

        self.attention_mlp = nn.Sequential(
            nn.Linear(input_dim, attention_hidden_dim),
            nn.ReLU(),
            nn.Linear(attention_hidden_dim, attention_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(attention_hidden_dim // 2, 1)
        )

    def forward(self, history_vecs, candidate_vec, history_mask):
        """
        history_vecs: [B, H, D]
        candidate_vec: [B, D]
        history_mask: [B, H]
        """
        B, H, D = history_vecs.shape

        candidate_expand = candidate_vec.unsqueeze(1).expand(-1, H, -1)

        attention_input = torch.cat(
            [
                history_vecs,
                candidate_expand,
                history_vecs * candidate_expand,
                torch.abs(history_vecs - candidate_expand)
            ],
            dim=-1
        )

        scores = self.attention_mlp(attention_input).squeeze(-1)  # [B, H]

        # padding mask
        scores = scores.masked_fill(history_mask <= 0, -1e9)

        weights = torch.softmax(scores, dim=1)

        # 防止全空 history 导致异常影响
        weights = weights * history_mask
        weights_sum = weights.sum(dim=1, keepdim=True) + 1e-8
        weights = weights / weights_sum

        user_vec = torch.sum(
            history_vecs * weights.unsqueeze(-1),
            dim=1
        )

        return user_vec, weights

class DINLite(nn.Module):
    """
    普通 DIN-lite 模型。

    输入：
    - candidate_vec
    - history_vecs
    - history_mask
    - log_history_len

    拼接特征：
    - user_vec
    - candidate_vec
    - user_vec * candidate_vec
    - cosine_similarity
    - log_history_len

    MLP 输入维度：
    embedding_dim * 3 + 2
    """
    def __init__(
        self,
        embedding_dim,
        attention_hidden_dim=64,
        mlp_hidden_dims=[256, 128, 64],
        dropout=0.2
    ):
        super().__init__()

        self.embedding_dim = embedding_dim
        self.attention = AttentionLayer(
            embedding_dim=embedding_dim,
            attention_hidden_dim=attention_hidden_dim
        )

        mlp_input_dim = embedding_dim * 3 + 2

        layers = []
        prev_dim = mlp_input_dim

        for hidden_dim in mlp_hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev_dim = hidden_dim

        # 输出 logits，不在模型内部 sigmoid
        layers.append(nn.Linear(prev_dim, 1))

        self.mlp = nn.Sequential(*layers)

    def forward(self, candidate_vec, history_vecs, history_mask, log_history_len):
        user_vec, attention_weights = self.attention(
            history_vecs=history_vecs,
            candidate_vec=candidate_vec,
            history_mask=history_mask
        )

        interaction_vec = user_vec * candidate_vec

        user_norm = torch.norm(user_vec, dim=1, keepdim=True)
        cand_norm = torch.norm(candidate_vec, dim=1, keepdim=True)

        cosine_sim = torch.sum(user_vec * candidate_vec, dim=1, keepdim=True) / (
            user_norm * cand_norm + 1e-8
        )

        x = torch.cat(
            [
                user_vec,
                candidate_vec,
                interaction_vec,
                cosine_sim,
                log_history_len
            ],
            dim=1
        )

        logits = self.mlp(x).squeeze(-1)

        return logits

model = DINLite(
    embedding_dim=embedding_dim,
    attention_hidden_dim=cfg.ATTENTION_HIDDEN_DIM,
    mlp_hidden_dims=cfg.MLP_HIDDEN_DIMS,
    dropout=cfg.DROPOUT
).to(device)

print(model)
print(f"可训练参数量: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

# =========================================================
# 7. 训练和预测函数
# =========================================================

def move_batch_to_device(batch, device):
    return {
        k: v.to(device)
        for k, v in batch.items()
    }

def train_one_epoch(model, loader, optimizer, device):
    model.train()

    total_loss = 0.0
    total_samples = 0

    all_probs = []
    all_labels = []

    for batch in tqdm(loader, desc="Train", leave=False):
        batch = move_batch_to_device(batch, device)

        candidate_vec = batch["candidate_vec"]
        history_vecs = batch["history_vecs"]
        history_mask = batch["history_mask"]
        log_history_len = batch["log_history_len"]
        labels = batch["label"]

        optimizer.zero_grad(set_to_none=True)

        logits = model(
            candidate_vec,
            history_vecs,
            history_mask,
            log_history_len
        )

        loss = F.binary_cross_entropy_with_logits(
            logits,
            labels,
            reduction="mean"
        )

        loss.backward()
        optimizer.step()

        batch_size = labels.size(0)
        total_loss += loss.item() * batch_size
        total_samples += batch_size

        probs = torch.sigmoid(logits).detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()

        all_probs.append(probs)
        all_labels.append(labels_np)

    avg_loss = total_loss / max(total_samples, 1)

    all_probs = np.concatenate(all_probs)
    all_labels = np.concatenate(all_labels)

    try:
        auc = roc_auc_score(all_labels, all_probs)
    except Exception:
        auc = 0.0

    return avg_loss, auc

@torch.no_grad()
def predict(model, loader, device, desc="Predict", has_label=True):
    model.eval()

    all_probs = []
    all_labels = []

    total_loss = 0.0
    total_samples = 0

    for batch in tqdm(loader, desc=desc, leave=False):
        batch = move_batch_to_device(batch, device)

        candidate_vec = batch["candidate_vec"]
        history_vecs = batch["history_vecs"]
        history_mask = batch["history_mask"]
        log_history_len = batch["log_history_len"]
        labels = batch["label"]

        logits = model(
            candidate_vec,
            history_vecs,
            history_mask,
            log_history_len
        )

        probs = torch.sigmoid(logits).detach().cpu().numpy()

        all_probs.append(probs)

        if has_label:
            loss = F.binary_cross_entropy_with_logits(
                logits,
                labels,
                reduction="mean"
            )

            labels_np = labels.detach().cpu().numpy()
            all_labels.append(labels_np)

            batch_size = labels.size(0)
            total_loss += loss.item() * batch_size
            total_samples += batch_size

    all_probs = np.concatenate(all_probs)

    if has_label:
        all_labels = np.concatenate(all_labels)
        avg_loss = total_loss / max(total_samples, 1)

        try:
            auc = roc_auc_score(all_labels, all_probs)
        except Exception:
            auc = 0.0

        return all_probs, all_labels, avg_loss, auc

    else:
        return all_probs, None, None, None

# =========================================================
# 8. 排序指标：与 IPS-DIN 对齐
# =========================================================

def dcg_score(labels):
    labels = np.asarray(labels)
    gains = (2 ** labels - 1)
    discounts = np.log2(np.arange(len(labels)) + 2)
    return np.sum(gains / discounts)

def ndcg_score(labels, k=None):
    labels = np.asarray(labels)

    if k is not None:
        labels = labels[:k]

    dcg = dcg_score(labels)

    ideal = np.sort(labels)[::-1]
    if k is not None:
        ideal = ideal[:k]

    idcg = dcg_score(ideal)

    if idcg == 0:
        return 0.0

    return dcg / idcg

def mrr_score(labels):
    labels = np.asarray(labels)
    pos_indices = np.where(labels == 1)[0]

    if len(pos_indices) == 0:
        return 0.0

    return 1.0 / (pos_indices[0] + 1)

def evaluate_ranking_metrics(df, probs):
    """
    与 IPS-DIN 相同的 ranking metrics:
    - group_auc
    - mrr
    - ndcg@5
    - ndcg@10
    """
    eval_df = df.copy()
    eval_df["pred"] = probs

    auc_list = []
    mrr_list = []
    ndcg5_list = []
    ndcg10_list = []

    if "impression_id" not in eval_df.columns:
        print("⚠️ 缺少 impression_id，无法计算 group ranking metrics")
        return {
            "group_auc": 0.0,
            "mrr": 0.0,
            "ndcg@5": 0.0,
            "ndcg@10": 0.0,
        }

    if "label" not in eval_df.columns:
        print("⚠️ 缺少 label，无法计算 ranking metrics")
        return {
            "group_auc": None,
            "mrr": None,
            "ndcg@5": None,
            "ndcg@10": None,
        }

    for imp_id, group in tqdm(eval_df.groupby("impression_id"), desc="Ranking metrics", leave=False):
        labels = group["label"].values
        preds = group["pred"].values

        if len(np.unique(labels)) > 1:
            auc_list.append(roc_auc_score(labels, preds))

        order = np.argsort(-preds)
        sorted_labels = labels[order]

        mrr_list.append(mrr_score(sorted_labels))
        ndcg5_list.append(ndcg_score(sorted_labels, k=5))
        ndcg10_list.append(ndcg_score(sorted_labels, k=10))

    metrics = {
        "group_auc": float(np.mean(auc_list)) if len(auc_list) > 0 else 0.0,
        "mrr": float(np.mean(mrr_list)) if len(mrr_list) > 0 else 0.0,
        "ndcg@5": float(np.mean(ndcg5_list)) if len(ndcg5_list) > 0 else 0.0,
        "ndcg@10": float(np.mean(ndcg10_list)) if len(ndcg10_list) > 0 else 0.0,
    }

    return metrics

# =========================================================
# 9. 训练 DIN-lite
# =========================================================

print("\n" + "=" * 90)
print("Step 5: 开始训练 DIN-lite")
print("=" * 90)

optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=cfg.LR,
    weight_decay=cfg.WEIGHT_DECAY
)

scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer,
    mode="max",
    factor=0.5,
    patience=1
)

best_valid_auc = 0.0
best_epoch = -1
patience_counter = 0

history_logs = []

best_model_path = os.path.join(cfg.OUTPUT_DIR, "best_din_lite.pt")

start_total = time.time()

for epoch in range(1, cfg.EPOCHS + 1):
    print("\n" + "-" * 90)
    print(f"Epoch {epoch}/{cfg.EPOCHS}")
    print("-" * 90)

    start_epoch = time.time()

    train_loss, train_auc = train_one_epoch(
        model,
        train_loader,
        optimizer,
        device
    )

    valid_probs, valid_labels, valid_loss, valid_auc = predict(
        model,
        valid_loader,
        device,
        desc="Valid",
        has_label=True
    )

    scheduler.step(valid_auc)

    epoch_time = time.time() - start_epoch

    log = {
        "epoch": int(epoch),
        "train_loss": float(train_loss),
        "train_auc": float(train_auc),
        "valid_loss": float(valid_loss),
        "valid_auc": float(valid_auc),
        "lr": float(optimizer.param_groups[0]["lr"]),
        "epoch_time": float(epoch_time),
    }

    history_logs.append(log)

    print(
        f"Epoch {epoch}: "
        f"train_loss={train_loss:.5f}, train_auc={train_auc:.5f}, "
        f"valid_loss={valid_loss:.5f}, valid_auc={valid_auc:.5f}, "
        f"lr={optimizer.param_groups[0]['lr']:.2e}, "
        f"time={epoch_time:.1f}s"
    )

    if valid_auc > best_valid_auc:
        best_valid_auc = valid_auc
        best_epoch = epoch
        patience_counter = 0

        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "config": {
                    "embedding_dim": embedding_dim,
                    "max_history_len": cfg.MAX_HISTORY_LEN,
                    "attention_hidden_dim": cfg.ATTENTION_HIDDEN_DIM,
                    "mlp_hidden_dims": cfg.MLP_HIDDEN_DIMS,
                    "dropout": cfg.DROPOUT,
                },
                "best_valid_auc": float(best_valid_auc),
                "epoch": int(epoch),
            },
            best_model_path
        )

        print(f"保存最优模型: {best_model_path}")

    else:
        patience_counter += 1
        print(f"未提升，patience={patience_counter}/{cfg.PATIENCE}")

        if patience_counter >= cfg.PATIENCE:
            print("Early stopping")
            break

total_train_time = time.time() - start_total

print("\n训练完成")
print(f"Best epoch: {best_epoch}")
print(f"Best valid AUC: {best_valid_auc:.5f}")
print(f"Total train time: {total_train_time:.1f}s")

pd.DataFrame(history_logs).to_csv(
    os.path.join(cfg.OUTPUT_DIR, "training_history.csv"),
    index=False
)

# =========================================================
# 10. 加载最优模型并最终评估
# =========================================================

print("\n" + "=" * 90)
print("Step 6: 加载最优模型并最终评估")
print("=" * 90)

checkpoint = torch.load(best_model_path, map_location=device)
model.load_state_dict(checkpoint["model_state_dict"])
model.to(device)

# -------------------------
# Valid final evaluation
# -------------------------
valid_probs, valid_labels, final_valid_loss, final_valid_auc = predict(
    model,
    valid_loader,
    device,
    desc="Final Valid",
    has_label=True
)

valid_ranking_metrics = evaluate_ranking_metrics(valid_df, valid_probs)

print("\nFinal Valid Metrics:")
print(f"  auc:       {final_valid_auc:.6f}")
print(f"  group_auc: {valid_ranking_metrics['group_auc']:.6f}")
print(f"  mrr:       {valid_ranking_metrics['mrr']:.6f}")
print(f"  ndcg@5:    {valid_ranking_metrics['ndcg@5']:.6f}")
print(f"  ndcg@10:   {valid_ranking_metrics['ndcg@10']:.6f}")

# -------------------------
# Test final evaluation
# -------------------------
test_has_label = "label" in test_df.columns

test_probs, test_labels, final_test_loss, final_test_auc = predict(
    model,
    test_loader,
    device,
    desc="Final Test",
    has_label=test_has_label
)

if test_has_label:
    test_ranking_metrics = evaluate_ranking_metrics(test_df, test_probs)

    print("\nFinal Test Metrics:")
    print(f"  auc:       {final_test_auc:.6f}")
    print(f"  group_auc: {test_ranking_metrics['group_auc']:.6f}")
    print(f"  mrr:       {test_ranking_metrics['mrr']:.6f}")
    print(f"  ndcg@5:    {test_ranking_metrics['ndcg@5']:.6f}")
    print(f"  ndcg@10:   {test_ranking_metrics['ndcg@10']:.6f}")

else:
    test_ranking_metrics = {
        "group_auc": None,
        "mrr": None,
        "ndcg@5": None,
        "ndcg@10": None,
    }

    print("\nFinal Test:")
    print("  test 无 label，仅保存预测结果")

# =========================================================
# 11. 保存预测结果
# =========================================================

print("\n" + "=" * 90)
print("Step 7: 保存预测结果")
print("=" * 90)

valid_pred_cols = [
    c for c in ["impression_id", "user_id", "candidate_news_id", "label"]
    if c in valid_df.columns
]

valid_pred_df = valid_df[valid_pred_cols].copy()
valid_pred_df["pred"] = valid_probs

test_pred_cols = [
    c for c in ["impression_id", "user_id", "candidate_news_id", "label"]
    if c in test_df.columns
]

test_pred_df = test_df[test_pred_cols].copy()
test_pred_df["pred"] = test_probs

valid_pred_path = os.path.join(cfg.OUTPUT_DIR, "valid_predictions_din.csv")
test_pred_path = os.path.join(cfg.OUTPUT_DIR, "test_predictions_din.csv")

valid_pred_df.to_csv(valid_pred_path, index=False)
test_pred_df.to_csv(test_pred_path, index=False)

print(f"Valid predictions saved: {valid_pred_path}")
print(f"Test predictions saved : {test_pred_path}")

# =========================================================
# 12. 生成 MIND 官方提交格式
# =========================================================

def make_mind_submission(pred_df, output_path):
    """
    生成 MIND 官方提交格式：
    impression_id [rank1,rank2,...]

    注意：
    - 每个 impression 内部按照 pred 降序排名；
    - rank 从 1 开始；
    - 输出通常不带 header。
    """
    assert "impression_id" in pred_df.columns, "缺少 impression_id"
    assert "pred" in pred_df.columns, "缺少 pred"

    lines = []

    for imp_id, group in tqdm(pred_df.groupby("impression_id"), desc="Make submission"):
        preds = group["pred"].values

        # pred 越大 rank 越靠前
        order = np.argsort(-preds)

        ranks = np.empty_like(order)
        ranks[order] = np.arange(1, len(preds) + 1)

        rank_str = "[" + ",".join(map(str, ranks.tolist())) + "]"
        lines.append(f"{imp_id} {rank_str}")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"Submission saved: {output_path}")

if "impression_id" in test_pred_df.columns:
    submission_path = os.path.join(cfg.OUTPUT_DIR, "prediction_din.txt")
    make_mind_submission(test_pred_df, submission_path)

# =========================================================
# 13. 保存最终指标 JSON
# =========================================================

print("\n" + "=" * 90)
print("Step 8: 保存最终指标")
print("=" * 90)

if test_has_label:
    final_test_auc_value = float(final_test_auc)
    final_test_loss_value = float(final_test_loss)

    final_test_metrics = {
        "auc": float(final_test_auc),
        "group_auc": float(test_ranking_metrics["group_auc"]),
        "mrr": float(test_ranking_metrics["mrr"]),
        "ndcg@5": float(test_ranking_metrics["ndcg@5"]),
        "ndcg@10": float(test_ranking_metrics["ndcg@10"]),
    }
else:
    final_test_auc_value = None
    final_test_loss_value = None

    final_test_metrics = {
        "auc": None,
        "group_auc": None,
        "mrr": None,
        "ndcg@5": None,
        "ndcg@10": None,
    }

final_metrics = {
    "method": "DIN-lite",

    "best_epoch": int(best_epoch),
    "best_valid_auc": float(best_valid_auc),

    "final_valid_loss": float(final_valid_loss),
    "final_valid_auc": float(final_valid_auc),
    "final_valid_metrics": {
        "auc": float(final_valid_auc),
        "group_auc": float(valid_ranking_metrics["group_auc"]),
        "mrr": float(valid_ranking_metrics["mrr"]),
        "ndcg@5": float(valid_ranking_metrics["ndcg@5"]),
        "ndcg@10": float(valid_ranking_metrics["ndcg@10"]),
    },

    "final_test_loss": final_test_loss_value,
    "final_test_auc": final_test_auc_value,
    "final_test_metrics": final_test_metrics,

    # 与 IPS-DIN 字段兼容
    "valid_ranking_metrics": valid_ranking_metrics,
    "test_ranking_metrics": test_ranking_metrics,

    "config": {
        "seed": cfg.SEED,
        "use_negative_downsample": cfg.USE_NEGATIVE_DOWNSAMPLE,
        "neg_pos_ratio": cfg.NEG_POS_RATIO,
        "max_history_len": cfg.MAX_HISTORY_LEN,
        "batch_size": cfg.BATCH_SIZE,
        "epochs": cfg.EPOCHS,
        "lr": cfg.LR,
        "weight_decay": cfg.WEIGHT_DECAY,
        "attention_hidden_dim": cfg.ATTENTION_HIDDEN_DIM,
        "mlp_hidden_dims": cfg.MLP_HIDDEN_DIMS,
        "dropout": cfg.DROPOUT,
        "embedding_dim": embedding_dim,
        "device": str(device),
        "num_workers": cfg.NUM_WORKERS,
        "fast_test_mode": cfg.USE_FAST_TEST_MODE,
        "train_samples": int(len(train_df)),
        "valid_samples": int(len(valid_df)),
        "test_samples": int(len(test_df)),
    },

    "time": {
        "train_total_time": float(total_train_time),
    }
}

metrics_path = os.path.join(cfg.OUTPUT_DIR, "final_metrics_din.json")

with open(metrics_path, "w", encoding="utf-8") as f:
    json.dump(final_metrics, f, indent=2, ensure_ascii=False)

print(f"Final metrics saved: {metrics_path}")

# =========================================================
# 14. 总结
# =========================================================

print("\n" + "=" * 90)
print("DIN-lite baseline 完成")
print("=" * 90)

print(f"Best epoch: {best_epoch}")
print(f"Best Valid AUC: {best_valid_auc:.6f}")

print("\nFinal Valid:")
print(f"  auc:       {final_valid_auc:.6f}")
print(f"  group_auc: {valid_ranking_metrics['group_auc']:.6f}")
print(f"  mrr:       {valid_ranking_metrics['mrr']:.6f}")
print(f"  ndcg@5:    {valid_ranking_metrics['ndcg@5']:.6f}")
print(f"  ndcg@10:   {valid_ranking_metrics['ndcg@10']:.6f}")

if test_has_label:
    print("\nFinal Test:")
    print(f"  auc:       {final_test_auc:.6f}")
    print(f"  group_auc: {test_ranking_metrics['group_auc']:.6f}")
    print(f"  mrr:       {test_ranking_metrics['mrr']:.6f}")
    print(f"  ndcg@5:    {test_ranking_metrics['ndcg@5']:.6f}")
    print(f"  ndcg@10:   {test_ranking_metrics['ndcg@10']:.6f}")
else:
    print("\nFinal Test:")
    print("  无 label，仅生成预测和 submission 文件")

print(f"\nOutput dir: {cfg.OUTPUT_DIR}")
print("=" * 90)