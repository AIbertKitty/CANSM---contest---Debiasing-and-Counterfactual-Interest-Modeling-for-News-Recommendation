"""
Day 2 Task 3: Text-Avg-MLP

核心思想：
1. 使用新闻文本 embedding 表示候选新闻；
2. 使用用户历史点击新闻 embedding 的平均值表示用户兴趣；
3. 拼接 user_vec、candidate_vec、user_vec * candidate_vec、cos_sim、history_len；
4. 输入 MLP 预测点击概率。
"""

import os
import json
import random
import numpy as np
import pandas as pd
from tqdm import tqdm

import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader

from sklearn.metrics import roc_auc_score

# =========================================================
# 0. 配置
# =========================================================

class Config:
    EMBEDDINGS_DIR = "your_path/data/embeddings"
    PROCESSED_DIR = "your_path/data/processed"
    OUTPUT_DIR = "./outputs/text_avg_mlp"

    TRAIN_PATH = "your_path/data/processed/train_samples.csv"
    VALID_PATH = "your_path/data/processed/valid_samples.csv"
    TEST_PATH = "your_path/data/processed/test_samples.csv"

    NEWS_EMB_PATH = "your_path/data/embeddings/news_embeddings.npy"
    NEWS_MAP_PATH = "your_path/data/embeddings/news_id_to_index.json"

    SEED = 42

    # 训练参数
    BATCH_SIZE = 512
    EPOCHS = 10
    LR = 1e-3
    WEIGHT_DECAY = 1e-5
    PATIENCE = 3

    # 负采样参数
    USE_NEGATIVE_DOWNSAMPLE = True
    NEG_POS_RATIO = 4  # 每个正样本最多保留 4 个负样本

    # DataLoader
    NUM_WORKERS = 0  # Mac 建议先用 0，避免 multiprocessing semaphore warning

    # 模型参数
    HIDDEN_DIMS = [512, 256, 128]
    DROPOUT = 0.2

    # 设备
    DEVICE = "cuda" if torch.cuda.is_available() else (
        "mps" if torch.backends.mps.is_available() else "cpu"
    )

cfg = Config()
os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)

# =========================================================
# 1. 随机种子
# =========================================================

def set_seed(seed=42):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)

set_seed(cfg.SEED)

# =========================================================
# 2. 读取数据
# =========================================================

print("=" * 80)
print("Step 1: 加载数据")
print("=" * 80)

train_df = pd.read_csv(cfg.TRAIN_PATH)
valid_df = pd.read_csv(cfg.VALID_PATH)
test_df = pd.read_csv(cfg.TEST_PATH)

print(f"原始训练样本数: {len(train_df)}")
print(f"验证样本数: {len(valid_df)}")
print(f"测试样本数: {len(test_df)}")

print(f"训练集点击率: {train_df['label'].mean():.4f}")
print(f"验证集点击率: {valid_df['label'].mean():.4f}")
print(f"测试集点击率: {test_df['label'].mean():.4f}")

# =========================================================
# 3. 负样本下采样
# =========================================================

def negative_downsample(df, neg_pos_ratio=4, seed=42):
    """
    对训练集负样本下采样。
    MIND 数据正样本比例较低，直接训练容易被负样本主导。
    保留所有正样本，并随机采样若干倍负样本。
    """
    pos_df = df[df["label"] == 1]
    neg_df = df[df["label"] == 0]

    n_pos = len(pos_df)
    n_neg_keep = min(len(neg_df), n_pos * neg_pos_ratio)

    neg_sampled = neg_df.sample(n=n_neg_keep, random_state=seed)

    sampled_df = pd.concat([pos_df, neg_sampled], axis=0)
    sampled_df = sampled_df.sample(frac=1.0, random_state=seed).reset_index(drop=True)

    return sampled_df

if cfg.USE_NEGATIVE_DOWNSAMPLE:
    train_df = negative_downsample(
        train_df,
        neg_pos_ratio=cfg.NEG_POS_RATIO,
        seed=cfg.SEED
    )
    print("\n使用负样本下采样后：")
    print(f"训练样本数: {len(train_df)}")
    print(f"训练点击率: {train_df['label'].mean():.4f}")

# =========================================================
# 4. 加载新闻向量
# =========================================================

print("\n" + "=" * 80)
print("Step 2: 加载新闻 embedding")
print("=" * 80)

news_embeddings = np.load(cfg.NEWS_EMB_PATH).astype(np.float32)

with open(cfg.NEWS_MAP_PATH, "r", encoding="utf-8") as f:
    news_id_to_index = json.load(f)

embedding_dim = news_embeddings.shape[1]

print(f"新闻向量 shape: {news_embeddings.shape}")
print(f"Embedding dim: {embedding_dim}")
print(f"新闻 ID 映射数量: {len(news_id_to_index)}")

# =========================================================
# 5. Dataset
# =========================================================

class TextAvgDataset(Dataset):
    """
    动态构造样本特征：
    - user_avg_vec
    - candidate_vec
    - user_avg_vec * candidate_vec
    - cosine similarity
    - log history length
    """

    def __init__(self, df, news_embeddings, news_id_to_index, has_label=True):
        self.df = df.reset_index(drop=True)
        self.news_embeddings = news_embeddings
        self.news_id_to_index = news_id_to_index
        self.has_label = has_label
        self.embedding_dim = news_embeddings.shape[1]

        # 缓存 history -> user_vec，避免重复计算
        self.history_cache = {}

    def __len__(self):
        return len(self.df)

    def get_news_vec(self, news_id):
        if news_id in self.news_id_to_index:
            idx = self.news_id_to_index[news_id]
            return self.news_embeddings[idx]
        else:
            return np.zeros(self.embedding_dim, dtype=np.float32)

    def get_user_avg_vec(self, history):
        """
        history 是一个字符串，如：
        N123 N456 N789
        """
        if pd.isna(history) or history == "" or str(history) == "nan":
            return np.zeros(self.embedding_dim, dtype=np.float32), 0

        history = str(history)

        # 使用缓存加速
        if history in self.history_cache:
            return self.history_cache[history]

        news_ids = history.split()
        vecs = []

        for nid in news_ids:
            if nid in self.news_id_to_index:
                idx = self.news_id_to_index[nid]
                vecs.append(self.news_embeddings[idx])

        history_len = len(vecs)

        if history_len == 0:
            user_vec = np.zeros(self.embedding_dim, dtype=np.float32)
        else:
            user_vec = np.mean(vecs, axis=0).astype(np.float32)

        result = (user_vec, history_len)
        self.history_cache[history] = result

        return result

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        history = row["history"]
        candidate_news_id = row["candidate_news_id"]

        user_vec, history_len = self.get_user_avg_vec(history)
        cand_vec = self.get_news_vec(candidate_news_id)

        # 余弦相似度
        user_norm = np.linalg.norm(user_vec)
        cand_norm = np.linalg.norm(cand_vec)

        if user_norm == 0 or cand_norm == 0:
            sim = 0.0
        else:
            sim = float(np.dot(user_vec, cand_vec) / (user_norm * cand_norm))

        # 交互项
        interact_vec = user_vec * cand_vec

        # 历史长度做 log 变换，避免数值过大
        log_history_len = np.log1p(history_len).astype(np.float32)

        # 拼接最终特征
        feature = np.concatenate([
            user_vec,
            cand_vec,
            interact_vec,
            np.array([sim, log_history_len], dtype=np.float32)
        ]).astype(np.float32)

        if self.has_label:
            label = np.float32(row["label"])
            return torch.tensor(feature, dtype=torch.float32), torch.tensor(label, dtype=torch.float32)
        else:
            return torch.tensor(feature, dtype=torch.float32)

# =========================================================
# 6. DataLoader
# =========================================================

print("\n" + "=" * 80)
print("Step 3: 构造 Dataset 和 DataLoader")
print("=" * 80)

train_dataset = TextAvgDataset(train_df, news_embeddings, news_id_to_index, has_label=True)
valid_dataset = TextAvgDataset(valid_df, news_embeddings, news_id_to_index, has_label=True)
test_dataset = TextAvgDataset(test_df, news_embeddings, news_id_to_index, has_label=True)

input_dim = embedding_dim * 3 + 2

print(f"模型输入维度: {input_dim}")
print(f"  user_vec: {embedding_dim}")
print(f"  candidate_vec: {embedding_dim}")
print(f"  interaction_vec: {embedding_dim}")
print(f"  sim + log_history_len: 2")

train_loader = DataLoader(
    train_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=True,
    num_workers=cfg.NUM_WORKERS
)

valid_loader = DataLoader(
    valid_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS
)

test_loader = DataLoader(
    test_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS
)

# =========================================================
# 7. 定义模型
# =========================================================

class TextAvgMLP(nn.Module):
    def __init__(self, input_dim, hidden_dims=[512, 256, 128], dropout=0.2):
        super().__init__()

        layers = []
        prev_dim = input_dim

        for hidden_dim in hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev_dim = hidden_dim

        layers.append(nn.Linear(prev_dim, 1))

        self.mlp = nn.Sequential(*layers)

    def forward(self, x):
        logits = self.mlp(x).squeeze(1)
        return logits

model = TextAvgMLP(
    input_dim=input_dim,
    hidden_dims=cfg.HIDDEN_DIMS,
    dropout=cfg.DROPOUT
).to(cfg.DEVICE)

print("\n模型结构:")
print(model)
print(f"使用设备: {cfg.DEVICE}")

# =========================================================
# 8. 损失函数和优化器
# =========================================================

criterion = nn.BCEWithLogitsLoss()

optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=cfg.LR,
    weight_decay=cfg.WEIGHT_DECAY
)

scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer,
    mode="max",
    factor=0.5,
    patience=1
)

# =========================================================
# 9. 训练与评估函数
# =========================================================

def train_one_epoch(model, loader, criterion, optimizer, device):
    model.train()

    total_loss = 0.0
    all_labels = []
    all_probs = []

    pbar = tqdm(loader, desc="Training")

    for features, labels in pbar:
        features = features.to(device)
        labels = labels.to(device)

        optimizer.zero_grad()

        logits = model(features)
        loss = criterion(logits, labels)

        loss.backward()
        optimizer.step()

        probs = torch.sigmoid(logits).detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()

        total_loss += loss.item() * len(labels)

        all_probs.extend(probs.tolist())
        all_labels.extend(labels_np.tolist())

        pbar.set_postfix({"loss": loss.item()})

    avg_loss = total_loss / len(loader.dataset)

    try:
        auc = roc_auc_score(all_labels, all_probs)
    except Exception:
        auc = 0.0

    return avg_loss, auc

@torch.no_grad()
def evaluate(model, loader, criterion, device, desc="Evaluating"):
    model.eval()

    total_loss = 0.0
    all_labels = []
    all_probs = []

    pbar = tqdm(loader, desc=desc)

    for features, labels in pbar:
        features = features.to(device)
        labels = labels.to(device)

        logits = model(features)
        loss = criterion(logits, labels)

        probs = torch.sigmoid(logits).cpu().numpy()
        labels_np = labels.cpu().numpy()

        total_loss += loss.item() * len(labels)

        all_probs.extend(probs.tolist())
        all_labels.extend(labels_np.tolist())

    avg_loss = total_loss / len(loader.dataset)

    try:
        auc = roc_auc_score(all_labels, all_probs)
    except Exception:
        auc = 0.0

    return avg_loss, auc, np.array(all_probs), np.array(all_labels)

# =========================================================
# 10. 按 impression 计算 MRR / nDCG
# =========================================================

def dcg_score(labels):
    labels = np.asarray(labels)
    gains = (2 ** labels - 1)
    discounts = np.log2(np.arange(len(labels)) + 2)
    return np.sum(gains / discounts)

def ndcg_score(labels, k=None):
    labels = np.asarray(labels)

    if k is not None:
        labels = labels[:k]

    dcg = dcg_score(labels)
    ideal = np.sort(labels)[::-1]

    if k is not None:
        ideal = ideal[:k]

    idcg = dcg_score(ideal)

    if idcg == 0:
        return 0.0

    return dcg / idcg

def mrr_score(labels):
    labels = np.asarray(labels)
    pos_indices = np.where(labels == 1)[0]

    if len(pos_indices) == 0:
        return 0.0

    return 1.0 / (pos_indices[0] + 1)

def evaluate_ranking_metrics(df, probs):
    """
    按 impression_id 分组计算：
    - AUC
    - MRR
    - nDCG@5
    - nDCG@10
    """
    eval_df = df.copy()
    eval_df["pred"] = probs

    auc_list = []
    mrr_list = []
    ndcg5_list = []
    ndcg10_list = []

    for imp_id, group in tqdm(eval_df.groupby("impression_id"), desc="Ranking metrics"):
        labels = group["label"].values
        preds = group["pred"].values

        # 如果该 impression 里只有单一标签，AUC 无法计算
        if len(np.unique(labels)) > 1:
            auc_list.append(roc_auc_score(labels, preds))

        # 按预测分数降序排列
        order = np.argsort(-preds)
        sorted_labels = labels[order]

        mrr_list.append(mrr_score(sorted_labels))
        ndcg5_list.append(ndcg_score(sorted_labels, k=5))
        ndcg10_list.append(ndcg_score(sorted_labels, k=10))

    metrics = {
        "group_auc": float(np.mean(auc_list)) if len(auc_list) > 0 else 0.0,
        "mrr": float(np.mean(mrr_list)),
        "ndcg@5": float(np.mean(ndcg5_list)),
        "ndcg@10": float(np.mean(ndcg10_list)),
    }

    return metrics

# =========================================================
# 11. 训练主循环
# =========================================================

print("\n" + "=" * 80)
print("Step 4: 开始训练")
print("=" * 80)

best_valid_auc = 0.0
best_epoch = -1
patience_counter = 0

history = []

best_model_path = os.path.join(cfg.OUTPUT_DIR, "best_text_avg_mlp.pt")

for epoch in range(1, cfg.EPOCHS + 1):
    print(f"\nEpoch {epoch}/{cfg.EPOCHS}")
    print("-" * 80)

    train_loss, train_auc = train_one_epoch(
        model, train_loader, criterion, optimizer, cfg.DEVICE
    )

    valid_loss, valid_auc, valid_probs, valid_labels = evaluate(
        model, valid_loader, criterion, cfg.DEVICE, desc="Validation"
    )

    scheduler.step(valid_auc)

    print(f"Train Loss: {train_loss:.5f} | Train AUC: {train_auc:.5f}")
    print(f"Valid Loss: {valid_loss:.5f} | Valid AUC: {valid_auc:.5f}")

    epoch_info = {
        "epoch": epoch,
        "train_loss": train_loss,
        "train_auc": train_auc,
        "valid_loss": valid_loss,
        "valid_auc": valid_auc,
    }
    history.append(epoch_info)

    # 保存最优模型
    if valid_auc > best_valid_auc:
        best_valid_auc = valid_auc
        best_epoch = epoch
        patience_counter = 0

        torch.save({
            "model_state_dict": model.state_dict(),
            "input_dim": input_dim,
            "embedding_dim": embedding_dim,
            "config": {
                "hidden_dims": cfg.HIDDEN_DIMS,
                "dropout": cfg.DROPOUT
            },
            "best_valid_auc": best_valid_auc,
            "best_epoch": best_epoch,
        }, best_model_path)

        print(f"✓ 保存最优模型: {best_model_path}")
    else:
        patience_counter += 1
        print(f"验证 AUC 未提升，patience: {patience_counter}/{cfg.PATIENCE}")

    if patience_counter >= cfg.PATIENCE:
        print("触发 Early Stopping")
        break

# 保存训练日志
history_path = os.path.join(cfg.OUTPUT_DIR, "training_history.json")
with open(history_path, "w", encoding="utf-8") as f:
    json.dump(history, f, indent=2, ensure_ascii=False)

print("\n训练完成")
print(f"Best Epoch: {best_epoch}")
print(f"Best Valid AUC: {best_valid_auc:.5f}")

# =========================================================
# 12. 加载最佳模型并做最终评估
# =========================================================

print("\n" + "=" * 80)
print("Step 5: 加载最佳模型并评估")
print("=" * 80)

# checkpoint = torch.load(best_model_path, map_location=cfg.DEVICE)
checkpoint = torch.load(best_model_path, map_location=cfg.DEVICE, weights_only=False)
model.load_state_dict(checkpoint["model_state_dict"])

valid_loss, valid_auc, valid_probs, valid_labels = evaluate(
    model, valid_loader, criterion, cfg.DEVICE, desc="Final Valid"
)

test_loss, test_auc, test_probs, test_labels = evaluate(
    model, test_loader, criterion, cfg.DEVICE, desc="Final Test"
)

print(f"\nFinal Valid AUC: {valid_auc:.5f}")
print(f"Final Test AUC: {test_auc:.5f}")

# 排序指标
print("\n计算验证集排序指标...")
valid_ranking_metrics = evaluate_ranking_metrics(valid_df, valid_probs)

print("\n计算测试集排序指标...")
test_ranking_metrics = evaluate_ranking_metrics(test_df, test_probs)

print("\n验证集排序指标:")
for k, v in valid_ranking_metrics.items():
    print(f"  {k}: {v:.5f}")

print("\n测试集排序指标:")
for k, v in test_ranking_metrics.items():
    print(f"  {k}: {v:.5f}")

# =========================================================
# 13. 保存预测结果
# =========================================================

print("\n" + "=" * 80)
print("Step 6: 保存预测结果")
print("=" * 80)

valid_pred_df = valid_df[["impression_id", "user_id", "candidate_news_id", "label"]].copy()
valid_pred_df["pred"] = valid_probs

test_pred_df = test_df[["impression_id", "user_id", "candidate_news_id", "label"]].copy()
test_pred_df["pred"] = test_probs

valid_pred_path = os.path.join(cfg.OUTPUT_DIR, "valid_predictions.csv")
test_pred_path = os.path.join(cfg.OUTPUT_DIR, "test_predictions.csv")

valid_pred_df.to_csv(valid_pred_path, index=False)
test_pred_df.to_csv(test_pred_path, index=False)

print(f"✓ 验证集预测已保存: {valid_pred_path}")
print(f"✓ 测试集预测已保存: {test_pred_path}")

# 保存最终指标
final_metrics = {
    "best_epoch": best_epoch,
    "best_valid_auc": best_valid_auc,
    "final_valid_auc": valid_auc,
    "final_test_auc": test_auc,
    "valid_ranking_metrics": valid_ranking_metrics,
    "test_ranking_metrics": test_ranking_metrics,
    "config": {
        "batch_size": cfg.BATCH_SIZE,
        "epochs": cfg.EPOCHS,
        "lr": cfg.LR,
        "weight_decay": cfg.WEIGHT_DECAY,
        "hidden_dims": cfg.HIDDEN_DIMS,
        "dropout": cfg.DROPOUT,
        "use_negative_downsample": cfg.USE_NEGATIVE_DOWNSAMPLE,
        "neg_pos_ratio": cfg.NEG_POS_RATIO,
        "input_dim": input_dim,
        "embedding_dim": embedding_dim,
    }
}

metrics_path = os.path.join(cfg.OUTPUT_DIR, "final_metrics.json")
with open(metrics_path, "w", encoding="utf-8") as f:
    json.dump(final_metrics, f, indent=2, ensure_ascii=False)

print(f"✓ 最终指标已保存: {metrics_path}")

print("\n" + "=" * 80)
print("✓ Day 2 Task 3 完成：Text-Avg-MLP 训练结束")
print("=" * 80)