"""
FCAD-DIN: Factual-Counterfactual Attention DIN

核心改动：
1. 保留 DIN-lite 主干；
2. 仅替换原 DIN Attention 模块；
3. 新增 factual attention 与 counterfactual attention；
4. 通过可学习 intervention gate 构造反事实历史表示；
5. 后续 MLP 输入维度保持不变，便于和 DIN 控制变量对比；
6. 不使用 IPS；
7. 不使用 bias tower；
8. 不使用 REx / IRM / ADV；
9. 可选加入轻量 factual-counterfactual prediction consistency loss。
"""

import os
import json
import time
import random
import warnings
warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
from tqdm import tqdm

from sklearn.metrics import roc_auc_score

import torch
import torch.nn as nn
import torch.nn.functional as F
from torch.utils.data import Dataset, DataLoader

# =========================================================
# 0. Config
# =========================================================

class Config:
    # =====================================================
    # 路径：按你的实际路径修改
    # =====================================================
    TRAIN_PATH = "your_path/data/processed/train_samples.csv"
    VALID_PATH = "your_path/data/processed/valid_samples.csv"
    TEST_PATH = "your_path/data/processed/test_samples.csv"

    NEWS_EMB_PATH = "your_path/data/embeddings/news_embeddings.npy"
    NEWS_MAP_PATH = "your_path/data/embeddings/news_id_to_index.json"

    OUTPUT_DIR = "./outputs/fcad_din"

    # =====================================================
    # 基础训练参数：尽量和 DIN 保持一致
    # =====================================================
    SEED = 42

    USE_NEGATIVE_DOWNSAMPLE = True
    NEG_POS_RATIO = 4

    USE_FAST_TEST_MODE = False
    FAST_TEST_SAMPLE_SIZE = 50000

    MAX_HISTORY_LEN = 50

    BATCH_SIZE = 256
    NUM_WORKERS = 0

    ATTENTION_HIDDEN_DIM = 64
    MLP_HIDDEN_DIMS = [256, 128, 64]
    DROPOUT = 0.2

    EPOCHS = 8
    LR = 1e-3
    WEIGHT_DECAY = 1e-5
    PATIENCE = 2

    # =====================================================
    # FCAD-DIN 核心参数
    # =====================================================

    # 反事实用户兴趣表示融合比例：
    # user_vec = (1-alpha) * factual_user_vec + alpha * counterfactual_user_vec
    # alpha=0 等价于只用 factual attention，接近原 DIN。
    # 稳健建议：0.2 ~ 0.4。
    CF_FUSION_ALPHA = 0.3

    # 是否使用 factual/counterfactual prediction consistency loss
    # 为了稳定，默认开启很小权重。
    USE_FC_CONSISTENCY_LOSS = True

    # 一致性损失权重，建议很小。
    LAMBDA_FC_CONSISTENCY = 0.02

    # 第几个 epoch 后启用 consistency loss。
    # epoch=1 先接近普通 DIN 训练。
    CONSISTENCY_WARMUP_EPOCHS = 1

    # intervention gate 正则：
    # 防止 gate 全部趋近 0 或全部趋近 1。
    # 让 gate 平均值不要过度偏离 TARGET_GATE_MEAN。
    USE_GATE_REG = True
    LAMBDA_GATE_REG = 0.005
    TARGET_GATE_MEAN = 0.8

    # 模型选择指标
    # 如果你最怕 AUC 掉，设为 "auc"
    # 如果想综合推荐排序指标，设为 "composite"
    SELECT_METRIC = "composite"

    USE_MPS = True

cfg = Config()
os.makedirs(cfg.OUTPUT_DIR, exist_ok=True)

# =========================================================
# 1. Seed and device
# =========================================================

def set_seed(seed):
    random.seed(seed)
    np.random.seed(seed)
    torch.manual_seed(seed)

set_seed(cfg.SEED)

def get_device():
    if cfg.USE_MPS and torch.backends.mps.is_available():
        return torch.device("mps")
    elif torch.cuda.is_available():
        return torch.device("cuda")
    else:
        return torch.device("cpu")

device = get_device()

print("=" * 90)
print("FCAD-DIN: Factual-Counterfactual Attention DIN")
print("=" * 90)
print(f"Device: {device}")
print(f"Output dir: {cfg.OUTPUT_DIR}")

# =========================================================
# 2. Load data
# =========================================================

print("\n" + "=" * 90)
print("Step 1: Load data")
print("=" * 90)

train_full_df = pd.read_csv(cfg.TRAIN_PATH)
valid_df = pd.read_csv(cfg.VALID_PATH)
test_df = pd.read_csv(cfg.TEST_PATH)

print(f"train_full: {len(train_full_df):,}, CTR={train_full_df['label'].mean():.5f}")
print(f"valid     : {len(valid_df):,}, CTR={valid_df['label'].mean():.5f}")

if "label" in test_df.columns:
    print(f"test      : {len(test_df):,}, CTR={test_df['label'].mean():.5f}")
else:
    print(f"test      : {len(test_df):,}, no label")

required_cols = ["user_id", "candidate_news_id", "history", "label"]
for col in required_cols:
    assert col in train_full_df.columns, f"Missing column in train: {col}"

# =========================================================
# 3. Negative downsampling
# =========================================================

def negative_downsample(df, neg_pos_ratio=4, seed=42):
    pos_df = df[df["label"] == 1]
    neg_df = df[df["label"] == 0]

    n_pos = len(pos_df)
    n_neg_keep = min(len(neg_df), n_pos * neg_pos_ratio)

    neg_sampled = neg_df.sample(n=n_neg_keep, random_state=seed)

    sampled_df = pd.concat([pos_df, neg_sampled], axis=0)
    sampled_df = sampled_df.sample(frac=1.0, random_state=seed).reset_index(drop=True)

    return sampled_df

train_df = train_full_df.copy()

if cfg.USE_NEGATIVE_DOWNSAMPLE:
    print("\nApply negative downsampling")
    print(f"neg_pos_ratio = {cfg.NEG_POS_RATIO}")

    train_df = negative_downsample(
        train_df,
        neg_pos_ratio=cfg.NEG_POS_RATIO,
        seed=cfg.SEED
    )

    print(f"sampled train: {len(train_df):,}, CTR={train_df['label'].mean():.5f}")

if cfg.USE_FAST_TEST_MODE:
    print("\nFAST TEST MODE")
    if len(train_df) > cfg.FAST_TEST_SAMPLE_SIZE:
        train_df = train_df.sample(
            n=cfg.FAST_TEST_SAMPLE_SIZE,
            random_state=cfg.SEED
        ).reset_index(drop=True)
    print(f"fast train: {len(train_df):,}, CTR={train_df['label'].mean():.5f}")

# =========================================================
# 4. Load news embeddings
# =========================================================

print("\n" + "=" * 90)
print("Step 2: Load news embeddings")
print("=" * 90)

news_embeddings = np.load(cfg.NEWS_EMB_PATH).astype(np.float32)

with open(cfg.NEWS_MAP_PATH, "r", encoding="utf-8") as f:
    news_id_to_index = json.load(f)

embedding_dim = news_embeddings.shape[1]

print(f"news_embeddings: {news_embeddings.shape}")
print(f"embedding_dim: {embedding_dim}")
print(f"news_id_to_index size: {len(news_id_to_index):,}")

# =========================================================
# 5. Dataset / DataLoader
# =========================================================

print("\n" + "=" * 90)
print("Step 3: Dataset / DataLoader")
print("=" * 90)

class FCADDINDataset(Dataset):
    def __init__(
        self,
        df,
        news_embeddings,
        news_id_to_index,
        max_history_len=50,
        has_label=True
    ):
        self.df = df.reset_index(drop=True)
        self.news_embeddings = news_embeddings
        self.news_id_to_index = news_id_to_index
        self.max_history_len = max_history_len
        self.has_label = has_label
        self.embedding_dim = news_embeddings.shape[1]

    def __len__(self):
        return len(self.df)

    def _get_vec(self, news_id):
        if news_id in self.news_id_to_index:
            return self.news_embeddings[self.news_id_to_index[news_id]]
        return np.zeros(self.embedding_dim, dtype=np.float32)

    def _get_history_vecs_and_mask(self, history):
        history_vecs = np.zeros(
            (self.max_history_len, self.embedding_dim),
            dtype=np.float32
        )
        history_mask = np.zeros(self.max_history_len, dtype=np.float32)

        if pd.isna(history) or str(history) == "" or str(history) == "nan":
            return history_vecs, history_mask, 0

        news_ids = str(history).split()
        news_ids = news_ids[-self.max_history_len:]

        real_len = 0

        for i, nid in enumerate(news_ids):
            if nid in self.news_id_to_index:
                history_vecs[i] = self.news_embeddings[self.news_id_to_index[nid]]
                history_mask[i] = 1.0
                real_len += 1

        return history_vecs, history_mask, real_len

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        candidate_vec = self._get_vec(row["candidate_news_id"])
        history_vecs, history_mask, real_history_len = self._get_history_vecs_and_mask(
            row["history"]
        )

        log_history_len = np.float32(np.log1p(real_history_len))

        item = {
            "candidate_vec": torch.tensor(candidate_vec, dtype=torch.float32),
            "history_vecs": torch.tensor(history_vecs, dtype=torch.float32),
            "history_mask": torch.tensor(history_mask, dtype=torch.float32),
            "log_history_len": torch.tensor([log_history_len], dtype=torch.float32),
        }

        if self.has_label and "label" in row:
            item["label"] = torch.tensor(row["label"], dtype=torch.float32)
        else:
            item["label"] = torch.tensor(0.0, dtype=torch.float32)

        return item

train_dataset = FCADDINDataset(
    train_df,
    news_embeddings,
    news_id_to_index,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=True
)

valid_dataset = FCADDINDataset(
    valid_df,
    news_embeddings,
    news_id_to_index,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=True
)

test_dataset = FCADDINDataset(
    test_df,
    news_embeddings,
    news_id_to_index,
    max_history_len=cfg.MAX_HISTORY_LEN,
    has_label=("label" in test_df.columns)
)

train_loader = DataLoader(
    train_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=True,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

valid_loader = DataLoader(
    valid_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

test_loader = DataLoader(
    test_dataset,
    batch_size=cfg.BATCH_SIZE,
    shuffle=False,
    num_workers=cfg.NUM_WORKERS,
    drop_last=False
)

print(f"train batches: {len(train_loader)}")
print(f"valid batches: {len(valid_loader)}")
print(f"test batches : {len(test_loader)}")

# =========================================================
# 6. Model
# =========================================================

print("\n" + "=" * 90)
print("Step 4: Define FCAD-DIN model")
print("=" * 90)

class BaseAttentionScorer(nn.Module):
    """
    与原 DIN Attention 的打分网络保持一致：
    input = [h_t, i, h_t * i, |h_t - i|]
    """
    def __init__(self, embedding_dim, attention_hidden_dim=64):
        super().__init__()

        input_dim = embedding_dim * 4

        self.attention_mlp = nn.Sequential(
            nn.Linear(input_dim, attention_hidden_dim),
            nn.ReLU(),
            nn.Linear(attention_hidden_dim, attention_hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(attention_hidden_dim // 2, 1)
        )

    def forward(self, history_vecs, candidate_vec, history_mask):
        B, H, D = history_vecs.shape

        candidate_expand = candidate_vec.unsqueeze(1).expand(-1, H, -1)

        attention_input = torch.cat(
            [
                history_vecs,
                candidate_expand,
                history_vecs * candidate_expand,
                torch.abs(history_vecs - candidate_expand)
            ],
            dim=-1
        )

        scores = self.attention_mlp(attention_input).squeeze(-1)

        scores = scores.masked_fill(history_mask <= 0, -1e9)

        weights = torch.softmax(scores, dim=1)

        weights = weights * history_mask
        weights_sum = weights.sum(dim=1, keepdim=True) + 1e-8
        weights = weights / weights_sum

        user_vec = torch.sum(history_vecs * weights.unsqueeze(-1), dim=1)

        return user_vec, weights, scores

class InterventionGate(nn.Module):
    """
    可学习反事实干预门控。

    对每条历史新闻 h_t，在候选新闻 i 条件下计算保留概率 gate_t：

        gate_t = sigmoid(G([h_t, i, h_t*i, |h_t-i|]))

    gate_t 越小，表示该历史项在反事实路径中被更强干预削弱。
    """
    def __init__(self, embedding_dim, hidden_dim=64):
        super().__init__()

        input_dim = embedding_dim * 4

        self.gate_mlp = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Linear(hidden_dim, hidden_dim // 2),
            nn.ReLU(),
            nn.Linear(hidden_dim // 2, 1)
        )

    def forward(self, history_vecs, candidate_vec, history_mask):
        B, H, D = history_vecs.shape

        candidate_expand = candidate_vec.unsqueeze(1).expand(-1, H, -1)

        gate_input = torch.cat(
            [
                history_vecs,
                candidate_expand,
                history_vecs * candidate_expand,
                torch.abs(history_vecs - candidate_expand)
            ],
            dim=-1
        )

        gate_logits = self.gate_mlp(gate_input).squeeze(-1)

        gates = torch.sigmoid(gate_logits)

        gates = gates * history_mask

        return gates

class FactualCounterfactualAttentionLayer(nn.Module):
    """
    FCAD Attention:

    1. Factual attention:
        u_f = DIN_Attention(H, i)

    2. Intervention gate:
        g_t = sigmoid(G(h_t, i))

    3. Counterfactual history:
        H_cf = g_t * H

    4. Counterfactual attention:
        u_cf = DIN_Attention(H_cf, i)

    5. Fusion:
        u = (1-alpha) * u_f + alpha * u_cf

    为了控制变量：
    - factual attention 和 counterfactual attention 使用同结构 attention scorer；
    - 下游 MLP 输入维度不变；
    - 不引入环境变量；
    - 不引入 bias tower。
    """
    def __init__(
        self,
        embedding_dim,
        attention_hidden_dim=64,
        cf_fusion_alpha=0.3,
        share_attention_scorer=True
    ):
        super().__init__()

        self.cf_fusion_alpha = cf_fusion_alpha
        self.share_attention_scorer = share_attention_scorer

        self.factual_attention = BaseAttentionScorer(
            embedding_dim=embedding_dim,
            attention_hidden_dim=attention_hidden_dim
        )

        if share_attention_scorer:
            self.counterfactual_attention = self.factual_attention
        else:
            self.counterfactual_attention = BaseAttentionScorer(
                embedding_dim=embedding_dim,
                attention_hidden_dim=attention_hidden_dim
            )

        self.intervention_gate = InterventionGate(
            embedding_dim=embedding_dim,
            hidden_dim=attention_hidden_dim
        )

    def forward(self, history_vecs, candidate_vec, history_mask):
        # factual path
        factual_user_vec, factual_weights, factual_scores = self.factual_attention(
            history_vecs=history_vecs,
            candidate_vec=candidate_vec,
            history_mask=history_mask
        )

        # learnable intervention gate
        gates = self.intervention_gate(
            history_vecs=history_vecs,
            candidate_vec=candidate_vec,
            history_mask=history_mask
        )

        # counterfactual history: do-soft-mask
        cf_history_vecs = history_vecs * gates.unsqueeze(-1)

        # counterfactual path
        cf_user_vec, cf_weights, cf_scores = self.counterfactual_attention(
            history_vecs=cf_history_vecs,
            candidate_vec=candidate_vec,
            history_mask=history_mask
        )

        alpha = self.cf_fusion_alpha

        fused_user_vec = (1.0 - alpha) * factual_user_vec + alpha * cf_user_vec

        return {
            "user_vec": fused_user_vec,
            "factual_user_vec": factual_user_vec,
            "cf_user_vec": cf_user_vec,
            "factual_weights": factual_weights,
            "cf_weights": cf_weights,
            "gates": gates
        }

class FCADDIN(nn.Module):
    """
    FCAD-DIN:
    仅将原 DIN attention 替换为 factual-counterfactual attention。
    后续 DIN-lite MLP 结构保持不变。
    """
    def __init__(
        self,
        embedding_dim,
        attention_hidden_dim=64,
        mlp_hidden_dims=[256, 128, 64],
        dropout=0.2,
        cf_fusion_alpha=0.3
    ):
        super().__init__()

        self.embedding_dim = embedding_dim

        self.attention = FactualCounterfactualAttentionLayer(
            embedding_dim=embedding_dim,
            attention_hidden_dim=attention_hidden_dim,
            cf_fusion_alpha=cf_fusion_alpha,
            share_attention_scorer=True
        )

        din_input_dim = embedding_dim * 3 + 2

        layers = []
        prev_dim = din_input_dim

        for hidden_dim in mlp_hidden_dims:
            layers.append(nn.Linear(prev_dim, hidden_dim))
            layers.append(nn.BatchNorm1d(hidden_dim))
            layers.append(nn.ReLU())
            layers.append(nn.Dropout(dropout))
            prev_dim = hidden_dim

        self.mlp = nn.Sequential(*layers)
        self.pred_head = nn.Linear(prev_dim, 1)

    def build_din_features(self, user_vec, candidate_vec, log_history_len):
        interaction_vec = user_vec * candidate_vec

        user_norm = torch.norm(user_vec, dim=1, keepdim=True)
        cand_norm = torch.norm(candidate_vec, dim=1, keepdim=True)

        cosine_sim = torch.sum(user_vec * candidate_vec, dim=1, keepdim=True) / (
            user_norm * cand_norm + 1e-8
        )

        din_input = torch.cat(
            [
                user_vec,
                candidate_vec,
                interaction_vec,
                cosine_sim,
                log_history_len
            ],
            dim=1
        )

        return din_input

    def score_from_user_vec(self, user_vec, candidate_vec, log_history_len):
        din_input = self.build_din_features(
            user_vec=user_vec,
            candidate_vec=candidate_vec,
            log_history_len=log_history_len
        )

        z = self.mlp(din_input)
        logit = self.pred_head(z).squeeze(-1)

        return logit, z

    def forward(
        self,
        candidate_vec,
        history_vecs,
        history_mask,
        log_history_len,
        return_aux=True
    ):
        att_out = self.attention(
            history_vecs=history_vecs,
            candidate_vec=candidate_vec,
            history_mask=history_mask
        )

        fused_user_vec = att_out["user_vec"]

        fused_logit, z = self.score_from_user_vec(
            user_vec=fused_user_vec,
            candidate_vec=candidate_vec,
            log_history_len=log_history_len
        )

        if not return_aux:
            return {
                "logit": fused_logit,
                "z": z
            }

        # 用于 consistency loss 和可解释分析
        factual_logit, _ = self.score_from_user_vec(
            user_vec=att_out["factual_user_vec"],
            candidate_vec=candidate_vec,
            log_history_len=log_history_len
        )

        cf_logit, _ = self.score_from_user_vec(
            user_vec=att_out["cf_user_vec"],
            candidate_vec=candidate_vec,
            log_history_len=log_history_len
        )

        return {
            "logit": fused_logit,
            "factual_logit": factual_logit,
            "cf_logit": cf_logit,
            "z": z,
            "factual_weights": att_out["factual_weights"],
            "cf_weights": att_out["cf_weights"],
            "gates": att_out["gates"]
        }

model = FCADDIN(
    embedding_dim=embedding_dim,
    attention_hidden_dim=cfg.ATTENTION_HIDDEN_DIM,
    mlp_hidden_dims=cfg.MLP_HIDDEN_DIMS,
    dropout=cfg.DROPOUT,
    cf_fusion_alpha=cfg.CF_FUSION_ALPHA
).to(device)

print(model)
print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")

# =========================================================
# 7. Metrics
# =========================================================

def dcg_score(labels):
    labels = np.asarray(labels)
    gains = (2 ** labels - 1)
    discounts = np.log2(np.arange(len(labels)) + 2)
    return np.sum(gains / discounts)

def ndcg_score(labels, k=None):
    labels = np.asarray(labels)

    if k is not None:
        labels = labels[:k]

    dcg = dcg_score(labels)

    ideal = np.sort(labels)[::-1]
    if k is not None:
        ideal = ideal[:k]

    idcg = dcg_score(ideal)

    if idcg == 0:
        return 0.0

    return dcg / idcg

def mrr_score(labels):
    labels = np.asarray(labels)
    pos_indices = np.where(labels == 1)[0]

    if len(pos_indices) == 0:
        return 0.0

    return 1.0 / (pos_indices[0] + 1)

def evaluate_ranking_metrics(df, probs):
    eval_df = df.copy()
    eval_df["pred"] = probs

    if "label" not in eval_df.columns:
        return {
            "auc": None,
            "group_auc": None,
            "mrr": None,
            "ndcg@5": None,
            "ndcg@10": None,
        }

    labels_all = eval_df["label"].values

    try:
        auc = roc_auc_score(labels_all, probs)
    except Exception:
        auc = 0.0

    if "impression_id" not in eval_df.columns:
        return {
            "auc": float(auc),
            "group_auc": 0.0,
            "mrr": 0.0,
            "ndcg@5": 0.0,
            "ndcg@10": 0.0,
        }

    auc_list = []
    mrr_list = []
    ndcg5_list = []
    ndcg10_list = []

    for imp_id, group in tqdm(
        eval_df.groupby("impression_id"),
        desc="Ranking metrics",
        leave=False
    ):
        labels = group["label"].values
        preds = group["pred"].values

        if len(np.unique(labels)) > 1:
            try:
                auc_list.append(roc_auc_score(labels, preds))
            except Exception:
                pass

        order = np.argsort(-preds)
        sorted_labels = labels[order]

        mrr_list.append(mrr_score(sorted_labels))
        ndcg5_list.append(ndcg_score(sorted_labels, k=5))
        ndcg10_list.append(ndcg_score(sorted_labels, k=10))

    return {
        "auc": float(auc),
        "group_auc": float(np.mean(auc_list)) if len(auc_list) > 0 else 0.0,
        "mrr": float(np.mean(mrr_list)) if len(mrr_list) > 0 else 0.0,
        "ndcg@5": float(np.mean(ndcg5_list)) if len(ndcg5_list) > 0 else 0.0,
        "ndcg@10": float(np.mean(ndcg10_list)) if len(ndcg10_list) > 0 else 0.0,
    }

def metric_selection_score(metrics, select_metric="composite"):
    if metrics["auc"] is None:
        return -1e9

    if select_metric == "auc":
        return metrics["auc"]
    elif select_metric == "group_auc":
        return metrics["group_auc"]
    elif select_metric == "mrr":
        return metrics["mrr"]
    elif select_metric == "ndcg@5":
        return metrics["ndcg@5"]
    elif select_metric == "ndcg@10":
        return metrics["ndcg@10"]
    else:
        return (
            0.25 * metrics["auc"]
            + 0.25 * metrics["group_auc"]
            + 0.20 * metrics["mrr"]
            + 0.15 * metrics["ndcg@5"]
            + 0.15 * metrics["ndcg@10"]
        )

# =========================================================
# 8. Loss / Train / Predict
# =========================================================

def move_batch_to_device(batch, device):
    return {k: v.to(device) for k, v in batch.items()}

def compute_fc_consistency_loss(factual_logits, cf_logits):
    """
    事实路径和反事实路径的一致性约束。
    用概率空间 MSE，比 logit MSE 更稳。
    """
    p_f = torch.sigmoid(factual_logits)
    p_cf = torch.sigmoid(cf_logits)

    return F.mse_loss(p_f, p_cf, reduction="mean")

def compute_gate_regularization(gates, history_mask):
    """
    gate 正则：
    防止 gate 平均值过低，导致反事实路径过度破坏历史兴趣。
    """
    valid_num = history_mask.sum() + 1e-8
    gate_mean = (gates * history_mask).sum() / valid_num

    target = torch.tensor(
        cfg.TARGET_GATE_MEAN,
        device=gates.device,
        dtype=gates.dtype
    )

    return (gate_mean - target) ** 2, gate_mean.detach()

def train_one_epoch(model, loader, optimizer, device, epoch):
    model.train()

    total_loss_sum = 0.0
    erm_loss_sum = 0.0
    fc_loss_sum = 0.0
    gate_reg_sum = 0.0
    gate_mean_sum = 0.0

    total_samples = 0

    all_probs = []
    all_labels = []

    use_consistency = (
        cfg.USE_FC_CONSISTENCY_LOSS
        and epoch > cfg.CONSISTENCY_WARMUP_EPOCHS
    )

    for batch in tqdm(loader, desc="Train", leave=False):
        batch = move_batch_to_device(batch, device)

        candidate_vec = batch["candidate_vec"]
        history_vecs = batch["history_vecs"]
        history_mask = batch["history_mask"]
        log_history_len = batch["log_history_len"]
        labels = batch["label"]

        optimizer.zero_grad(set_to_none=True)

        outputs = model(
            candidate_vec=candidate_vec,
            history_vecs=history_vecs,
            history_mask=history_mask,
            log_history_len=log_history_len,
            return_aux=True
        )

        logits = outputs["logit"]

        erm_loss = F.binary_cross_entropy_with_logits(
            logits,
            labels,
            reduction="mean"
        )

        if use_consistency:
            fc_loss = compute_fc_consistency_loss(
                factual_logits=outputs["factual_logit"],
                cf_logits=outputs["cf_logit"]
            )
        else:
            fc_loss = torch.tensor(0.0, device=device)

        if cfg.USE_GATE_REG:
            gate_reg, gate_mean = compute_gate_regularization(
                gates=outputs["gates"],
                history_mask=history_mask
            )
        else:
            gate_reg = torch.tensor(0.0, device=device)
            gate_mean = torch.tensor(0.0, device=device)

        loss = erm_loss

        if use_consistency:
            loss = loss + cfg.LAMBDA_FC_CONSISTENCY * fc_loss

        if cfg.USE_GATE_REG:
            loss = loss + cfg.LAMBDA_GATE_REG * gate_reg

        loss.backward()
        optimizer.step()

        batch_size = labels.size(0)

        total_loss_sum += loss.item() * batch_size
        erm_loss_sum += erm_loss.item() * batch_size
        fc_loss_sum += fc_loss.item() * batch_size
        gate_reg_sum += gate_reg.item() * batch_size
        gate_mean_sum += gate_mean.item() * batch_size

        total_samples += batch_size

        probs = torch.sigmoid(logits).detach().cpu().numpy()
        labels_np = labels.detach().cpu().numpy()

        all_probs.append(probs)
        all_labels.append(labels_np)

    all_probs = np.concatenate(all_probs)
    all_labels = np.concatenate(all_labels)

    try:
        auc = roc_auc_score(all_labels, all_probs)
    except Exception:
        auc = 0.0

    return {
        "loss": total_loss_sum / max(total_samples, 1),
        "erm_loss": erm_loss_sum / max(total_samples, 1),
        "fc_loss": fc_loss_sum / max(total_samples, 1),
        "gate_reg": gate_reg_sum / max(total_samples, 1),
        "gate_mean": gate_mean_sum / max(total_samples, 1),
        "auc": auc,
        "use_consistency": use_consistency,
    }

@torch.no_grad()
def predict(model, loader, device, desc="Predict"):
    model.eval()

    all_logits = []
    all_labels = []

    total_loss = 0.0
    total_samples = 0

    gate_mean_sum = 0.0

    for batch in tqdm(loader, desc=desc, leave=False):
        batch = move_batch_to_device(batch, device)

        candidate_vec = batch["candidate_vec"]
        history_vecs = batch["history_vecs"]
        history_mask = batch["history_mask"]
        log_history_len = batch["log_history_len"]
        labels = batch["label"]

        outputs = model(
            candidate_vec=candidate_vec,
            history_vecs=history_vecs,
            history_mask=history_mask,
            log_history_len=log_history_len,
            return_aux=True
        )

        logits = outputs["logit"]

        all_logits.append(logits.detach().cpu().numpy())

        loss = F.binary_cross_entropy_with_logits(
            logits,
            labels,
            reduction="mean"
        )

        total_loss += loss.item() * labels.size(0)
        total_samples += labels.size(0)

        all_labels.append(labels.detach().cpu().numpy())

        valid_num = history_mask.sum() + 1e-8
        gate_mean = (outputs["gates"] * history_mask).sum() / valid_num
        gate_mean_sum += gate_mean.item() * labels.size(0)

    logits = np.concatenate(all_logits)
    probs = 1.0 / (1.0 + np.exp(-logits))

    labels = np.concatenate(all_labels)
    avg_loss = total_loss / max(total_samples, 1)
    avg_gate_mean = gate_mean_sum / max(total_samples, 1)

    return {
        "logits": logits,
        "probs": probs,
        "labels": labels,
        "loss": avg_loss,
        "gate_mean": avg_gate_mean,
    }

# =========================================================
# 9. Train loop
# =========================================================

print("\n" + "=" * 90)
print("Step 5: Train FCAD-DIN")
print("=" * 90)

optimizer = torch.optim.AdamW(
    model.parameters(),
    lr=cfg.LR,
    weight_decay=cfg.WEIGHT_DECAY
)

scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
    optimizer,
    mode="max",
    factor=0.5,
    patience=1
)

best_score = -1e18
best_epoch = -1
best_metrics = None
patience_counter = 0

history_logs = []

best_model_path = os.path.join(cfg.OUTPUT_DIR, "best_fcad_din.pt")

start_total = time.time()

for epoch in range(1, cfg.EPOCHS + 1):
    print("\n" + "-" * 90)
    print(f"Epoch {epoch}/{cfg.EPOCHS}")
    print("-" * 90)

    start_epoch = time.time()

    train_log = train_one_epoch(
        model=model,
        loader=train_loader,
        optimizer=optimizer,
        device=device,
        epoch=epoch
    )

    valid_pred = predict(
        model=model,
        loader=valid_loader,
        device=device,
        desc="Valid"
    )

    valid_metrics = evaluate_ranking_metrics(
        valid_df,
        valid_pred["probs"]
    )

    valid_score = metric_selection_score(
        valid_metrics,
        select_metric=cfg.SELECT_METRIC
    )

    scheduler.step(valid_score)

    epoch_time = time.time() - start_epoch

    log = {
        "epoch": int(epoch),
        "train_loss": float(train_log["loss"]),
        "train_erm_loss": float(train_log["erm_loss"]),
        "train_fc_loss": float(train_log["fc_loss"]),
        "train_gate_reg": float(train_log["gate_reg"]),
        "train_gate_mean": float(train_log["gate_mean"]),
        "train_auc": float(train_log["auc"]),
        "valid_loss": float(valid_pred["loss"]),
        "valid_score": float(valid_score),
        "valid_auc": float(valid_metrics["auc"]),
        "valid_group_auc": float(valid_metrics["group_auc"]),
        "valid_mrr": float(valid_metrics["mrr"]),
        "valid_ndcg@5": float(valid_metrics["ndcg@5"]),
        "valid_ndcg@10": float(valid_metrics["ndcg@10"]),
        "valid_gate_mean": float(valid_pred["gate_mean"]),
        "lr": float(optimizer.param_groups[0]["lr"]),
        "epoch_time": float(epoch_time),
        "use_consistency": bool(train_log["use_consistency"]),
    }

    history_logs.append(log)

    print(
        f"Epoch {epoch}: "
        f"train_loss={train_log['loss']:.5f}, "
        f"erm={train_log['erm_loss']:.5f}, "
        f"fc={train_log['fc_loss']:.6f}, "
        f"gate_reg={train_log['gate_reg']:.6f}, "
        f"gate_mean={train_log['gate_mean']:.4f}, "
        f"train_auc={train_log['auc']:.5f}, "
        f"valid_loss={valid_pred['loss']:.5f}, "
        f"valid_score={valid_score:.6f}, "
        f"valid_auc={valid_metrics['auc']:.6f}, "
        f"group_auc={valid_metrics['group_auc']:.6f}, "
        f"mrr={valid_metrics['mrr']:.6f}, "
        f"ndcg@5={valid_metrics['ndcg@5']:.6f}, "
        f"ndcg@10={valid_metrics['ndcg@10']:.6f}, "
        f"valid_gate_mean={valid_pred['gate_mean']:.4f}, "
        f"lr={optimizer.param_groups[0]['lr']:.2e}, "
        f"time={epoch_time:.1f}s"
    )

    if valid_score > best_score:
        best_score = valid_score
        best_epoch = epoch
        best_metrics = valid_metrics
        patience_counter = 0

        torch.save(
            {
                "model_state_dict": model.state_dict(),
                "config": {
                    "embedding_dim": embedding_dim,
                    "max_history_len": cfg.MAX_HISTORY_LEN,
                    "attention_hidden_dim": cfg.ATTENTION_HIDDEN_DIM,
                    "mlp_hidden_dims": cfg.MLP_HIDDEN_DIMS,
                    "dropout": cfg.DROPOUT,
                    "cf_fusion_alpha": cfg.CF_FUSION_ALPHA,
                    "use_fc_consistency_loss": cfg.USE_FC_CONSISTENCY_LOSS,
                    "lambda_fc_consistency": cfg.LAMBDA_FC_CONSISTENCY,
                    "consistency_warmup_epochs": cfg.CONSISTENCY_WARMUP_EPOCHS,
                    "use_gate_reg": cfg.USE_GATE_REG,
                    "lambda_gate_reg": cfg.LAMBDA_GATE_REG,
                    "target_gate_mean": cfg.TARGET_GATE_MEAN,
                    "select_metric": cfg.SELECT_METRIC,
                },
                "best_epoch": int(best_epoch),
                "best_score": float(best_score),
                "best_metrics": best_metrics,
            },
            best_model_path
        )

        print(f"Saved best model: {best_model_path}")

    else:
        patience_counter += 1
        print(f"No improvement. patience={patience_counter}/{cfg.PATIENCE}")

        if patience_counter >= cfg.PATIENCE:
            print("Early stopping")
            break

total_train_time = time.time() - start_total

pd.DataFrame(history_logs).to_csv(
    os.path.join(cfg.OUTPUT_DIR, "training_history.csv"),
    index=False
)

print("\nTraining finished")
print(f"Best epoch: {best_epoch}")
print(f"Best score: {best_score:.6f}")
print(f"Best valid metrics: {best_metrics}")
print(f"Total train time: {total_train_time:.1f}s")

# =========================================================
# 10. Final evaluation
# =========================================================

print("\n" + "=" * 90)
print("Step 6: Final evaluation")
print("=" * 90)

checkpoint = torch.load(best_model_path, map_location=device)
model.load_state_dict(checkpoint["model_state_dict"])
model.to(device)

print(f"Loaded best epoch: {checkpoint['best_epoch']}")

valid_pred = predict(
    model=model,
    loader=valid_loader,
    device=device,
    desc="Final Valid"
)

valid_metrics = evaluate_ranking_metrics(
    valid_df,
    valid_pred["probs"]
)

print("\nFinal Valid Metrics:")
print(f"  auc:       {valid_metrics['auc']:.6f}")
print(f"  group_auc: {valid_metrics['group_auc']:.6f}")
print(f"  mrr:       {valid_metrics['mrr']:.6f}")
print(f"  ndcg@5:    {valid_metrics['ndcg@5']:.6f}")
print(f"  ndcg@10:   {valid_metrics['ndcg@10']:.6f}")
print(f"  gate_mean: {valid_pred['gate_mean']:.4f}")

test_has_label = "label" in test_df.columns

test_pred = predict(
    model=model,
    loader=test_loader,
    device=device,
    desc="Final Test"
)

if test_has_label:
    test_metrics = evaluate_ranking_metrics(
        test_df,
        test_pred["probs"]
    )

    print("\nFinal Test Metrics:")
    print(f"  auc:       {test_metrics['auc']:.6f}")
    print(f"  group_auc: {test_metrics['group_auc']:.6f}")
    print(f"  mrr:       {test_metrics['mrr']:.6f}")
    print(f"  ndcg@5:    {test_metrics['ndcg@5']:.6f}")
    print(f"  ndcg@10:   {test_metrics['ndcg@10']:.6f}")
    print(f"  gate_mean: {test_pred['gate_mean']:.4f}")

else:
    test_metrics = {
        "auc": None,
        "group_auc": None,
        "mrr": None,
        "ndcg@5": None,
        "ndcg@10": None,
    }

    print("\nTest has no label. Predictions saved only.")

# =========================================================
# 11. Save predictions
# =========================================================

print("\n" + "=" * 90)
print("Step 7: Save predictions")
print("=" * 90)

valid_cols = [
    c for c in ["impression_id", "user_id", "candidate_news_id", "label"]
    if c in valid_df.columns
]

test_cols = [
    c for c in ["impression_id", "user_id", "candidate_news_id", "label"]
    if c in test_df.columns
]

valid_pred_df = valid_df[valid_cols].copy()
valid_pred_df["pred"] = valid_pred["probs"]

test_pred_df = test_df[test_cols].copy()
test_pred_df["pred"] = test_pred["probs"]

valid_pred_path = os.path.join(cfg.OUTPUT_DIR, "valid_predictions_fcad_din.csv")
test_pred_path = os.path.join(cfg.OUTPUT_DIR, "test_predictions_fcad_din.csv")

valid_pred_df.to_csv(valid_pred_path, index=False)
test_pred_df.to_csv(test_pred_path, index=False)

print(f"Valid predictions saved: {valid_pred_path}")
print(f"Test predictions saved : {test_pred_path}")

# =========================================================
# 12. MIND submission
# =========================================================

def make_mind_submission(pred_df, output_path):
    assert "impression_id" in pred_df.columns
    assert "pred" in pred_df.columns

    lines = []

    for imp_id, group in tqdm(pred_df.groupby("impression_id"), desc="Make submission"):
        preds = group["pred"].values

        order = np.argsort(-preds)
        ranks = np.empty_like(order)
        ranks[order] = np.arange(1, len(preds) + 1)

        rank_str = "[" + ",".join(map(str, ranks.tolist())) + "]"
        lines.append(f"{imp_id} {rank_str}")

    with open(output_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))

    print(f"Submission saved: {output_path}")

if "impression_id" in test_pred_df.columns:
    submission_path = os.path.join(cfg.OUTPUT_DIR, "prediction_fcad_din.txt")
    make_mind_submission(test_pred_df, submission_path)

# =========================================================
# 13. Save final metrics
# =========================================================

print("\n" + "=" * 90)
print("Step 8: Save final metrics")
print("=" * 90)

final_metrics = {
    "method": "FCAD-DIN: Factual-Counterfactual Attention DIN",

    "best_epoch": int(checkpoint["best_epoch"]),
    "best_score": float(checkpoint["best_score"]),

    "final_valid_metrics": {
        "auc": float(valid_metrics["auc"]),
        "group_auc": float(valid_metrics["group_auc"]),
        "mrr": float(valid_metrics["mrr"]),
        "ndcg@5": float(valid_metrics["ndcg@5"]),
        "ndcg@10": float(valid_metrics["ndcg@10"]),
        "gate_mean": float(valid_pred["gate_mean"]),
    },

    "final_test_metrics": {
        "auc": None if test_metrics["auc"] is None else float(test_metrics["auc"]),
        "group_auc": None if test_metrics["group_auc"] is None else float(test_metrics["group_auc"]),
        "mrr": None if test_metrics["mrr"] is None else float(test_metrics["mrr"]),
        "ndcg@5": None if test_metrics["ndcg@5"] is None else float(test_metrics["ndcg@5"]),
        "ndcg@10": None if test_metrics["ndcg@10"] is None else float(test_metrics["ndcg@10"]),
        "gate_mean": float(test_pred["gate_mean"]),
    },

    "model_design": {
        "base_model": "DIN-lite",
        "changed_module": "attention layer only",
        "factual_attention": True,
        "counterfactual_attention": True,
        "learnable_intervention_gate": True,
        "downstream_mlp_input_dim_unchanged": True,
        "ips": False,
        "bias_tower": False,
        "rex": False,
        "irm": False,
        "environment_adversarial": False,
        "cf_fusion_alpha": cfg.CF_FUSION_ALPHA,
        "fc_consistency_loss": {
            "enabled": cfg.USE_FC_CONSISTENCY_LOSS,
            "lambda": cfg.LAMBDA_FC_CONSISTENCY,
            "warmup_epochs": cfg.CONSISTENCY_WARMUP_EPOCHS
        },
        "gate_regularization": {
            "enabled": cfg.USE_GATE_REG,
            "lambda": cfg.LAMBDA_GATE_REG,
            "target_gate_mean": cfg.TARGET_GATE_MEAN
        }
    },

    "config": {
        "seed": cfg.SEED,
        "use_negative_downsample": cfg.USE_NEGATIVE_DOWNSAMPLE,
        "neg_pos_ratio": cfg.NEG_POS_RATIO,
        "max_history_len": cfg.MAX_HISTORY_LEN,
        "batch_size": cfg.BATCH_SIZE,
        "epochs": cfg.EPOCHS,
        "lr": cfg.LR,
        "weight_decay": cfg.WEIGHT_DECAY,
        "attention_hidden_dim": cfg.ATTENTION_HIDDEN_DIM,
        "mlp_hidden_dims": cfg.MLP_HIDDEN_DIMS,
        "dropout": cfg.DROPOUT,
        "select_metric": cfg.SELECT_METRIC,
        "embedding_dim": embedding_dim,
        "device": str(device),
        "train_samples": int(len(train_df)),
        "valid_samples": int(len(valid_df)),
        "test_samples": int(len(test_df)),
    },

    "time": {
        "total_train_time": float(total_train_time)
    }
}

metrics_path = os.path.join(cfg.OUTPUT_DIR, "final_metrics_fcad_din.json")

with open(metrics_path, "w", encoding="utf-8") as f:
    json.dump(final_metrics, f, indent=2, ensure_ascii=False)

print(f"Final metrics saved: {metrics_path}")

# =========================================================
# 14. Finish
# =========================================================

print("\n" + "=" * 90)
print("FCAD-DIN finished")
print("=" * 90)

print(f"Best epoch: {checkpoint['best_epoch']}")
print(f"Best score: {checkpoint['best_score']:.6f}")

print("\nFinal Valid:")
print(f"  auc:       {valid_metrics['auc']:.6f}")
print(f"  group_auc: {valid_metrics['group_auc']:.6f}")
print(f"  mrr:       {valid_metrics['mrr']:.6f}")
print(f"  ndcg@5:    {valid_metrics['ndcg@5']:.6f}")
print(f"  ndcg@10:   {valid_metrics['ndcg@10']:.6f}")
print(f"  gate_mean: {valid_pred['gate_mean']:.4f}")

if test_has_label:
    print("\nFinal Test:")
    print(f"  auc:       {test_metrics['auc']:.6f}")
    print(f"  group_auc: {test_metrics['group_auc']:.6f}")
    print(f"  mrr:       {test_metrics['mrr']:.6f}")
    print(f"  ndcg@5:    {test_metrics['ndcg@5']:.6f}")
    print(f"  ndcg@10:   {test_metrics['ndcg@10']:.6f}")
    print(f"  gate_mean: {test_pred['gate_mean']:.4f}")
else:
    print("\nFinal Test:")
    print("  no label, predictions saved only")

print(f"\nOutput dir: {cfg.OUTPUT_DIR}")
print("=" * 90)