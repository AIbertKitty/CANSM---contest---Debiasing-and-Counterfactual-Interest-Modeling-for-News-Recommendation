import pandas as pd
from pathlib import Path
from typing import Dict
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')


class MINDDataProcessor:
    """MIND数据处理器"""

    def __init__(self, data_dir: str = "./data/mind/MINDsmall_train"):
        """
        初始化数据处理器

        Args:
            data_dir: MIND数据目录路径
        """
        self.data_dir = Path(data_dir)
        self.news_df = None
        self.behaviors_df = None
        self.samples_df = None

    def load_news(self) -> pd.DataFrame:
        """
        读取news.tsv文件

        Returns:
            news DataFrame
        """
        print("📰 读取news.tsv...")

        news_cols = [
            "news_id",
            "category",
            "subcategory",
            "title",
            "abstract",
            "url",
            "title_entities",
            "abstract_entities"
        ]

        news_path = self.data_dir / "news.tsv"

        self.news_df = pd.read_csv(
            news_path,
            sep="\t",
            names=news_cols,
            encoding='utf-8'
        )

        print(f"✅ 读取完成: {len(self.news_df)} 条新闻")
        print(f"   类别数: {self.news_df['category'].nunique()}")
        print(f"   子类别数: {self.news_df['subcategory'].nunique()}")

        return self.news_df

    def load_behaviors(self) -> pd.DataFrame:
        """
        读取behaviors.tsv文件

        Returns:
            behaviors DataFrame
        """
        print("\n👤 读取behaviors.tsv...")

        behaviors_cols = [
            "impression_id",
            "user_id",
            "time",
            "history",
            "impressions"
        ]

        behaviors_path = self.data_dir / "behaviors.tsv"

        self.behaviors_df = pd.read_csv(
            behaviors_path,
            sep="\t",
            names=behaviors_cols,
            encoding='utf-8'
        )

        print(f"✅ 读取完成: {len(self.behaviors_df)} 条行为记录")
        print(f"   用户数: {self.behaviors_df['user_id'].nunique()}")
        print(f"   Impression数: {len(self.behaviors_df)}")

        return self.behaviors_df

    def expand_impressions(self,
                           save_path: str = None,
                           sample_ratio: float = 1.0) -> pd.DataFrame:
        """
        展开impressions为训练样本

        每个impression包含多个候选新闻，格式为: "news_id-label news_id-label ..."
        展开为: (impression_id, user_id, time, history, candidate_news_id, label)

        Args:
            save_path: 保存路径，如果为None则不保存
            sample_ratio: 采样比例，用于快速测试

        Returns:
            展开后的样本DataFrame
        """
        print("\n🔄 展开impressions为训练样本...")

        if self.behaviors_df is None:
            self.load_behaviors()

        samples = []

        # 如果需要采样
        if sample_ratio < 1.0:
            behaviors_sample = self.behaviors_df.sample(
                frac=sample_ratio,
                random_state=42
            )
            print(f"   采样 {sample_ratio*100:.1f}% 数据用于快速测试")
        else:
            behaviors_sample = self.behaviors_df

        # 展开每个impression
        for idx, row in tqdm(behaviors_sample.iterrows(),
                             total=len(behaviors_sample),
                             desc="展开样本"):

            impression_id = row['impression_id']
            user_id = row['user_id']
            time = row['time']
            history = row['history'] if pd.notna(row['history']) else ""
            impressions = row['impressions']

            # 解析impressions字符串
            # 格式: "N12345-1 N23456-0 N34567-1 or N34567" 处理测试集时不同
            if pd.isna(impressions):
                continue

            impression_list = impressions.split()

            for imp in impression_list:
                try:
                    news_id = imp  # news_id, label = imp.split('-') 处理测试集时不同

                    samples.append({
                        'impression_id': impression_id,
                        'user_id': user_id,
                        'time': time,
                        'history': history,
                        'candidate_news_id': news_id
                        # 'label' : label 处理测试集时注释
                    })
                except:
                    # 跳过格式错误的样本
                    continue

        self.samples_df = pd.DataFrame(samples)

        print(f"\n✅ 展开完成:")
        print(f"   总样本数: {len(self.samples_df):,}")

        # print(f"   正样本数: {(self.samples_df['label']==1).sum():,}")
        # print(f"   负样本数: {(self.samples_df['label']==0).sum():,}")
        # print(f"   点击率: {self.samples_df['label'].mean()*100:.2f}%") 处理测试集时注释

        # 保存
        if save_path:
            self.samples_df.to_csv(save_path, index=False)
            print(f"   已保存至: {save_path}")

        return self.samples_df

    def get_statistics(self) -> Dict:
        """
        获取数据统计信息

        Returns:
            统计信息字典
        """
        if self.samples_df is None:
            print("⚠️  请先运行expand_impressions()")
            return {}

        stats = {
            'total_samples': len(self.samples_df),
            'positive_samples': (self.samples_df['label'] == 1).sum(),
            'negative_samples': (self.samples_df['label'] == 0).sum(),
            'click_rate': self.samples_df['label'].mean(),
            'num_users': self.samples_df['user_id'].nunique(),
            'num_impressions': self.samples_df['impression_id'].nunique(),
            'num_candidate_news': self.samples_df['candidate_news_id'].nunique(),
        }

        # 用户历史长度统计
        history_lengths = self.samples_df['history'].apply(
            lambda x: len(x.split()) if x else 0
        )
        stats['avg_history_length'] = history_lengths.mean()
        stats['max_history_length'] = history_lengths.max()
        stats['min_history_length'] = history_lengths.min()

        return stats

    def print_statistics(self):
        """打印统计信息"""
        stats = self.get_statistics()

        print("\n" + "="*60)
        print("📊 数据统计信息")
        print("="*60)
        print(f"总样本数:        {stats['total_samples']:>12,}")
        print(f"正样本数:        {stats['positive_samples']:>12,}")
        print(f"负样本数:        {stats['negative_samples']:>12,}")
        print(f"点击率:          {stats['click_rate']:>12.2%}")
        print(f"用户数:          {stats['num_users']:>12,}")
        print(f"Impression数:    {stats['num_impressions']:>12,}")
        print(f"候选新闻数:      {stats['num_candidate_news']:>12,}")
        print(f"平均历史长度:    {stats['avg_history_length']:>12.1f}")
        print(f"最大历史长度:    {stats['max_history_length']:>12}")
        print(f"最小历史长度:    {stats['min_history_length']:>12}")
        print("="*60)

    def show_samples(self, n: int = 5):
        """
        展示样本示例

        Args:
            n: 展示样本数量
        """
        if self.samples_df is None:
            print("⚠️  请先运行expand_impressions()")
            return

        print(f"\n📋 样本示例 (前{n}条):")
        print("-"*100)

        for idx, row in self.samples_df.head(n).iterrows():
            print(f"\n样本 {idx+1}:")
            print(f"  Impression ID: {row['impression_id']}")
            print(f"  User ID:       {row['user_id']}")
            print(f"  Time:          {row['time']}")
            print(f"  Candidate:     {row['candidate_news_id']}")
            print(
                f"  Label:         {row['label']} {'✅ 点击' if row['label']==1 else '❌ 未点击'}")

            history = row['history']
            if history:
                history_list = history.split()
                print(
                    f"  History:       {len(history_list)} 条历史 (前3条: {' '.join(history_list[:3])}...)")
            else:
                print(f"  History:       无历史")

        print("-"*100)


def main():

    # 训练集
    train_processor = MINDDataProcessor(
        "your_path/data/MINDsmall_train")
    train_processor.load_news()
    train_processor.load_behaviors()
    train_samples = train_processor.expand_impressions(
        save_path="your_path/data/train_samples.csv"
    )

    # 验证集
    dev_processor = MINDDataProcessor(
        "your_path/data/MINDsmall_dev")
    dev_processor.load_news()
    dev_processor.load_behaviors()
    dev_samples = dev_processor.expand_impressions(
        save_path="your_path/data/dev_samples.csv"
    )

    print(f"\n训练集: {len(train_samples):,} 样本")
    print(f"验证集: {len(dev_samples):,} 样本")


if __name__ == "__main__":
    main()
