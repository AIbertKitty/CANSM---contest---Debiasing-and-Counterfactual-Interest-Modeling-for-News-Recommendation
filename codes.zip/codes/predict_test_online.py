import os
import pandas as pd
import numpy as np
import lightgbm as lgb
from tqdm import tqdm


class OnlineMINDPredictor:
    """在线 MIND 测试集预测器（无需编码器文件）"""

    def __init__(self, model_path, news_path, train_features_path=None):
        """
        初始化预测器

        Args:
            model_path: LightGBM 模型路径
            news_path: 新闻信息文件路径（news.tsv）
            train_features_path: 训练集特征路径（用于构建类别映射，可选）
        """
        self.model_path = model_path
        self.news_path = news_path
        self.train_features_path = train_features_path

        # 加载模型
        self.load_model()

        # 加载新闻信息
        self.load_news_info()

        # 构建类别映射（从训练集或新闻数据）
        self.build_category_mappings()

    def load_model(self):
        """加载 LightGBM 模型"""
        print(f"\n📥 加载模型...")

        if not os.path.exists(self.model_path):
            raise FileNotFoundError(f"❌ 模型文件不存在: {self.model_path}")

        self.model = lgb.Booster(model_file=self.model_path)
        print(f"✅ LightGBM 模型已加载: {self.model_path}")

        # 获取模型特征名（从模型文件中读取）
        self.feature_names = self.model.feature_name()
        print(f"✅ 模型特征数: {len(self.feature_names)}")
        print(f"   特征列表: {self.feature_names}")

    def load_news_info(self):
        """加载新闻信息到内存"""
        print(f"\n📰 加载新闻信息...")

        news_df = pd.read_csv(
            self.news_path,
            sep='\t',
            names=['news_id', 'category', 'subcategory', 'title', 'abstract',
                   'url', 'title_entities', 'abstract_entities']
        )

        # 转换为字典（快速查询）
        self.news_dict = news_df.set_index('news_id').to_dict('index')

        print(f"✅ 新闻信息已加载: {len(self.news_dict):,} 条新闻")

    def build_category_mappings(self):
        import pickle
        """从训练时保存的编码器加载映射"""
        print(f"\n🔧 构建类别映射...")

        # ✅ 优先从编码器文件加载
        encoder_path = self.model_path.replace('.txt', '_encoders.pkl')

        if os.path.exists(encoder_path):
            print(f"   从编码器文件加载: {encoder_path}")
            with open(encoder_path, 'rb') as f:
                encoder_data = pickle.load(f)

            # 提取类别映射
            label_encoders = encoder_data['label_encoders']
            self.category_mapping = label_encoders.get(
                'candidate_category', {})
            self.subcategory_mapping = label_encoders.get(
                'candidate_subcategory', {})
            self.time_period_mapping = label_encoders.get('time_period', {})

            print(f"✅ 类别映射加载完成:")
            print(f"   category: {len(self.category_mapping)} 类")
            print(f"   subcategory: {len(self.subcategory_mapping)} 类")
            print(f"   time_period: {len(self.time_period_mapping)} 类")
        else:
            raise FileNotFoundError(
                f"❌ 编码器文件不存在: {encoder_path}\n"
                f"   请重新训练模型并保存编码器！"
            )

    def extract_features_online(self, impression_id, user_id, time_str, history, candidates):
        """
        在线提取单个 impression 的特征

        Args:
            impression_id: impression ID
            user_id: 用户 ID
            time_str: 时间字符串
            history: 历史点击新闻列表（字符串，空格分隔）
            candidates: 候选新闻列表

        Returns:
            特征 DataFrame
        """
        # 解析时间
        time_dt = pd.to_datetime(time_str)
        hour = time_dt.hour

        # 时间段特征
        if 6 <= hour < 12:
            time_period = 'morning'
        elif 12 <= hour < 18:
            time_period = 'afternoon'
        elif 18 <= hour < 24:
            time_period = 'evening'
        else:
            time_period = 'night'

        # 用户历史特征
        if pd.isna(history) or history == '':
            history_list = []
        else:
            history_list = history.split()

        history_length = len(history_list)

        # 历史类别统计
        history_categories = []
        history_subcategories = []
        for news_id in history_list:
            if news_id in self.news_dict:
                history_categories.append(self.news_dict[news_id]['category'])
                history_subcategories.append(
                    self.news_dict[news_id]['subcategory'])

        # 为每个候选新闻提取特征
        features_list = []

        for candidate_news_id in candidates:
            # 候选新闻特征
            if candidate_news_id in self.news_dict:
                candidate_info = self.news_dict[candidate_news_id]
                candidate_category = candidate_info['category']
                candidate_subcategory = candidate_info['subcategory']
            else:
                candidate_category = 'unknown'
                candidate_subcategory = 'unknown'

            # 用户-候选新闻交互特征
            category_match = 1 if candidate_category in history_categories else 0
            subcategory_match = 1 if candidate_subcategory in history_subcategories else 0

            # 类别频率
            category_freq = history_categories.count(
                candidate_category) if history_categories else 0
            subcategory_freq = history_subcategories.count(
                candidate_subcategory) if history_subcategories else 0

            # 编码类别特征（使用映射）
            candidate_category_encoded = self.category_mapping.get(
                candidate_category, -1)
            candidate_subcategory_encoded = self.subcategory_mapping.get(
                candidate_subcategory, -1)
            time_period_encoded = self.time_period_mapping.get(time_period, -1)

            # 构建特征字典（必须与训练时的特征顺序一致）
            feature_dict = {
                'candidate_category': candidate_category_encoded,
                'candidate_subcategory': candidate_subcategory_encoded,
                'history_length': history_length,
                'time_period': time_period_encoded,
                'hour': hour,
                'category_match': category_match,
                'subcategory_match': subcategory_match,
                'category_freq': category_freq,
                'subcategory_freq': subcategory_freq,
            }

            features_list.append(feature_dict)

        return pd.DataFrame(features_list)

    def prepare_features(self, features_df):
        """
        准备特征（确保特征顺序与模型一致）

        Args:
            features_df: 原始特征 DataFrame

        Returns:
            按模型特征顺序排列的 DataFrame
        """
        # 确保特征顺序与模型一致
        feature_cols = []
        for fname in self.feature_names:
            if fname in features_df.columns:
                feature_cols.append(fname)
            else:
                # 如果缺少特征，填充 0
                features_df[fname] = 0
                feature_cols.append(fname)

        return features_df[feature_cols]

    def predict_and_rank(self, features_df):
        """
        预测并生成排序

        Args:
            features_df: 特征 DataFrame

        Returns:
            排序列表（从 1 开始）
        """
        # 准备特征
        X = self.prepare_features(features_df)

        # 预测
        preds = self.model.predict(X)

        # 生成排序（按预测分数降序）
        sorted_indices = np.argsort(-preds)  # 降序排序

        # 生成排名列表（原始位置 -> 排名）
        rank_list = np.empty_like(sorted_indices)
        rank_list[sorted_indices] = np.arange(1, len(sorted_indices) + 1)

        return rank_list.tolist()

    def predict_test_online(self, behaviors_path, output_path='./outputs/prediction.txt',
                            batch_size=1000):
        """
        在线预测测试集（流式处理）

        Args:
            behaviors_path: 测试集 behaviors.tsv 路径
            output_path: 输出文件路径
            batch_size: 批量写入大小
        """
        print(f"\n🔮 开始在线预测...")
        print(f"测试集路径: {behaviors_path}")

        # 确保输出目录存在
        output_dir = os.path.dirname(output_path)
        if output_dir and not os.path.exists(output_dir):
            os.makedirs(output_dir, exist_ok=True)

        # 读取 behaviors.tsv
        behaviors_df = pd.read_csv(
            behaviors_path,
            sep='\t',
            names=['impression_id', 'user_id',
                   'time', 'history', 'impressions']
        )

        print(f"✅ 测试集加载完成: {len(behaviors_df):,} impressions")

        # 清空输出文件（如果存在）
        if os.path.exists(output_path):
            os.remove(output_path)

        # 打开输出文件
        submission_lines = []

        # 逐 impression 处理
        for idx, row in tqdm(behaviors_df.iterrows(), total=len(behaviors_df), desc="在线预测"):
            impression_id = row['impression_id']
            user_id = row['user_id']
            time_str = row['time']
            history = row['history']
            impressions = row['impressions']

            # 解析候选新闻（测试集格式：news_id，无标签）
            candidates = impressions.split()

            # 在线提取特征
            features_df = self.extract_features_online(
                impression_id, user_id, time_str, history, candidates
            )

            # 预测并生成排序
            rank_list = self.predict_and_rank(features_df)

            # 格式化输出
            rank_str = '[' + ','.join(map(str, rank_list)) + ']'
            submission_lines.append(f"{impression_id} {rank_str}")

            # 批量写入
            if (idx + 1) % batch_size == 0:
                with open(output_path, 'a') as f:
                    f.write('\n'.join(submission_lines) + '\n')
                submission_lines = []

        # 写入剩余数据
        if submission_lines:
            with open(output_path, 'a') as f:
                f.write('\n'.join(submission_lines))

        print(f"\n✅ 预测完成！")
        print(f"📄 提交文件: {output_path}")

        return output_path


def main():
    """主函数"""

    print("="*60)
    print("🎯 MIND 测试集在线预测（无需编码器文件）")
    print("="*60)

    # ========== 配置参数 ==========
    MODEL_PATH = 'your_path/src/outputs/lgb_baseline.txt'
    NEWS_PATH = 'your_path/data/MINDlarge_test/news.tsv'
    BEHAVIORS_PATH = 'your_path/data/MINDlarge_test/behaviors.tsv'
    TRAIN_FEATURES_PATH = 'your_path/data/train_features.csv'  # 可选，用于学习类别映射
    OUTPUT_PATH = './outputs/prediction.txt'

    # ========== 检查文件 ==========
    if not os.path.exists(MODEL_PATH):
        raise FileNotFoundError(f"❌ 模型文件不存在: {MODEL_PATH}")
    if not os.path.exists(NEWS_PATH):
        raise FileNotFoundError(f"❌ 新闻文件不存在: {NEWS_PATH}")
    if not os.path.exists(BEHAVIORS_PATH):
        raise FileNotFoundError(f"❌ 行为文件不存在: {BEHAVIORS_PATH}")

    # ========== 初始化预测器 ==========
    predictor = OnlineMINDPredictor(
        model_path=MODEL_PATH,
        news_path=NEWS_PATH,
        train_features_path=TRAIN_FEATURES_PATH  # 如果没有，设为 None
    )

    # ========== 在线预测 ==========
    submission_path = predictor.predict_test_online(
        behaviors_path=BEHAVIORS_PATH,
        output_path=OUTPUT_PATH,
        batch_size=1000
    )

    # ========== 验证提交文件 ==========
    print(f"\n🔍 验证提交文件...")
    with open(submission_path, 'r') as f:
        lines = f.readlines()

    print(f"✅ 提交文件验证:")
    print(f"   总行数: {len(lines):,}")
    print(f"   前3行示例:")
    for i, line in enumerate(lines[:3]):
        print(f"   {i+1}. {line.strip()}")

    print("\n" + "="*60)
    print("✅ 在线预测完成！可以提交到官网了！")
    print(f"📄 提交文件: {submission_path}")
    print("="*60)


if __name__ == '__main__':
    main()
