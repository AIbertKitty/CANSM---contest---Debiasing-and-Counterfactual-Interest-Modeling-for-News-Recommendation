"""
MIND LightGBM Baseline训练
Day 1 - Task 4: 训练第一个baseline
"""

import pandas as pd
import numpy as np
import lightgbm as lgb
from sklearn.metrics import roc_auc_score, log_loss, accuracy_score
import json
from tqdm import tqdm
import warnings
warnings.filterwarnings('ignore')

# ==================== 评估指标实现 ====================


def dcg_score(y_true, y_score, k=10):
    """
    计算DCG@K

    Args:
        y_true: 真实标签列表
        y_score: 预测分数列表
        k: top-k

    Returns:
        DCG@K分数
    """
    order = np.argsort(y_score)[::-1]
    y_true = np.take(y_true, order[:k])
    gains = 2 ** y_true - 1
    discounts = np.log2(np.arange(len(y_true)) + 2)
    return np.sum(gains / discounts)


def ndcg_score(y_true, y_score, k=10):
    """
    计算nDCG@K

    Args:
        y_true: 真实标签列表
        y_score: 预测分数列表
        k: top-k

    Returns:
        nDCG@K分数
    """
    actual = dcg_score(y_true, y_score, k)
    best = dcg_score(y_true, y_true, k)
    return actual / best if best > 0 else 0.0


def mrr_score(y_true, y_score):
    """
    计算MRR (Mean Reciprocal Rank)

    Args:
        y_true: 真实标签列表
        y_score: 预测分数列表

    Returns:
        MRR分数
    """
    order = np.argsort(y_score)[::-1]
    y_true = np.take(y_true, order)

    # 找到第一个正样本的位置
    rr_score = 0.0
    for i, label in enumerate(y_true):
        if label == 1:
            rr_score = 1.0 / (i + 1)
            break

    return rr_score


def evaluate_all_metrics(labels, preds, group_by_impression=None):
    """
    计算所有评估指标

    Args:
        labels: 真实标签
        preds: 预测分数
        group_by_impression: impression_id分组信息（用于计算MRR和nDCG）

    Returns:
        指标字典
    """
    if not isinstance(labels, np.ndarray):
        labels = np.array(labels)
    if not isinstance(preds, np.ndarray):
        preds = np.array(preds)
    if group_by_impression is not None and not isinstance(group_by_impression, np.ndarray):
        group_by_impression = np.array(group_by_impression)

    metrics = {}

    # 1. AUC
    metrics['AUC'] = roc_auc_score(labels, preds)

    # 2. LogLoss
    metrics['LogLoss'] = log_loss(labels, preds)

    # 3. Accuracy (使用0.5作为阈值)
    pred_labels = (preds >= 0.5).astype(int)
    metrics['Accuracy'] = accuracy_score(labels, pred_labels)

    # 4. 如果提供了impression分组，计算MRR和nDCG
    if group_by_impression is not None:
        mrr_list = []
        ndcg5_list = []
        ndcg10_list = []

        # for imp_id in group_by_impression.unique():

        unique_impressions = np.unique(group_by_impression)
        for imp_id in unique_impressions:
            mask = group_by_impression == imp_id
            imp_labels = labels[mask]
            imp_preds = preds[mask]

            # 只有当impression中有正样本时才计算
            if imp_labels.sum() > 0:
                mrr_list.append(mrr_score(imp_labels, imp_preds))
                ndcg5_list.append(ndcg_score(imp_labels, imp_preds, k=5))
                ndcg10_list.append(ndcg_score(imp_labels, imp_preds, k=10))

        metrics['MRR'] = np.mean(mrr_list) if mrr_list else 0.0
        metrics['nDCG@5'] = np.mean(ndcg5_list) if ndcg5_list else 0.0
        metrics['nDCG@10'] = np.mean(ndcg10_list) if ndcg10_list else 0.0

    return metrics

# ==================== LightGBM训练器 ====================


class MINDLightGBMTrainer:
    """MIND LightGBM训练器"""

    def __init__(self,
                 categorical_features=None,
                 lgb_params=None):
        """
        初始化训练器

        Args:
            categorical_features: 类别特征列表
            lgb_params: LightGBM参数
        """
        self.categorical_features = categorical_features or []
        self.lgb_params = lgb_params or self._default_params()
        self.model = None
        self.label_encoders = {}
        self.feature_names = None

    def _default_params(self):
        """默认LightGBM参数"""
        return {
            'objective': 'binary',
            'metric': 'auc',
            'boosting_type': 'gbdt',
            'num_leaves': 31,
            'learning_rate': 0.05,
            'feature_fraction': 0.8,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'verbose': -1,
            'min_child_samples': 20,
            'max_depth': -1,
            'reg_alpha': 0.1,
            'reg_lambda': 0.1,
        }

    def prepare_features(self, df, is_train=True):
        """
        准备特征（优化版 - 使用字典映射）

        Args:
            df: 特征DataFrame
            is_train: 是否训练集

        Returns:
            处理后的特征DataFrame
        """
        df = df.copy()

        # 排除的列
        exclude_cols = [
            'impression_id', 'user_id', 'time', 'history',
            'candidate_news_id', 'label', 'time_dt'
        ]

        # 获取特征列
        feature_cols = [col for col in df.columns if col not in exclude_cols]

        # 优化：使用字典映射替代LabelEncoder
        for col in tqdm(self.categorical_features):
            if col in df.columns:
                if is_train:
                    # 训练时：创建类别到ID的映射字典
                    unique_values = df[col].astype(str).unique()
                    self.label_encoders[col] = {
                        val: idx for idx, val in enumerate(unique_values)
                    }
                    # 使用map进行快速映射
                    df[col] = df[col].astype(str).map(self.label_encoders[col])
                else:
                    # 测试时：使用已有映射，未见过的类别设为-1
                    mapping = self.label_encoders[col]
                    df[col] = df[col].astype(str).map(
                        mapping).fillna(-1).astype(int)

        if is_train:
            self.feature_names = feature_cols

        return df[feature_cols]

    def train(self,
              train_df,
              valid_df=None,
              num_boost_round=1000,
              early_stopping_rounds=50,
              verbose_eval=50):
        """
        训练模型

        Args:
            train_df: 训练数据
            valid_df: 验证数据
            num_boost_round: 最大迭代次数
            early_stopping_rounds: 早停轮数
            verbose_eval: 打印间隔

        Returns:
            训练好的模型
        """
        print("\n" + "="*60)
        print("🚀 开始训练LightGBM模型")
        print("="*60)

        # 准备训练数据
        print("\n📊 准备训练数据...")
        X_train = self.prepare_features(train_df, is_train=True)
        y_train = train_df['label'].values

        print(f"   训练集: {len(X_train):,} 样本, {len(X_train.columns)} 特征")
        print(f"   正样本: {y_train.sum():,} ({y_train.mean()*100:.2f}%)")

        # 创建LightGBM数据集
        train_data = lgb.Dataset(
            X_train,
            label=y_train,
            categorical_feature=[col for col in self.categorical_features
                                 if col in X_train.columns]
        )

        valid_sets = [train_data]
        valid_names = ['train']

        # 准备验证数据
        if valid_df is not None:
            print(f"\n📊 准备验证数据...")
            X_valid = self.prepare_features(valid_df, is_train=False)
            y_valid = valid_df['label'].values

            print(f"   验证集: {len(X_valid):,} 样本")
            print(f"   正样本: {y_valid.sum():,} ({y_valid.mean()*100:.2f}%)")

            valid_data = lgb.Dataset(
                X_valid,
                label=y_valid,
                reference=train_data
            )
            valid_sets.append(valid_data)
            valid_names.append('valid')

        # 训练模型
        print(f"\n🔧 训练参数:")
        for key, value in self.lgb_params.items():
            print(f"   {key}: {value}")

        print(f"\n⏳ 开始训练...")
        self.model = lgb.train(
            self.lgb_params,
            train_data,
            num_boost_round=num_boost_round,
            valid_sets=valid_sets,
            valid_names=valid_names,
            callbacks=[
                lgb.early_stopping(early_stopping_rounds),
                lgb.log_evaluation(verbose_eval)
            ]
        )

        print(f"\n✅ 训练完成！最佳迭代: {self.model.best_iteration}")

        return self.model

    def predict(self, df):
        """
        预测

        Args:
            df: 特征DataFrame

        Returns:
            预测概率
        """
        X = self.prepare_features(df, is_train=False)
        return self.model.predict(X, num_iteration=self.model.best_iteration)

    def evaluate(self, df, dataset_name='Dataset'):
        """
        评估模型

        Args:
            df: 数据DataFrame
            dataset_name: 数据集名称

        Returns:
            评估指标字典
        """
        print(f"\n📈 评估 {dataset_name}...")

        # 预测
        preds = self.predict(df)
        labels = df['label'].values

        # 计算指标
        metrics = evaluate_all_metrics(
            labels,
            preds,
            group_by_impression=df['impression_id'].values if 'impression_id' in df.columns else None
        )

        # 打印结果
        print(f"\n{dataset_name} 评估结果:")
        print("-" * 40)
        for metric_name, metric_value in metrics.items():
            print(f"  {metric_name:12s}: {metric_value:.4f}")
        print("-" * 40)

        return metrics

    def get_feature_importance(self, importance_type='gain', top_k=20):
        """
        获取特征重要性

        Args:
            importance_type: 重要性类型 ('gain', 'split')
            top_k: 返回top-k特征

        Returns:
            特征重要性DataFrame
        """
        importance = self.model.feature_importance(
            importance_type=importance_type)
        feature_importance = pd.DataFrame({
            'feature': self.feature_names,
            'importance': importance
        }).sort_values('importance', ascending=False)

        return feature_importance.head(top_k)

    def print_feature_importance(self, importance_type='gain', top_k=20):
        """打印特征重要性"""
        print(f"\n📊 Top {top_k} 特征重要性 ({importance_type}):")
        print("-" * 60)

        feature_importance = self.get_feature_importance(
            importance_type, top_k)

        for idx, row in feature_importance.iterrows():
            print(f"  {row['feature']:40s}: {row['importance']:>10.0f}")

        print("-" * 60)

    def save_model(self, save_path):
        import os
        import pickle
        """保存模型和编码器"""
        if self.model is None:
            raise ValueError("模型未训练，无法保存！")

        # 保存 LightGBM 模型
        save_dir = os.path.dirname(save_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir, exist_ok=True)

        self.model.save_model(save_path)
        print(f"💾 模型已保存至: {save_path}")

        # ✅ 保存编码器（关键！）
        encoder_path = save_path.replace('.txt', '_encoders.pkl')
        encoder_data = {
            'label_encoders': self.label_encoders,
            'feature_names': self.feature_names,
            'categorical_features': self.categorical_features
        }

        with open(encoder_path, 'wb') as f:
            pickle.dump(encoder_data, f)
        print(f"💾 编码器已保存至: {encoder_path}")

    def load_model(self, model_path):
        """加载模型"""
        self.model = lgb.Booster(model_file=model_path)
        print(f"\n📂 模型已加载: {model_path}")

# ==================== 负采样 ====================


def negative_sampling(df, neg_ratio=0.2, random_state=42):
    """
    负样本下采样

    Args:
        df: 数据DataFrame
        neg_ratio: 保留的负样本比例
        random_state: 随机种子

    Returns:
        采样后的DataFrame
    """
    print(f"\n🎲 负样本下采样 (保留比例: {neg_ratio*100:.0f}%)...")

    pos_df = df[df['label'] == 1]
    neg_df = df[df['label'] == 0]

    print(f"   原始: 正样本 {len(pos_df):,}, 负样本 {len(neg_df):,}")

    # 采样负样本
    neg_sample_size = int(len(neg_df) * neg_ratio)
    neg_df_sampled = neg_df.sample(
        n=neg_sample_size, random_state=random_state)

    # 合并
    df_sampled = pd.concat([pos_df, neg_df_sampled], ignore_index=True)
    df_sampled = df_sampled.sample(
        frac=1, random_state=random_state).reset_index(drop=True)

    print(f"   采样后: 正样本 {len(pos_df):,}, 负样本 {len(neg_df_sampled):,}")
    print(
        f"   总样本: {len(df_sampled):,}, 点击率: {df_sampled['label'].mean()*100:.2f}%")

    return df_sampled

# ==================== 主函数 ====================


def main():
    """主函数：完整执行LightGBM训练流程"""

    print("="*60)
    print("🚀 MIND LightGBM Baseline - Day 1 Task 4")
    print("="*60)

    # 1. 读取数据
    print("\n📂 读取特征数据...")
    train_df = pd.read_csv(
        "/Users/xuyunpeng/Desktop/统计建模大赛/project/data/train_features.csv")
    dev_df = pd.read_csv(
        "/Users/xuyunpeng/Desktop/统计建模大赛/project/data/dev_features.csv")

    print(f"✅ 训练集: {len(train_df):,} 样本")
    print(f"✅ 验证集: {len(dev_df):,} 样本")

    # 2. 负采样（可选）
    use_negative_sampling = True
    if use_negative_sampling:
        train_df = negative_sampling(train_df, neg_ratio=0.2, random_state=42)

    # 3. 定义类别特征
    categorical_features = [
        'candidate_category',
        'candidate_subcategory',
        'time_period'
    ]

    # 4. 初始化训练器
    trainer = MINDLightGBMTrainer(
        categorical_features=categorical_features,
        lgb_params={
            'objective': 'binary',
            'metric': 'auc',
            'boosting_type': 'gbdt',
            'num_leaves': 31,
            'learning_rate': 0.05,
            'feature_fraction': 0.8,
            'bagging_fraction': 0.8,
            'bagging_freq': 5,
            'verbose': -1,
            'min_child_samples': 20,
            'reg_alpha': 0.1,
            'reg_lambda': 0.1,
        }
    )

    # 5. 训练模型
    trainer.train(
        train_df=train_df,
        valid_df=dev_df,
        num_boost_round=1000,
        early_stopping_rounds=50,
        verbose_eval=50
    )

    # 6. 评估模型
    train_metrics = trainer.evaluate(train_df, dataset_name='训练集')
    dev_metrics = trainer.evaluate(dev_df, dataset_name='验证集')

    # 7. 特征重要性
    trainer.print_feature_importance(importance_type='gain', top_k=20)

    # 8. 保存模型
    trainer.save_model("./outputs/lgb_baseline.txt")

    # 9. 保存结果
    results = {
        'model': 'LightGBM Baseline',
        'train_metrics': train_metrics,
        'dev_metrics': dev_metrics,
        'feature_importance': trainer.get_feature_importance(top_k=20).to_dict('records')
    }

    with open('./outputs/lgb_baseline_results.json', 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)

    print("\n💾 结果已保存至: ./outputs/lgb_baseline_results.json")

    # 10. 生成结果表格
    print("\n" + "="*60)
    print("📊 最终结果汇总")
    print("="*60)

    results_table = pd.DataFrame({
        '指标': list(train_metrics.keys()),
        '训练集': [f"{v:.4f}" for v in train_metrics.values()],
        '验证集': [f"{v:.4f}" for v in dev_metrics.values()]
    })

    print(results_table.to_string(index=False))
    print("="*60)

    print("\n✅ Day 1 Task 4 完成！")

    return trainer, train_metrics, dev_metrics


if __name__ == "__main__":
    trainer, train_metrics, dev_metrics = main()
