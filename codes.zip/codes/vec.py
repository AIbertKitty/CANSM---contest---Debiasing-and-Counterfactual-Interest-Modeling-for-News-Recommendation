"""
Day 2 Task 1: 抽取新闻文本向量
使用 sentence-transformers 的 MiniLM 模型
"""

import pandas as pd
import numpy as np
import json
from sentence_transformers import SentenceTransformer
import os

# ==================== 配置 ====================
DATA_DIR = "your_path/data/MINDsmall_train"
OUTPUT_DIR = "your_path/data/embeddings"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 模型选择
MODEL_NAME = "sentence-transformers/all-MiniLM-L6-v2"
# 备选：
# "sentence-transformers/all-mpnet-base-v2"  # 更强但更慢
# "sentence-transformers/paraphrase-MiniLM-L6-v2"

BATCH_SIZE = 256  # 根据显存调整
MAX_LENGTH = 128  # 标题+摘要最大长度

# ==================== 1. 读取新闻数据 ====================
print("=" * 50)
print("Step 1: 读取新闻数据")
print("=" * 50)

news_cols = [
    "news_id", "category", "subcategory", "title", "abstract",
    "url", "title_entities", "abstract_entities"
]

news_df = pd.read_csv(
    f"{DATA_DIR}/news.tsv",
    sep="\t",
    names=news_cols,
    encoding="utf-8"
)

print(f"新闻总数: {len(news_df)}")
print(f"前3条样例:")
print(news_df[["news_id", "category", "title", "abstract"]].head(3))

# ==================== 2. 构造文本输入 ====================
print("\n" + "=" * 50)
print("Step 2: 构造文本输入")
print("=" * 50)

def construct_text(row):
    """
    将 title 和 abstract 拼接成一个文本
    格式：title [SEP] abstract
    """
    title = str(row["title"]) if pd.notna(row["title"]) else ""
    abstract = str(row["abstract"]) if pd.notna(row["abstract"]) else ""
    
    # 如果 abstract 为空，只用 title
    if abstract.strip() == "":
        return title.strip()
    
    # 拼接
    return f"{title.strip()} [SEP] {abstract.strip()}"

news_df["text"] = news_df.apply(construct_text, axis=1)

print(f"文本样例:")
for i in range(3):
    print(f"\n新闻 {i+1}:")
    print(f"  news_id: {news_df.iloc[i]['news_id']}")
    print(f"  category: {news_df.iloc[i]['category']}")
    print(f"  text: {news_df.iloc[i]['text'][:200]}...")

# ==================== 3. 加载预训练模型 ====================
print("\n" + "=" * 50)
print("Step 3: 加载预训练模型")
print("=" * 50)

print(f"正在加载模型: {MODEL_NAME}")
print("首次运行会自动下载，可能需要几分钟...")

try:
    model = SentenceTransformer(MODEL_NAME)
    print(f"✓ 模型加载成功")
    print(f"  输出维度: {model.get_sentence_embedding_dimension()}")
except Exception as e:
    print(f"✗ 模型加载失败: {e}")
    print("\n如果下载失败，可以尝试：")
    print("1. 手动下载模型到本地")
    print("2. 使用国内镜像")
    print("3. 使用备选方案（TF-IDF）")
    raise

# ==================== 4. 批量编码 ====================
print("\n" + "=" * 50)
print("Step 4: 批量编码新闻文本")
print("=" * 50)

texts = news_df["text"].tolist()

print(f"开始编码 {len(texts)} 条新闻...")
print(f"Batch size: {BATCH_SIZE}")

# 使用 tqdm 显示进度
embeddings = model.encode(
    texts,
    batch_size=BATCH_SIZE,
    show_progress_bar=True,
    convert_to_numpy=True,
    normalize_embeddings=True  # L2 归一化，有助于后续相似度计算
)

print(f"✓ 编码完成")
print(f"  Embeddings shape: {embeddings.shape}")
print(f"  数据类型: {embeddings.dtype}")

# ==================== 5. 构造 news_id 到 index 的映射 ====================
print("\n" + "=" * 50)
print("Step 5: 构造索引映射")
print("=" * 50)

news_id_to_index = {
    news_id: idx 
    for idx, news_id in enumerate(news_df["news_id"].tolist())
}

print(f"映射样例:")
for i, (news_id, idx) in enumerate(list(news_id_to_index.items())[:3]):
    print(f"  {news_id} -> {idx}")

# ==================== 6. 保存结果 ====================
print("\n" + "=" * 50)
print("Step 6: 保存结果")
print("=" * 50)

# 保存 embeddings
embeddings_path = f"{OUTPUT_DIR}/news_embeddings.npy"
np.save(embeddings_path, embeddings)
print(f"✓ 已保存: {embeddings_path}")

# 保存映射
mapping_path = f"{OUTPUT_DIR}/news_id_to_index.json"
with open(mapping_path, "w", encoding="utf-8") as f:
    json.dump(news_id_to_index, f, ensure_ascii=False, indent=2)
print(f"✓ 已保存: {mapping_path}")

# 保存新闻元信息（可选，方便后续分析）
meta_path = f"{OUTPUT_DIR}/news_meta.csv"
news_df[["news_id", "category", "subcategory", "title"]].to_csv(
    meta_path, index=False, encoding="utf-8"
)
print(f"✓ 已保存: {meta_path}")

# ==================== 7. 验证结果 ====================
print("\n" + "=" * 50)
print("Step 7: 验证结果")
print("=" * 50)

# 重新加载验证
loaded_embeddings = np.load(embeddings_path)
with open(mapping_path, "r", encoding="utf-8") as f:
    loaded_mapping = json.load(f)

print(f"✓ 加载验证成功")
print(f"  Embeddings shape: {loaded_embeddings.shape}")
print(f"  映射条目数: {len(loaded_mapping)}")

# 计算相似度验证
print("\n相似度验证（前3条新闻）:")
for i in range(min(3, len(embeddings))):
    # 计算与自己的相似度（应该接近1）
    self_sim = np.dot(embeddings[i], embeddings[i])
    # 计算与下一条的相似度
    if i + 1 < len(embeddings):
        next_sim = np.dot(embeddings[i], embeddings[i+1])
        print(f"  新闻 {i}: 自相似度={self_sim:.4f}, 与下一条相似度={next_sim:.4f}")
    else:
        print(f"  新闻 {i}: 自相似度={self_sim:.4f}")

print("\n" + "=" * 50)
print("✓ Day 2 Task 1 完成！")
print("=" * 50)
print(f"\n输出文件:")
print(f"  1. {embeddings_path}")
print(f"  2. {mapping_path}")
print(f"  3. {meta_path}")
print(f"\n下一步: 使用这些向量训练 Text-Avg-MLP 和 DIN-lite")