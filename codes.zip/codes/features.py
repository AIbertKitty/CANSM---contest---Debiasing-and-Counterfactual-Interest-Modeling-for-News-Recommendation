"""
MIND基础特征工程
Day 1 - Task 3: 构造基础特征
python features.py
"""

import pandas as pd
import numpy as np
import warnings
from tqdm import tqdm
tqdm.pandas()

warnings.filterwarnings('ignore')


class MINDFeatureEngineer:
    """MIND特征工程器"""

    def __init__(self,
                 news_df: pd.DataFrame,
                 samples_df: pd.DataFrame):
        """
        初始化特征工程器

        Args:
            news_df: 新闻数据
            samples_df: 展开后的样本数据
        """
        self.news_df = news_df
        self.samples_df = samples_df
        self.features_df = None

        # 构建新闻ID到信息的映射
        self._build_news_dict()

    def _build_news_dict(self):
        """构建新闻信息字典，加速查询"""
        print("📚 构建新闻信息字典...")

        self.news_dict = {}
        for idx, row in tqdm(self.news_df.iterrows()):
            self.news_dict[row['news_id']] = {
                'category': row['category'],
                'subcategory': row['subcategory'],
                'title': row['title'] if pd.notna(row['title']) else "",
                'abstract': row['abstract'] if pd.notna(row['abstract']) else "",
                'title_entities': row['title_entities'] if pd.notna(row['title_entities']) else "",
                'abstract_entities': row['abstract_entities'] if pd.notna(row['abstract_entities']) else ""
            }

        print(f"✅ 新闻字典构建完成: {len(self.news_dict)} 条新闻")

    def extract_all_features(self) -> pd.DataFrame:
        """
        提取所有基础特征

        Returns:
            包含所有特征的DataFrame
        """
        print("\n" + "="*60)
        print("🔧 开始提取基础特征")
        print("="*60)

        # 复制样本数据
        self.features_df = self.samples_df.copy()

        # 1. 候选新闻特征
        self._extract_candidate_features()

        # 2. 用户历史特征
        self._extract_user_history_features()

        # 3. 用户-候选匹配特征
        self._extract_matching_features()

        # 4. 时间特征
        self._extract_time_features()

        print("\n" + "="*60)
        print(f"✅ 特征提取完成！总特征数: {len(self.features_df.columns)}")
        print("="*60)

        return self.features_df

    def _extract_candidate_features(self):
        """提取候选新闻特征"""
        print("\n📰 提取候选新闻特征...")

        # 获取候选新闻信息
        candidate_info = self.features_df['candidate_news_id'].map(
            lambda x: self.news_dict.get(x, {})
        )

        # 1. 类别特征
        self.features_df['candidate_category'] = candidate_info.map(
            lambda x: x.get('category', 'unknown')
        )
        self.features_df['candidate_subcategory'] = candidate_info.map(
            lambda x: x.get('subcategory', 'unknown')
        )

        # 2. 文本长度特征
        self.features_df['candidate_title_len'] = candidate_info.map(
            lambda x: len(x.get('title', '').split())
        )
        self.features_df['candidate_abstract_len'] = candidate_info.map(
            lambda x: len(x.get('abstract', '').split())
        )

        # 3. 是否有摘要
        self.features_df['candidate_has_abstract'] = (
            self.features_df['candidate_abstract_len'] > 0
        ).astype(int)

        # 4. 实体数量特征
        self.features_df['candidate_title_entity_count'] = candidate_info.map(
            lambda x: len(x.get('title_entities', '').split()
                          ) if x.get('title_entities', '') else 0
        )
        self.features_df['candidate_abstract_entity_count'] = candidate_info.map(
            lambda x: len(x.get('abstract_entities', '').split()
                          ) if x.get('abstract_entities', '') else 0
        )
        self.features_df['candidate_total_entity_count'] = (
            self.features_df['candidate_title_entity_count'] +
            self.features_df['candidate_abstract_entity_count']
        )

        # 5. 是否有实体
        self.features_df['candidate_has_entity'] = (
            self.features_df['candidate_total_entity_count'] > 0
        ).astype(int)

        print(f"   ✓ 候选新闻特征: 10个")

    def _extract_user_history_features(self):
        """提取用户历史特征"""
        print("\n👤 提取用户历史特征...")

        self.features_df['history'] = self.features_df['history'].fillna("")

        # 1. 历史长度
        self.features_df['user_history_len'] = self.features_df['history'].progress_apply(
            lambda x: len(x.split()) if x else 0
        )

        # 2. 是否有历史
        self.features_df['user_has_history'] = (
            self.features_df['user_history_len'] > 0
        ).astype(int)

        # 3. 历史类别分布
        print("   计算用户历史类别分布...")
        history_categories = self.features_df['history'].progress_apply(
            self._get_history_categories
        )
        print("   计算用户历史类别数量...")
        # 4. 历史类别数量
        self.features_df['user_history_category_count'] = history_categories.progress_apply(
            len)
        print("   计算用户历史子类数量...")
        # 5. 历史子类别数量
        history_subcategories = self.features_df['history'].progress_apply(
            self._get_history_subcategories
        )
        self.features_df['user_history_subcategory_count'] = history_subcategories.progress_apply(
            len)
        print("   计算用户历史平均标题长度...")
        # 6. 用户历史平均标题长度
        self.features_df['user_history_avg_title_len'] = self.features_df['history'].progress_apply(
            self._get_avg_history_title_len
        )
        print("   计算用户历史实体总数...")
        # 7. 用户历史实体总数
        self.features_df['user_history_total_entities'] = self.features_df['history'].progress_apply(
            self._get_history_total_entities
        )

        # 保存历史类别信息用于后续匹配
        self.features_df['_history_categories'] = history_categories
        self.features_df['_history_subcategories'] = history_subcategories

        print(f"   ✓ 用户历史特征: 7个")

    def _extract_matching_features(self):
        """提取用户-候选匹配特征"""
        print("\n🔗 提取用户-候选匹配特征...")
        print('候选类别是否在用户历史中出现')
        # 1. 候选类别是否在用户历史中出现
        self.features_df['category_in_history'] = self.features_df.progress_apply(
            lambda row: int(row['candidate_category']
                            in row['_history_categories']),
            axis=1
        )
        print('候选子类别是否在用户历史中出现')
        # 2. 候选子类别是否在用户历史中出现
        self.features_df['subcategory_in_history'] = self.features_df.progress_apply(
            lambda row: int(row['candidate_subcategory']
                            in row['_history_subcategories']),
            axis=1
        )

        # 3. 候选类别在历史中出现次数
        print("   计算类别匹配次数...")
        self.features_df['category_match_count'] = self.features_df.progress_apply(
            lambda row: self._count_category_in_history(
                row['candidate_category'],
                row['history']
            ),
            axis=1
        )
        print('候选子类别在历史中出现次数')
        # 4. 候选子类别在历史中出现次数
        self.features_df['subcategory_match_count'] = self.features_df.progress_apply(
            lambda row: self._count_subcategory_in_history(
                row['candidate_subcategory'],
                row['history']
            ),
            axis=1
        )
        print('类别匹配比例')
        # 5. 类别匹配比例
        self.features_df['category_match_ratio'] = (
            self.features_df['category_match_count'] /
            (self.features_df['user_history_len'] + 1e-6)
        )
        print('子类别匹配比例')
        # 6. 子类别匹配比例
        self.features_df['subcategory_match_ratio'] = (
            self.features_df['subcategory_match_count'] /
            (self.features_df['user_history_len'] + 1e-6)
        )
        print('删除临时列')
        # 删除临时列
        self.features_df.drop(['_history_categories', '_history_subcategories'],
                              axis=1, inplace=True)

        print(f"   ✓ 匹配特征: 6个")

    def _extract_time_features(self):
        """提取时间特征"""
        print("\n⏰ 提取时间特征...")

        # 转换时间格式
        self.features_df['time_dt'] = pd.to_datetime(
            self.features_df['time'],
            format='%m/%d/%Y %I:%M:%S %p',
            errors='coerce'
        )

        # 1. 小时
        self.features_df['hour'] = self.features_df['time_dt'].dt.hour

        # 2. 星期几
        self.features_df['dayofweek'] = self.features_df['time_dt'].dt.dayofweek

        # 3. 是否周末
        self.features_df['is_weekend'] = (
            self.features_df['dayofweek'] >= 5
        ).astype(int)

        # 4. 时间段（早中晚夜）
        self.features_df['time_period'] = self.features_df['hour'].progress_apply(
            self._get_time_period
        )

        print(f"   ✓ 时间特征: 4个")

    # ========== 辅助函数 ==========

    def _get_history_categories(self, history: str) -> set:
        """获取历史新闻的类别集合"""
        if not history:
            return set()

        news_ids = history.split()
        categories = set()
        for nid in news_ids:
            if nid in self.news_dict:
                categories.add(self.news_dict[nid]['category'])
        return categories

    def _get_history_subcategories(self, history: str) -> set:
        """获取历史新闻的子类别集合"""
        if not history:
            return set()

        news_ids = history.split()
        subcategories = set()
        for nid in news_ids:
            if nid in self.news_dict:
                subcategories.add(self.news_dict[nid]['subcategory'])
        return subcategories

    def _get_avg_history_title_len(self, history: str) -> float:
        """获取历史新闻平均标题长度"""
        if not history:
            return 0.0

        news_ids = history.split()
        title_lens = []
        for nid in news_ids:
            if nid in self.news_dict:
                title = self.news_dict[nid]['title']
                title_lens.append(len(title.split()))

        return np.mean(title_lens) if title_lens else 0.0

    def _get_history_total_entities(self, history: str) -> int:
        """获取历史新闻实体总数"""
        if not history:
            return 0

        news_ids = history.split()
        total_entities = 0
        for nid in news_ids:
            if nid in self.news_dict:
                title_ent = self.news_dict[nid]['title_entities']
                abstract_ent = self.news_dict[nid]['abstract_entities']
                total_entities += len(title_ent.split()) if title_ent else 0
                total_entities += len(abstract_ent.split()
                                      ) if abstract_ent else 0

        return total_entities

    def _count_category_in_history(self, category: str, history: str) -> int:
        """统计候选类别在历史中出现次数"""
        if not history:
            return 0

        news_ids = history.split()
        count = 0
        for nid in news_ids:
            if nid in self.news_dict:
                if self.news_dict[nid]['category'] == category:
                    count += 1
        return count

    def _count_subcategory_in_history(self, subcategory: str, history: str) -> int:
        """统计候选子类别在历史中出现次数"""
        if not history:
            return 0

        news_ids = history.split()
        count = 0
        for nid in news_ids:
            if nid in self.news_dict:
                if self.news_dict[nid]['subcategory'] == subcategory:
                    count += 1
        return count

    def _get_time_period(self, hour: int) -> str:
        """获取时间段"""
        if pd.isna(hour):
            return 'unknown'
        if 6 <= hour < 12:
            return 'morning'
        elif 12 <= hour < 18:
            return 'afternoon'
        elif 18 <= hour < 24:
            return 'evening'
        else:
            return 'night'

    def get_feature_summary(self) -> pd.DataFrame:
        """
        获取特征摘要

        Returns:
            特征摘要DataFrame
        """
        if self.features_df is None:
            print("⚠️  请先运行extract_all_features()")
            return pd.DataFrame()

        # 排除原始列
        exclude_cols = [
            'impression_id', 'user_id', 'time', 'history',
            'candidate_news_id', 'time_dt'
        ]

        feature_cols = [col for col in self.features_df.columns
                        if col not in exclude_cols]

        summary = []
        for col in feature_cols:
            dtype = self.features_df[col].dtype
            nunique = self.features_df[col].nunique()
            missing = self.features_df[col].isna().sum()
            missing_pct = missing / len(self.features_df) * 100

            if dtype in ['int64', 'float64']:
                mean_val = self.features_df[col].mean()
                std_val = self.features_df[col].std()
                min_val = self.features_df[col].min()
                max_val = self.features_df[col].max()

                summary.append({
                    'feature': col,
                    'dtype': str(dtype),
                    'nunique': nunique,
                    'missing': missing,
                    'missing_pct': f"{missing_pct:.2f}%",
                    'mean': f"{mean_val:.2f}",
                    'std': f"{std_val:.2f}",
                    'min': f"{min_val:.2f}",
                    'max': f"{max_val:.2f}"
                })
            else:
                summary.append({
                    'feature': col,
                    'dtype': str(dtype),
                    'nunique': nunique,
                    'missing': missing,
                    'missing_pct': f"{missing_pct:.2f}%",
                    'mean': '-',
                    'std': '-',
                    'min': '-',
                    'max': '-'
                })

        return pd.DataFrame(summary)

    def print_feature_summary(self):
        """打印特征摘要"""
        summary_df = self.get_feature_summary()

        print("\n" + "="*100)
        print("📊 特征摘要")
        print("="*100)
        print(summary_df.to_string(index=False))
        print("="*100)

    def save_features(self, save_path: str):
        """
        保存特征数据

        Args:
            save_path: 保存路径
        """
        if self.features_df is None:
            print("⚠️  请先运行extract_all_features()")
            return

        self.features_df.to_csv(save_path, index=False)
        print(f"\n💾 特征数据已保存至: {save_path}")
        print(f"   样本数: {len(self.features_df):,}")
        print(f"   特征数: {len(self.features_df.columns)}")


def main():
    # 训练集
    train_news = pd.read_csv("your_path/data/MINDsmall_train/news.tsv", sep="\t", names=["news_id", "category", "subcategory", "title",
       "abstract", "url", "title_entities", "abstract_entities"], encoding='utf-8')
    train_samples = pd.read_csv("your_path/data/train_samples.csv")

    train_engineer = MINDFeatureEngineer(train_news, train_samples)
    _ = train_engineer.extract_all_features()
    train_engineer.save_features("your_path/data/train_features.csv")

    # 验证集
    dev_news = pd.read_csv("your_path/data/MINDsmall_dev/news.tsv", sep="\t", names=["news_id", "category", "subcategory", "title",
       "abstract", "url", "title_entities", "abstract_entities"], encoding='utf-8')
    dev_samples = pd.read_csv("your_path/data/dev_samples.csv")

    dev_engineer = MINDFeatureEngineer(dev_news, dev_samples)
    _ = dev_engineer.extract_all_features()
    dev_engineer.save_features("your_path/data/dev_features.csv")

if __name__ == "__main__":
    main()
